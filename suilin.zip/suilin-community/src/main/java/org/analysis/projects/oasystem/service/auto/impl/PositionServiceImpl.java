package org.analysis.projects.oasystem.service.auto.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.analysis.projects.oasystem.mapper.auto.PositionMapper;
import org.analysis.projects.oasystem.model.auto.Position;
import org.analysis.projects.oasystem.service.auto.PositionService;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 职位信息 服务实现类
 * </p>
 *
 * @author Feliz
 * @since 2019-06-14
 */
@Service
public class PositionServiceImpl extends ServiceImpl<PositionMapper, Position> implements PositionService {

}
