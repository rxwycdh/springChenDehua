package org.analysis.projects.suilin.mapper.auto;

import org.analysis.projects.suilin.model.auto.Community;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.CacheNamespace;

/**
 * <p>
 * 小区信息 Mapper 接口
 * </p>
 *
 * @author Feliz
 * @since 2020-07-28
 */
@CacheNamespace(flushInterval = 3600000, size = 4096)
public interface CommunityMapper extends BaseMapper<Community> {

}
