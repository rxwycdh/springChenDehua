package org.analysis.projects.ppp.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.analysis.projects.ppp.model.auto.ServerSupply;
import org.analysis.projects.ppp.service.auto.ServerSupplyService;
import org.analysis.system.common.base.BaseController;
import org.analysis.system.common.domain.AjaxResult;
import org.analysis.system.common.domain.TableSplitResult;
import org.analysis.system.common.domain.Tablepar;
import org.analysis.system.common.log.Log;
import org.analysis.system.common.support.Convert;
import org.analysis.system.model.custom.TitleVo;
import org.analysis.system.util.ExcelUtils;
import org.analysis.system.util.StringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.io.InputStream;
import java.io.OutputStream;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;


/**
 * <p>
 * 服务版服务商信息 前端控制器
 * </p>
 *
 * @author Feliz
 * @since 2020-04-23 17:52:41
 */
@Controller
@Api(tags = {"服务版服务商信息"})
@RequestMapping("/ppp/ServerSupplyController")
public class ServerSupplyController extends BaseController{

    private static Logger logger = LoggerFactory.getLogger(ServerSupplyController.class);

    //跳转页面参数
    private String prefix = "projects/ppp/serverSupply";

	@Autowired
	private ServerSupplyService serverSupplyService;

	//跳转服务版服务商信息页面
    @GetMapping("/view")
    @RequiresPermissions("ppp:serverSupply:view")
    public String view(Model model) {
        String str="服务入驻信息";
        setTitle(model, new TitleVo(str+"列表", str+"管理", false, "欢迎进入"+str+"页面", false, false));
        return prefix + "/list";
    }

    @Log(title = "服务版服务商信息列表查询", action = "111")
    @ApiOperation(value = "获取服务版服务商信息列表", notes = "获取服务版服务商信息列表")
    @PostMapping("/list")
    @RequiresPermissions("ppp:serverSupply:list")
    @ResponseBody
    public TableSplitResult<ServerSupply> list(Tablepar tablepar, String searchText) {

        QueryWrapper<ServerSupply> queryWrapper = new QueryWrapper<>();
        if (StringUtils.isNotEmpty(searchText)) {
            queryWrapper.and(wrapper -> wrapper
                    .like("service_provider", searchText).or()
                    .like("type", searchText).or()
                    .like("description", searchText).or()
                    .like("name", searchText).or()
                    .like("phone", searchText).or()
                    .like("wechat", searchText).or()
            );
        }

        PageHelper.startPage(tablepar.getPageNum(), tablepar.getPageSize());
        List<ServerSupply> list = serverSupplyService.list(queryWrapper);
        PageInfo<ServerSupply> pageInfo = new PageInfo<ServerSupply>(list);

        return new TableSplitResult<>(pageInfo.getPageNum(), pageInfo.getTotal(), pageInfo.getList());
    }

    @ApiOperation(value = "获取全部服务版服务商信息信息", notes = "获取全部服务版服务商信息信息")
    @PostMapping("/getAllServerSupply")
    @ResponseBody
    public AjaxResult<TableSplitResult<ServerSupply>> getAllServerSupply() {
        try {
            List<ServerSupply> list = serverSupplyService.list();
            return AjaxResult.successDataList(list);
        } catch (Exception e) {
            logger.error(e.toString());
            return AjaxResult.error(e.getMessage());
        }
    }

    //跳转服务版服务商信息新增页面
    @GetMapping("/add")
    public String add() {
        return prefix + "/add";
    }

    @Log(title = "服务版服务商信息新增", action = "111")
    @ApiOperation(value = "添加服务版服务商信息", notes = "添加服务版服务商信息")
    @PostMapping("add")
    @RequiresPermissions("ppp:serverSupply:add")
    @ResponseBody
    public AjaxResult add(ServerSupply serverSupply) {
        serverSupply.setCreateTime(LocalDateTime.now());
        boolean save = serverSupplyService.save(serverSupply);
        return save ? success() : error();
    }

    @Log(title = "服务版服务商信息删除", action = "111")
    @ApiOperation(value = "删除服务版服务商信息", notes = "根据id删除服务版服务商信息（可批量）")
    @PostMapping("/remove")
    @RequiresPermissions("ppp:serverSupply:remove")
    @ResponseBody
    public AjaxResult remove(String ids) {
        List<Integer> idList= Convert.toListIntArray(ids);
        boolean delete = serverSupplyService.removeByIds(idList);
        return delete ? success() : error();
    }

    //跳转服务版服务商信息修改页面
    @GetMapping("/edit/{id}")
    public String edit(@PathVariable("id") Integer id, ModelMap modelMap) {
        modelMap.put("serverSupply", serverSupplyService.getById(id));
        return prefix + "/edit";
    }

    @Log(title = "服务版服务商信息修改", action = "111")
    @ApiOperation(value = "修改服务版服务商信息", notes = "修改服务版服务商信息")
    @PostMapping("/edit")
    @RequiresPermissions("ppp:serverSupply:edit")
    @ResponseBody
    public AjaxResult editSave(ServerSupply serverSupply) {
        serverSupply.setUpdateTime(LocalDateTime.now());
        boolean edit = serverSupplyService.updateById(serverSupply);
        return edit ? success() : error();
    }


    //跳转服务版服务商信息批量新增页面
    @GetMapping("/batchAdd")
    public String batchAdd() {
        return prefix + "/batchAdd";
    }

    @Log(title = "服务版服务商信息批量导入", action = "111")
    @ApiOperation(value = "批量导入服务版服务商信息", notes = "批量导入服务版服务商信息")
    @RequiresPermissions("ppp:serverSupply:add")
    @Transactional(propagation = Propagation.REQUIRED)
    @PostMapping("/batchAdd")
    @ResponseBody
    public AjaxResult batchAdd(@RequestParam(value = "file", required = false) MultipartFile file) {
        try {
            String suffer = file.getOriginalFilename().substring(file.getOriginalFilename().indexOf(".") + 1);
            if ("xls".equals(suffer) || "xlsx".equals(suffer)) {
                InputStream in = file.getInputStream();
                Map<String, String> fields = new LinkedHashMap<String, String>();

                fields.put("服务商", "serviceProvider");
                fields.put("服务类型", "type");
                fields.put("服务描述", "description");
                fields.put("联系人", "name");
                fields.put("联系电话", "phone");
                fields.put("联系微信", "wechat");

                List<ServerSupply> list = new ArrayList<ServerSupply>();
                list = ExcelUtils.ExecltoList(in, ServerSupply.class, fields);

                int sum = list.size();//总需导入数
                int successNum = 0;//成功导入数
                int failNum = 0;//失败导入数
                for (ServerSupply o : list) {

                    AjaxResult res = add(o);
                    if (res.getCode() == 200) {
                        successNum++;
                    }else {
                        failNum++;
                    }
                }

                return success("总需导入数：" + sum + "</br>成功导入数：" + successNum +" </br>失败导入数：" + failNum);
            }
            return error("上传文件格式应为xls或xlsx");

        } catch (Exception e) {
            logger.error(ExceptionUtils.getFullStackTrace(e));
            return error("上传文件模板有误，请对比导入模板！");
        }
    }

    @Log(title = "服务版服务商信息导入模板获取", action = "111")
    @GetMapping("/getExcelModel")
    @ResponseBody
    public void getUserCardExcelModel(HttpServletResponse response) throws Exception {
        OutputStream out = null;
        //通过response对象获取outputStream流
        response.setContentType("application/octect-stream"); // 下载文件能正常显示中文
        response.setHeader("Content-Disposition", "attachment;filename=" + new String(("服务入驻信息的导入模板.xls").getBytes("gb2312"), "ISO8859-1"));
        out = response.getOutputStream();

        Map<String, String> fields = new LinkedHashMap<String, String>();

        fields.put("serviceProvider", "服务商");
        fields.put("type", "服务类型");
        fields.put("description", "服务描述");
        fields.put("name", "联系人");
        fields.put("phone", "联系电话");
        fields.put("wechat", "联系微信");

        ExcelUtils.ListtoExecl(null, out, fields);
        out.flush();
        out.close();
    }

	
}
