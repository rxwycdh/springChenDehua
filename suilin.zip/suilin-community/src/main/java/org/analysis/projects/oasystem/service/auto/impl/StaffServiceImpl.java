package org.analysis.projects.oasystem.service.auto.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.analysis.projects.oasystem.mapper.auto.StaffMapper;
import org.analysis.projects.oasystem.model.auto.Staff;
import org.analysis.projects.oasystem.service.auto.StaffService;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 职员信息 服务实现类
 * </p>
 *
 * @author Feliz
 * @since 2019-06-14
 */
@Service
public class StaffServiceImpl extends ServiceImpl<StaffMapper, Staff> implements StaffService {

}
