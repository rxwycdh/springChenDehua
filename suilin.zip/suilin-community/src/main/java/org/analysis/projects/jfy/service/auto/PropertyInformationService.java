package org.analysis.projects.jfy.service.auto;

import com.baomidou.mybatisplus.extension.service.IService;
import org.analysis.projects.jfy.model.auto.PropertyInformation;

/**
 * <p>
 * 业主决策物业信息表 服务类
 * </p>
 *
 * @author Feliz
 * @since 2019-07-03
 */
public interface PropertyInformationService extends IService<PropertyInformation> {

}
