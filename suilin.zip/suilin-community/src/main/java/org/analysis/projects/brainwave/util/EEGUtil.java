package org.analysis.projects.brainwave.util;

public class EEGUtil {

    /**
     * 计算波值
     *
     * @param high
     * @param mid
     * @param low
     * @return
     */
    public static int getEEGPower(int high, int mid, int low) {
        int eegPower = (high << 16) | (mid << 8) | low;
        return eegPower;
    }

    /**
     * 获取小包中的原始数据
     * @param xxHigh
     * @param xxLow
     * @param sum
     * @param checkSum
     * @return
     */
    public static Integer getRawData(Integer xxHigh, Integer xxLow, Integer sum, Integer checkSum) {
        Integer rawdata = null;
        if (sum.equals(checkSum)) {
            //原生数据
            rawdata = (xxHigh << 8) | xxLow;
            if (rawdata > 32768) {
                rawdata -= 65536;
            }
        }
        return rawdata;
    }

}
