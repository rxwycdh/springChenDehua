package org.analysis.projects.ppp.service.auto;

import org.analysis.projects.ppp.model.auto.ProjectTag;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 项目标签中间 服务类
 * </p>
 *
 * @author Feliz
 * @since 2020-04-03
 */
public interface ProjectTagService extends IService<ProjectTag> {

}
