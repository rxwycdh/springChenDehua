package org.analysis.projects.ppp.minapp.client;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.analysis.projects.ppp.model.auto.RotationChart;
import org.analysis.projects.ppp.model.custom.RotationChartIF;
import org.analysis.projects.ppp.service.auto.RotationChartService;
import org.analysis.system.common.domain.TableSplitResult;
import org.analysis.system.common.domain.Tablepar;
import org.apache.commons.beanutils.BeanUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.List;

/**
 * 微信小程序用户版获取轮播图接口
 */
@RestController
@Api(tags = {"微信小程序用户版-轮播图接口"})
@RequestMapping("/wx/pppclient/minapp/rotationchart")
public class WxMaClientRotationChartController {

    private static Logger logger = LoggerFactory.getLogger(WxMaClientRotationChartController.class);

    @Autowired
    private RotationChartService rotationChartService;

    @ApiOperation(value = "获取轮播信息表列表", notes = "获取轮播信息表列表")
    @GetMapping("/list")
    public TableSplitResult<RotationChartIF> list(Tablepar tablepar, HttpServletRequest request) {

        try {
            QueryWrapper<RotationChart> queryWrapper = new QueryWrapper<>();
            queryWrapper.orderByAsc("sort=0, sort");
            PageHelper.startPage(tablepar.getPageNum(), tablepar.getPageSize());
            List<RotationChart> rotationCharts = rotationChartService.list(queryWrapper);
            PageInfo<RotationChart> pageInfo = new PageInfo<RotationChart>(rotationCharts);

            List<RotationChartIF> list = new ArrayList<>();
            for (RotationChart rc : rotationCharts) {
                RotationChartIF rotationChartIF = new RotationChartIF();
                BeanUtils.copyProperties(rotationChartIF, rc);

                String url = "https://" + request.getServerName() + request.getContextPath() + "/FileController/viewFileByFileId/" + rc.getImageId();
                rotationChartIF.setImageUrl(url);

                list.add(rotationChartIF);
            }


            return new TableSplitResult<>(pageInfo.getPageNum(), pageInfo.getTotal(), list);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            return null;
        }
    }

}
