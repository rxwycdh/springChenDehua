package org.analysis.projects.archive.service.auto.impl;


import org.analysis.projects.archive.model.auto.UserField;
import org.analysis.projects.archive.mapper.auto.UserFieldMapper;
import org.analysis.projects.archive.service.auto.UserFieldService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;


/**
 * <p>
 * 信息用户字段值 服务实现类
 * </p>
 *
 * @author Feliz
 * @since 2019-09-10
 */
@Service
public class UserFieldServiceImpl extends ServiceImpl<UserFieldMapper, UserField> implements UserFieldService {

}

