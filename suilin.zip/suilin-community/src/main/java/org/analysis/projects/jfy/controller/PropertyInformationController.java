package org.analysis.projects.jfy.controller;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.analysis.projects.jfy.model.auto.PropertyInformation;
import org.analysis.projects.jfy.service.auto.PropertyInformationService;
import org.analysis.system.common.base.BaseController;
import org.analysis.system.common.domain.AjaxResult;
import org.analysis.system.common.domain.TableSplitResult;
import org.analysis.system.common.domain.Tablepar;
import org.analysis.system.common.support.Convert;
import org.analysis.system.model.custom.TitleVo;
import org.analysis.system.util.StringUtils;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

/**
 * <p>
 * 业主决策物业信息表 前端控制器
 * </p>
 *
 * @author Feliz
 * @since 2019-06-29
 */
@Api(tags = {"业主决策物业信息"})
@Controller
@RequestMapping("/jfy/property-information")
public class PropertyInformationController extends BaseController {

    private static Logger logger = LoggerFactory.getLogger(PropertyInformationController.class);

    @Autowired
    private PropertyInformationService propertyInformationService;

    //跳转页面参数
    private String prefix = "projects/jfy/propertyinfo";


    @ApiOperation(value = "跳转业主信息管理页面", notes = "跳转到业主信息页面", hidden = true)
    @GetMapping("view")
    @RequiresPermissions("jfy:propertyinfo:view")
    public String view(Model model) {
        setTitle(model, new TitleVo("业主信息列表", "业主信息管理", false, "", false, false));
        return prefix + "/list";
    }

    @ApiOperation(value = "获取业主信息列表", notes = "获取业主信息列表")
    @PostMapping("list")
    @RequiresPermissions("jfy:propertyinfo:list")
    @ResponseBody
    public TableSplitResult<PropertyInformation> list(Tablepar tablepar, String searchText) {

        QueryWrapper<PropertyInformation> queryWrapper = new QueryWrapper<>();
        if (StringUtils.isNotEmpty(searchText)) {
            queryWrapper.like("proprietor_name", searchText).or().like("house_address", searchText)
                    .or().like("park_address", searchText).or().like("phone", searchText);
        }

        PageHelper.startPage(tablepar.getPageNum(), tablepar.getPageSize());
        List<PropertyInformation> list = propertyInformationService.list(queryWrapper);
        PageInfo<PropertyInformation> pageInfo = new PageInfo<>(list);

        return new TableSplitResult<>(pageInfo.getPageNum(), pageInfo.getTotal(), pageInfo.getList());
    }


    @ApiOperation(value = "跳转新增业主信息页面", notes = "跳转新增业主信息页面", hidden = true)
    @GetMapping("/add")
    public String add() {
        return prefix + "/add";
    }

    @ApiOperation(value = "添加业主信息", notes = "添加新的业主信息")
    @PostMapping("add")
    @RequiresPermissions("jfy:propertyinfo:add")
    @ResponseBody
    public AjaxResult add(PropertyInformation propertyInfo) {
        propertyInfo.setCreateTime(LocalDateTime.now());
        boolean save = propertyInformationService.save(propertyInfo);
        if (save) {
            return success();
        } else {
            return error();
        }
    }

    @ApiOperation(value = "删除业主信息", notes = "根据id删除业主信息（批量）")
    @PostMapping("remove")
    @RequiresPermissions("jfy:propertyinfo:remove")
    @ResponseBody
    public AjaxResult remove(String ids) {
        List<String> idList= Convert.toListStrArray(ids);
        boolean save = propertyInformationService.removeByIds(idList);
        if (save) {
            return success();
        } else {
            return error();
        }
    }


    @ApiOperation(value = "检查业主信息名字是否存在", notes = "传入: name; 返回: 1-存在; 0-不存在")
    @PostMapping("checkNameUnique")
    @ResponseBody
    public Integer checkNameUnique(String proprietorName) {
        QueryWrapper<PropertyInformation> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("proprietor_name", proprietorName);
        List<PropertyInformation> list = propertyInformationService.list(queryWrapper);
        if (list.size() > 0) {
            return 1;
        } else {
            return 0;
        }
    }

    @ApiOperation(value = "跳转业主信息修改页面", notes = "跳转到业主信息修改页面", hidden = true)
    @GetMapping("/edit/{id}")
    public String edit(@PathVariable("id") String id, ModelMap mmap) {
        mmap.put("propertyInfo", propertyInformationService.getById(id));
        return prefix + "/edit";
    }

    @ApiOperation(value = "修改业主信息", notes = "修改保存业主信息")
    @PostMapping("/edit")
    @RequiresPermissions("jfy:propertyinfo:edit")
    @ResponseBody
    public AjaxResult editSave(PropertyInformation propertyInfo) {
        propertyInfo.setUpdateTime(LocalDateTime.now());
        boolean b = propertyInformationService.updateById(propertyInfo);
        return b ? success() : error();
    }
}

