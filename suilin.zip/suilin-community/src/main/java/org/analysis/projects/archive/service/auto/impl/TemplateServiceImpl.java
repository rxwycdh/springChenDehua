package org.analysis.projects.archive.service.auto.impl;

import org.analysis.projects.archive.model.auto.Template;
import org.analysis.projects.archive.mapper.auto.TemplateMapper;
import org.analysis.projects.archive.service.auto.TemplateService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 档案模板 服务实现类
 * </p>
 *
 * @author Feliz
 * @since 2019-09-10
 */
@Service
public class TemplateServiceImpl extends ServiceImpl<TemplateMapper, Template> implements TemplateService {

}
