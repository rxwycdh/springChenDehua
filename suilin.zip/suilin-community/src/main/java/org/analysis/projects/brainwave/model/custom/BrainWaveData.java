package org.analysis.projects.brainwave.model.custom;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * <p>
 * 
 * </p>
 *
 * @author Feliz
 * @since 2019-05-16
 */
@ApiModel(value="BrainWaveData对象", description="脑波数据")
public class BrainWaveData implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "id", example = "0", position = 1, required = true)
    private Integer id;

    /**
     * 时间戳
     */
    @ApiModelProperty(value = "时间戳", required = true)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime time;

    /**
     * 穿戴人
     */
    @ApiModelProperty(value = "穿戴者", required = true)
    private String userName;

    /**
     * 设备名
     */
    @ApiModelProperty(value = "设备名", required = true)
    private String deviceName;

    /**
     * 场景名
     */
    @ApiModelProperty(value = "场景名", required = true)
    private String sceneName;

    /**
     * 信号值
     */
    @ApiModelProperty(value = "信号值", example = "200")
    private Integer pq;

    private Integer delta;

    private Integer theta;

    private Integer lowAlpha;

    private Integer highAlpha;

    private Integer lowBeta;

    private Integer highBeta;

    private Integer lowGamma;

    private Integer middleGamma;

    /**
     * 专注度
     */
    @ApiModelProperty(value = "专注度", example = "0")
    private Integer attention;

    /**
     * 冥想度
     */
    @ApiModelProperty(value = "冥想度", example = "0")
    private Integer meditation;

    /**
     * 创建时间
     */
    @ApiModelProperty(value = "创建时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime createTime;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public LocalDateTime getTime() {
        return time;
    }

    public void setTime(LocalDateTime time) {
        this.time = time;
    }

    public Integer getPq() {
        return pq;
    }

    public void setPq(Integer pq) {
        this.pq = pq;
    }

    public Integer getDelta() {
        return delta;
    }

    public void setDelta(Integer delta) {
        this.delta = delta;
    }

    public Integer getTheta() {
        return theta;
    }

    public void setTheta(Integer theta) {
        this.theta = theta;
    }

    public Integer getLowAlpha() {
        return lowAlpha;
    }

    public void setLowAlpha(Integer lowAlpha) {
        this.lowAlpha = lowAlpha;
    }

    public Integer getHighAlpha() {
        return highAlpha;
    }

    public void setHighAlpha(Integer highAlpha) {
        this.highAlpha = highAlpha;
    }

    public Integer getLowBeta() {
        return lowBeta;
    }

    public void setLowBeta(Integer lowBeta) {
        this.lowBeta = lowBeta;
    }

    public Integer getHighBeta() {
        return highBeta;
    }

    public void setHighBeta(Integer highBeta) {
        this.highBeta = highBeta;
    }

    public Integer getLowGamma() {
        return lowGamma;
    }

    public void setLowGamma(Integer lowGamma) {
        this.lowGamma = lowGamma;
    }

    public Integer getMiddleGamma() {
        return middleGamma;
    }

    public void setMiddleGamma(Integer middleGamma) {
        this.middleGamma = middleGamma;
    }

    public Integer getAttention() {
        return attention;
    }

    public void setAttention(Integer attention) {
        this.attention = attention;
    }

    public Integer getMeditation() {
        return meditation;
    }

    public void setMeditation(Integer meditation) {
        this.meditation = meditation;
    }

    public LocalDateTime getCreateTime() {
        return createTime;
    }

    public void setCreateTime(LocalDateTime createTime) {
        this.createTime = createTime;
    }

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getDeviceName() {
        return deviceName;
    }

    public void setDeviceName(String deviceName) {
        this.deviceName = deviceName;
    }

    public String getSceneName() {
        return sceneName;
    }

    public void setSceneName(String sceneName) {
        this.sceneName = sceneName;
    }

    @Override
    public String toString() {
        return "BrainWaveData{" +
                "id=" + id +
                ", time=" + time +
                ", userName='" + userName + '\'' +
                ", deviceName='" + deviceName + '\'' +
                ", sceneName='" + sceneName + '\'' +
                ", pq=" + pq +
                ", delta=" + delta +
                ", theta=" + theta +
                ", lowAlpha=" + lowAlpha +
                ", highAlpha=" + highAlpha +
                ", lowBeta=" + lowBeta +
                ", highBeta=" + highBeta +
                ", lowGamma=" + lowGamma +
                ", middleGamma=" + middleGamma +
                ", attention=" + attention +
                ", meditation=" + meditation +
                ", createTime=" + createTime +
                '}';
    }
}
