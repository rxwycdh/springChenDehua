package org.analysis.projects.suilin.common.enums;

import io.swagger.annotations.ApiModel;

/**
 * @author ChenDehua  597701764@qq.com
 * @date 2020/8/19 10:13
 */
@ApiModel("帖子统计参数类型枚举")
public enum PostStatisticsEnum {
    /**
     * 1：阅读量
     */
    READ(1, "阅读量"),
    /**
     * 2：点赞量
     */
    LIKE(2, "点赞量"),
    /**
     * 3：评论量
     */
    COMMENT(3, "评论量");


    public Integer type;

    public String value;

    PostStatisticsEnum(Integer type, String value) {
        this.type = type;
        this.value = value;
    }
}
