package org.analysis.projects.brainwave.model.auto;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * <p>
 * gamma脑波数据表
 * </p>
 *
 * @author Feliz
 * @since 2019-06-06
 */
@TableName("brainwave_gamma_data")
@ApiModel(value="GammaData对象", description="gamma脑波数据表")
public class GammaData implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "id", required = true, example = "0", position = 1)
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "穿戴人", example = "0")
    @TableField("user_id")
    private Integer userId;

    @ApiModelProperty(value = "设备id", example = "0")
    @TableField("device_id")
    private Integer deviceId;

    @ApiModelProperty(value = "场景id", example = "0")
    @TableField("scene_id")
    private Integer sceneId;

    @ApiModelProperty(value = "时间戳")
    @TableField("time")
    private LocalDateTime time;

    @ApiModelProperty(value = "信号值", example = "200")
    @TableField("pq")
    private Integer pq;

    @TableField("low_gamma1")
    private Integer lowGamma1;

    @TableField("low_gamma2")
    private Integer lowGamma2;

    @TableField("low_gamma3")
    private Integer lowGamma3;

    @TableField("middle_gamma1")
    private Integer middleGamma1;

    @TableField("middle_gamma2")
    private Integer middleGamma2;

    @TableField("middle_gamma3")
    private Integer middleGamma3;

    @ApiModelProperty(value = "创建时间")
    @TableField("create_time")
    private LocalDateTime createTime;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public Integer getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(Integer deviceId) {
        this.deviceId = deviceId;
    }

    public Integer getSceneId() {
        return sceneId;
    }

    public void setSceneId(Integer sceneId) {
        this.sceneId = sceneId;
    }

    public LocalDateTime getTime() {
        return time;
    }

    public void setTime(LocalDateTime time) {
        this.time = time;
    }

    public Integer getPq() {
        return pq;
    }

    public void setPq(Integer pq) {
        this.pq = pq;
    }

    public Integer getLowGamma1() {
        return lowGamma1;
    }

    public void setLowGamma1(Integer lowGamma1) {
        this.lowGamma1 = lowGamma1;
    }

    public Integer getLowGamma2() {
        return lowGamma2;
    }

    public void setLowGamma2(Integer lowGamma2) {
        this.lowGamma2 = lowGamma2;
    }

    public Integer getLowGamma3() {
        return lowGamma3;
    }

    public void setLowGamma3(Integer lowGamma3) {
        this.lowGamma3 = lowGamma3;
    }

    public Integer getMiddleGamma1() {
        return middleGamma1;
    }

    public void setMiddleGamma1(Integer middleGamma1) {
        this.middleGamma1 = middleGamma1;
    }

    public Integer getMiddleGamma2() {
        return middleGamma2;
    }

    public void setMiddleGamma2(Integer middleGamma2) {
        this.middleGamma2 = middleGamma2;
    }

    public Integer getMiddleGamma3() {
        return middleGamma3;
    }

    public void setMiddleGamma3(Integer middleGamma3) {
        this.middleGamma3 = middleGamma3;
    }

    public LocalDateTime getCreateTime() {
        return createTime;
    }

    public void setCreateTime(LocalDateTime createTime) {
        this.createTime = createTime;
    }

    @Override
    public String toString() {
        return "GammaData{" +
        "id=" + id +
        ", userId=" + userId +
        ", deviceId=" + deviceId +
        ", sceneId=" + sceneId +
        ", time=" + time +
        ", pq=" + pq +
        ", lowGamma1=" + lowGamma1 +
        ", lowGamma2=" + lowGamma2 +
        ", lowGamma3=" + lowGamma3 +
        ", middleGamma1=" + middleGamma1 +
        ", middleGamma2=" + middleGamma2 +
        ", middleGamma3=" + middleGamma3 +
        ", createTime=" + createTime +
        "}";
    }
}
