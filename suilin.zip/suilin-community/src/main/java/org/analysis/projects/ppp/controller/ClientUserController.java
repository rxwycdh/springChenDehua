package org.analysis.projects.ppp.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.analysis.projects.ppp.model.auto.ClientUser;
import org.analysis.projects.ppp.service.auto.ClientUserService;
import org.analysis.system.common.base.BaseController;
import org.analysis.system.common.domain.AjaxResult;
import org.analysis.system.common.domain.TableSplitResult;
import org.analysis.system.common.domain.Tablepar;
import org.analysis.system.common.log.Log;
import org.analysis.system.common.support.Convert;
import org.analysis.system.model.auto.TsysFile;
import org.analysis.system.model.custom.TitleVo;
import org.analysis.system.util.ExcelUtils;
import org.analysis.system.util.StringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.io.InputStream;
import java.io.OutputStream;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;


/**
 * <p>
 * 用户版用户信息 前端控制器
 * </p>
 *
 * @author Feliz
 * @since 2020-03-31 13:40:36
 */
@Controller
@Api(tags = {"用户版用户信息"})
@RequestMapping("/ppp/ClientUserController")
public class ClientUserController extends BaseController{

    private static Logger logger = LoggerFactory.getLogger(ClientUserController.class);

    //跳转页面参数
    private String prefix = "projects/ppp/clientUser";

	@Autowired
	private ClientUserService clientUserService;

	//跳转用户版用户信息页面
    @GetMapping("/view")
    @RequiresPermissions("ppp:clientUser:view")
    public String view(Model model) {
        String str="用户版用户信息";
        setTitle(model, new TitleVo(str+"列表", str+"管理", false, "欢迎进入"+str+"页面", false, false));
        return prefix + "/list";
    }

    @Log(title = "用户版用户信息列表查询", action = "111")
    @ApiOperation(value = "获取用户版用户信息列表", notes = "获取用户版用户信息列表")
    @PostMapping("/list")
    @RequiresPermissions("ppp:clientUser:list")
    @ResponseBody
    public TableSplitResult<ClientUser> list(Tablepar tablepar, String searchText) {

        QueryWrapper<ClientUser> queryWrapper = new QueryWrapper<>();
        if (StringUtils.isNotEmpty(searchText)) {
            queryWrapper.and(wrapper -> wrapper
                    .like("name", searchText).or()
                    .like("openid", searchText).or()
                    .like("unionid", searchText).or()
                    .like("phone_number", searchText).or()
                    .like("wechat", searchText).or()
                    .like("school", searchText).or()
                    .like("major", searchText).or()
                    .like("grade", searchText).or()
                    .like("career_intention", searchText).or()
                    .like("province", searchText).or()
                    .like("city", searchText).or()
                    .like("area", searchText).or()
            );
        }

        PageHelper.startPage(tablepar.getPageNum(), tablepar.getPageSize());
        List<ClientUser> list = clientUserService.list(queryWrapper);
        PageInfo<ClientUser> pageInfo = new PageInfo<ClientUser>(list);

        return new TableSplitResult<>(pageInfo.getPageNum(), pageInfo.getTotal(), pageInfo.getList());
    }

    @ApiOperation(value = "获取全部用户版用户信息信息", notes = "获取全部用户版用户信息信息")
    @PostMapping("/getAllClientUser")
    @ResponseBody
    public AjaxResult<TableSplitResult<ClientUser>> getAllClientUser() {
        try {
            List<ClientUser> list = clientUserService.list();
            return AjaxResult.successDataList(list);
        } catch (Exception e) {
            logger.error(e.toString());
            return AjaxResult.error(e.getMessage());
        }
    }

    //跳转用户版用户信息新增页面
    @GetMapping("/add")
    public String add() {
        return prefix + "/add";
    }

    @Log(title = "用户版用户信息新增", action = "111")
    @ApiOperation(value = "添加用户版用户信息", notes = "添加用户版用户信息")
    @PostMapping("add")
    @RequiresPermissions("ppp:clientUser:add")
    @ResponseBody
    public AjaxResult add(ClientUser clientUser, Integer dataId) {

        //添加文件
        TsysFile record = new TsysFile();
        record.setFileName(clientUser.getName() + "用户端用户头像");
        int fileId = sysFileService.insertSelective(record, dataId);
        clientUser.setAvatarId(fileId);

        clientUser.setCreateTime(LocalDateTime.now());
        boolean save = clientUserService.save(clientUser);
        return save ? success() : error();
    }

    @Log(title = "用户版用户信息删除", action = "111")
    @ApiOperation(value = "删除用户版用户信息", notes = "根据id删除用户版用户信息（可批量）")
    @PostMapping("/remove")
    @RequiresPermissions("ppp:clientUser:remove")
    @ResponseBody
    public AjaxResult remove(String ids) {
        List<Integer> idList= Convert.toListIntArray(ids);
        boolean delete = clientUserService.removeByIds(idList);
        return delete ? success() : error();
    }

    @ApiOperation(value = "检查用户版用户信息是否存在", notes = "返回: 1-存在; 0-不存在")
    @PostMapping("/checkUnique")
    @ResponseBody
    public Integer checkUnique(ClientUser clientUser) {
        QueryWrapper<ClientUser> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("openid", clientUser.getOpenid());
        List<ClientUser> list = clientUserService.list(queryWrapper);
        if (list.size() > 0) {
            return 1;
        } else {
            return 0;
        }
    }

    //跳转用户版用户信息修改页面
    @GetMapping("/edit/{id}")
    public String edit(@PathVariable("id") Integer id, ModelMap mmap) {
        mmap.put("clientUser", clientUserService.getById(id));
        return prefix + "/edit";
    }

    @Log(title = "用户版用户信息修改", action = "111")
    @ApiOperation(value = "修改用户版用户信息", notes = "修改用户版用户信息")
    @PostMapping("/edit")
    @RequiresPermissions("ppp:clientUser:edit")
    @ResponseBody
    public AjaxResult editSave(ClientUser clientUser, Integer dataId) {

        //修改文件
        TsysFile record = sysFileService.selectByPrimaryKey(clientUser.getAvatarId());
        sysFileService.updateByPrimaryKey(record, dataId);

        clientUser.setUpdateTime(LocalDateTime.now());
        boolean edit = clientUserService.updateById(clientUser);
        return edit ? success() : error();
    }


    //跳转用户版用户信息批量新增页面
    @GetMapping("/batchAdd")
    public String batchAdd() {
        return prefix + "/batchAdd";
    }

    @Log(title = "用户版用户信息批量导入", action = "111")
    @ApiOperation(value = "批量导入用户版用户信息", notes = "批量导入用户版用户信息")
    @RequiresPermissions("ppp:clientUser:add")
    @Transactional(propagation = Propagation.REQUIRED)
    @PostMapping("/batchAdd")
    @ResponseBody
    public AjaxResult batchAdd(@RequestParam(value = "file", required = false) MultipartFile file) {
        try {
            String suffer = file.getOriginalFilename().substring(file.getOriginalFilename().indexOf(".") + 1);
            if ("xls".equals(suffer) || "xlsx".equals(suffer)) {
                InputStream in = file.getInputStream();
                Map<String, String> fields = new LinkedHashMap<String, String>();

                fields.put("姓名", "name");
                fields.put("头像图片file_id", "avatarId");
                fields.put("性别；0：未知；1：男性；2：女性", "gender");
                fields.put("年龄", "age");
                fields.put("微信openid", "openid");
                fields.put("微信unionid", "unionid");
                fields.put("手机号码", "phoneNumber");
                fields.put("微信", "wechat");
                fields.put("学校", "school");
                fields.put("专业", "major");
                fields.put("年级", "grade");
                fields.put("职业意向", "careerIntention");
                fields.put("国家", "country");
                fields.put("省份", "province");
                fields.put("城市", "city");
                fields.put("市区", "area");
                fields.put("自我介绍", "introduction");

                List<ClientUser> list = new ArrayList<ClientUser>();
                list = ExcelUtils.ExecltoList(in, ClientUser.class, fields);

                int sum = list.size();//总需导入数
                int successNum = 0;//成功导入数
                int failNum = 0;//失败导入数
                for (ClientUser o : list) {

                    if (checkUnique(o) == 0) {
                        add(o, null);
                        successNum++;
                    }else {
                        failNum++;
                    }
                }

                return success("总需导入数：" + sum + "</br>成功导入数：" + successNum +" </br>失败导入数：" + failNum);
            }
            return error("上传文件格式应为xls或xlsx");

        } catch (Exception e) {
            logger.error(ExceptionUtils.getFullStackTrace(e));
            return error("上传文件模板有误，请对比导入模板！");
        }
    }

    @Log(title = "用户版用户信息导入模板获取", action = "111")
    @GetMapping("/getExcelModel")
    @ResponseBody
    public void getUserCardExcelModel(HttpServletResponse response) throws Exception {
        OutputStream out = null;
        //通过response对象获取outputStream流
        response.setContentType("application/octect-stream"); // 下载文件能正常显示中文
        response.setHeader("Content-Disposition", "attachment;filename=" + new String(("用户版用户信息的导入模板.xls").getBytes("gb2312"), "ISO8859-1"));
        out = response.getOutputStream();

        Map<String, String> fields = new LinkedHashMap<String, String>();

        fields.put("name", "姓名");
        fields.put("avatarId", "头像图片file_id");
        fields.put("gender", "性别；0：未知；1：男性；2：女性");
        fields.put("age", "年龄");
        fields.put("openid", "微信openid");
        fields.put("unionid", "微信unionid");
        fields.put("phoneNumber", "手机号码");
        fields.put("wechat", "微信");
        fields.put("school", "学校");
        fields.put("major", "专业");
        fields.put("grade", "年级");
        fields.put("careerIntention", "职业意向");
        fields.put("country", "国家");
        fields.put("province", "省份");
        fields.put("city", "城市");
        fields.put("area", "市区");
        fields.put("introduction", "自我介绍");

        ExcelUtils.ListtoExecl(null, out, fields);
        out.flush();
        out.close();
    }

	
}
