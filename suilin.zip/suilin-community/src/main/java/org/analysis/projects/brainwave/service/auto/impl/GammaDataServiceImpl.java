package org.analysis.projects.brainwave.service.auto.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.analysis.projects.brainwave.mapper.auto.GammaDataMapper;
import org.analysis.projects.brainwave.model.auto.GammaData;
import org.analysis.projects.brainwave.service.auto.GammaDataService;
import org.springframework.stereotype.Service;

/**
 * <p>
 * gamma脑波数据表 服务实现类
 * </p>
 *
 * @author Feliz
 * @since 2019-06-06
 */
@Service
public class GammaDataServiceImpl extends ServiceImpl<GammaDataMapper, GammaData> implements GammaDataService {

}
