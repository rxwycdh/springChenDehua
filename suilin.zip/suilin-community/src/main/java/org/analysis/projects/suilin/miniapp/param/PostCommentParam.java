package org.analysis.projects.suilin.miniapp.param;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableLogic;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;

/**
 * @author ChenDehua  597701764@qq.com
 * @date 2020/8/19 11:00
 */
@ApiModel("帖子评论参数")
@Data
public class PostCommentParam {

    @ApiModelProperty(value = "所属帖子编号")
    @NotNull
    private Integer postInfoId;

    @ApiModelProperty(value = "用户号")
    @NotNull
    private Integer suilinUserId;

    @ApiModelProperty(value = "评论内容")
    @NotEmpty
    private String comment;

}
