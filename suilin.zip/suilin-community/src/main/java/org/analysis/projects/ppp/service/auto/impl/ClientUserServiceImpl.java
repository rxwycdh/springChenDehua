package org.analysis.projects.ppp.service.auto.impl;

import org.analysis.projects.ppp.model.auto.ClientUser;
import org.analysis.projects.ppp.mapper.auto.ClientUserMapper;
import org.analysis.projects.ppp.service.auto.ClientUserService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 用户版用户信息 服务实现类
 * </p>
 *
 * @author Feliz
 * @since 2020-03-31
 */
@Service
public class ClientUserServiceImpl extends ServiceImpl<ClientUserMapper, ClientUser> implements ClientUserService {

}
