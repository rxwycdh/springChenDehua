package org.analysis.projects.suilin.service.auto.impl;

import org.analysis.projects.suilin.model.auto.Examine;
import org.analysis.projects.suilin.mapper.auto.ExamineMapper;
import org.analysis.projects.suilin.service.auto.ExamineService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 审核信息 服务实现类
 * </p>
 *
 * @author Feliz
 * @since 2020-07-28
 */
@Service
public class ExamineServiceImpl extends ServiceImpl<ExamineMapper, Examine> implements ExamineService {

}
