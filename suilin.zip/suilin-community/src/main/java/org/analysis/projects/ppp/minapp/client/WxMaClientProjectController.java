package org.analysis.projects.ppp.minapp.client;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.analysis.projects.ppp.logic.ProjectTagLogic;
import org.analysis.projects.ppp.model.auto.*;
import org.analysis.projects.ppp.model.custom.ProjectDetailsIF;
import org.analysis.projects.ppp.model.custom.ProjectIF;
import org.analysis.projects.ppp.model.custom.ProjectTypeIF;
import org.analysis.projects.ppp.service.auto.*;
import org.analysis.system.common.base.BaseController;
import org.analysis.system.common.domain.AjaxResult;
import org.analysis.system.common.domain.TableSplitResult;
import org.analysis.system.common.domain.Tablepar;
import org.analysis.system.common.support.Convert;
import org.analysis.system.model.auto.TsysFile;
import org.analysis.system.util.GPSUtil;
import org.analysis.system.util.StringUtils;
import org.apache.commons.beanutils.BeanUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;


@RestController
@Api(tags = {"微信小程序用户版-项目信息接口"})
@RequestMapping("/wx/pppclient/minapp/project")
public class WxMaClientProjectController extends BaseController {

    private static Logger logger = LoggerFactory.getLogger(WxMaClientProjectController.class);

    @Autowired
    private ProjectService projectService;
    @Autowired
    private ProjectTypeService projectTypeService;
    @Autowired
    private ProjectTagLogic projectTagLogic;
    @Autowired
    private ProjectDynamicService projectDynamicService;
    @Autowired
    private ClientUserService clientUserService;
    @Autowired
    private ProjectTagService projectTagService;
    @Autowired
    private UserProjectCollectionService userProjectCollectionService;


    @ApiOperation(value = "获取推荐项目列表", notes = "获取推荐项目列表")
    @PostMapping("/sugglist")
    public TableSplitResult<ProjectIF> sugglist(Tablepar tablepar,
                                                @ApiParam(name = "longitude", value = "用户经度") Double longitude,
                                                @ApiParam(name = "latitude", value = "用户纬度") Double latitude,
                                                @ApiParam(name = "raidusMile", value = "半径距离") int raidusMile) {

        try {
            QueryWrapper<Project> queryWrapper = new QueryWrapper<>();
            queryWrapper.eq("state", 1);
            //筛选raidusMile米距离以内
            if(longitude!=null && latitude!=null) {
                Double[] around = GPSUtil.getAround(longitude, latitude, raidusMile);
                queryWrapper.and(wrapper -> wrapper
                        .between("longitude", around[0], around[2])
                        .between("latitude", around[1], around[3])
                );
            }

            queryWrapper.orderByDesc("weight is null, weight", "create_time is null, create_time");
            PageHelper.startPage(tablepar.getPageNum(), tablepar.getPageSize());
            List<Project> projects = projectService.list(queryWrapper);
            PageInfo<Project> pageInfo = new PageInfo<>(projects);

            List<ProjectIF> list = new ArrayList<>();
            for (Project p : projects) {
                ProjectIF projectIF = new ProjectIF();

                BeanUtils.copyProperties(projectIF, p);

                ProjectType projectType = projectTypeService.getById(p.getTypeId());
                projectIF.setTypeName(projectType!=null ? projectType.getName() : "");

                String tagsName = projectTagLogic.queryProjectTags(p.getId());
                projectIF.setTags(Convert.toListStrArray(tagsName));

                //计算距离
                if(longitude!=null && latitude!=null) {
                    double distance = GPSUtil.distanceByLongNLat(longitude, latitude, p.getLongitude().doubleValue(), p.getLatitude().doubleValue());
                    projectIF.setDistance(String.valueOf(Math.round(distance)));
                }else {
                    projectIF.setDistance("-");
                }

                list.add(projectIF);
            }

            return new TableSplitResult<>(pageInfo.getPageNum(), pageInfo.getTotal(), list);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            return null;
        }
    }

    @ApiOperation(value = "获取项目列表", notes = "获取项目列表")
    @PostMapping("/list")
    public TableSplitResult<ProjectIF> list(Tablepar tablepar,
                                            @ApiParam(name = "longitude", value = "用户经度") Double longitude,
                                            @ApiParam(name = "latitude", value = "用户纬度") Double latitude,
                                            @ApiParam(name = "typeId", value = "项目类型id") Integer typeId,
                                            @ApiParam(name = "searchText", value = "搜索关键词") String searchText) {

        try {
            QueryWrapper<Project> queryWrapper = new QueryWrapper<>();

            if (typeId != null) {
                queryWrapper.eq("type_id", typeId);
            }
            if (StringUtils.isNotEmpty(searchText)) {
                queryWrapper.and(wrapper -> wrapper
                        .like("title", searchText).or()
                        .like("publish_unit", searchText).or()
                        .like("location", searchText).or()
                );
            }

            queryWrapper.eq("state", 1);
            queryWrapper.orderByDesc("create_time is null, create_time");
            PageHelper.startPage(tablepar.getPageNum(), tablepar.getPageSize());
            List<Project> projects = projectService.list(queryWrapper);
            PageInfo<Project> pageInfo = new PageInfo<>(projects);

            List<ProjectIF> list = new ArrayList<>();
            for (Project p : projects) {
                ProjectIF projectIF = new ProjectIF();

                BeanUtils.copyProperties(projectIF, p);

                ProjectType projectType = projectTypeService.getById(p.getTypeId());
                projectIF.setTypeName(projectType!=null ? projectType.getName() : "");

                String tagsName = projectTagLogic.queryProjectTags(p.getId());
                projectIF.setTags(Convert.toListStrArray(tagsName));

                //计算距离
                if(longitude!=null && latitude!=null) {
                    double distance = GPSUtil.distanceByLongNLat(latitude, longitude, p.getLatitude().doubleValue(), p.getLongitude().doubleValue());
                    projectIF.setDistance(String.valueOf(Math.round(distance)));
                }else {
                    projectIF.setDistance("-");
                }

                list.add(projectIF);
            }

            return new TableSplitResult<>(pageInfo.getPageNum(), pageInfo.getTotal(), list);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            return null;
        }
    }

    @ApiOperation(value = "获取全部项目类型", notes = "获取全部项目类型")
    @GetMapping("/getProjectTypes")
    public AjaxResult<List<ProjectTypeIF>> getAllProjectType() {
        try {
            QueryWrapper<ProjectType> queryWrapper = new QueryWrapper<>();
            queryWrapper.orderByAsc("sort=0, sort");
            List<ProjectType> projectTypes = projectTypeService.list(queryWrapper);

            List<ProjectTypeIF> list = new ArrayList<>();
            for (ProjectType pt : projectTypes) {
                ProjectTypeIF projectIF = new ProjectTypeIF();
                BeanUtils.copyProperties(projectIF, pt);

                list.add(projectIF);
            }
            return AjaxResult.successData(list);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            return AjaxResult.error();
        }
    }

    @ApiOperation(value = "根据标签搜索项目", notes = "根据标签搜索项目")
    @PostMapping("/listByTag")
    public TableSplitResult<ProjectIF> listByTag(Tablepar tablepar,
                                            @ApiParam(name = "longitude", value = "用户经度") double longitude,
                                            @ApiParam(name = "latitude", value = "用户纬度") double latitude,
                                            @ApiParam(name = "searchText", value = "标签id") String searchText) {

        try {
            QueryWrapper<ProjectTag> queryWrapper = new QueryWrapper<>();
            queryWrapper.eq("tag_id", searchText);

            List<ProjectTag> projectTags = projectTagService.list(queryWrapper);

            List<Integer> projectIds = new ArrayList<>();
            for (ProjectTag pt : projectTags) {
                projectIds.add(pt.getProjectId());
            }

            QueryWrapper<Project> projectQueryWrapper = new QueryWrapper<>();
            projectQueryWrapper.in("id", projectIds);
            projectQueryWrapper.eq("state", 1);
            projectQueryWrapper.orderByDesc("create_time is null, create_time");
            PageHelper.startPage(tablepar.getPageNum(), tablepar.getPageSize());
            List<Project> projects = projectService.list(projectQueryWrapper);
            PageInfo<Project> pageInfo = new PageInfo<>(projects);

            List<ProjectIF> list = new ArrayList<>();
            for (Project p : projects) {
                ProjectIF projectIF = new ProjectIF();

                BeanUtils.copyProperties(projectIF, p);

                ProjectType projectType = projectTypeService.getById(p.getTypeId());
                projectIF.setTypeName(projectType!=null ? projectType.getName() : "");

                String tagsName = projectTagLogic.queryProjectTags(p.getId());
                projectIF.setTags(Convert.toListStrArray(tagsName));

                //计算距离
                double distance = GPSUtil.distanceByLongNLat(latitude, longitude, p.getLatitude().doubleValue(), p.getLongitude().doubleValue());
                projectIF.setDistance(String.valueOf(Math.round(distance)));

                list.add(projectIF);
            }

            return new TableSplitResult<>(pageInfo.getPageNum(), pageInfo.getTotal(), list);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            return null;
        }
    }

    @ApiOperation(value = "获取项目详情", notes = "获取项目详情")
    @GetMapping("/getOne")
    public AjaxResult<ProjectDetailsIF> getOne(@ApiParam(name = "userId", value = "用户id") Integer userId,
                                               @ApiParam(name = "projectId", value = "项目id") Integer projectId,
                                               @ApiParam(name = "longitude", value = "用户经度") double longitude,
                                               @ApiParam(name = "latitude", value = "用户纬度") double latitude) {

        try {
            ProjectDetailsIF projectDetailsIF = new ProjectDetailsIF();
            Project p = projectService.getById(projectId);
            BeanUtils.copyProperties(projectDetailsIF, p);

            String tagsName = projectTagLogic.queryProjectTags(p.getId());
            projectDetailsIF.setTags(Convert.toListStrArray(tagsName));

            ProjectType projectType = projectTypeService.getById(p.getTypeId());
            projectDetailsIF.setTypeName(projectType!=null ? projectType.getName() : "");

            //计算距离
            double distance = GPSUtil.distanceByLongNLat(latitude, longitude, p.getLatitude().doubleValue(), p.getLongitude().doubleValue());
            projectDetailsIF.setDistance(String.valueOf(Math.round(distance)));

            //判断是否已收藏
            QueryWrapper<UserProjectCollection> queryWrapper = new QueryWrapper<>();
            queryWrapper.eq("user_id", userId);
            queryWrapper.eq("project_id", projectId);
            List<UserProjectCollection> list = userProjectCollectionService.list(queryWrapper);
            if (list.size() > 0) {
                projectDetailsIF.setFavored(true);
            }else {
                projectDetailsIF.setFavored(false);
            }
            //判断是否已报名
            QueryWrapper<ProjectDynamic> dynamicQueryWrapper = new QueryWrapper<>();
            dynamicQueryWrapper.eq("applicant_id", userId).eq("project_id", projectId).last("LIMIT 1");
            ProjectDynamic one = projectDynamicService.getOne(dynamicQueryWrapper);
            if (null != one) {
                projectDetailsIF.setEnrolled(true);
            }else {
                projectDetailsIF.setEnrolled(false);
            }

            return AjaxResult.successData(projectDetailsIF);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            return AjaxResult.error();
        }
    }

    @ApiOperation(value = "项目报名", notes = "项目报名")
    @Transactional
    @GetMapping("/enroll")
    public AjaxResult enroll(ClientUser clientUser, @ApiParam(name = "dataId", value = "文件数据id") Integer dataId,
                             @ApiParam(name = "projectId", value = "项目id") Integer projectId) {

        try {
            if (dataId != null) {
                //修改文件
                TsysFile record = sysFileService.selectByPrimaryKey(clientUser.getAvatarId());
                sysFileService.updateByPrimaryKey(record, dataId);
            }
            //修改用户信息
            clientUser.setUpdateTime(LocalDateTime.now());
            boolean edit = clientUserService.updateById(clientUser);

            //新增报名动态
            ProjectDynamic projectDynamic = new ProjectDynamic();
            projectDynamic.setApplicantId(clientUser.getId());
            projectDynamic.setReplyId(projectService.getById(projectId).getLeaderId());
            projectDynamic.setProjectId(projectId);
            projectDynamic.setState(0);
            projectDynamic.setApplicantTime(LocalDateTime.now());
            boolean save = projectDynamicService.save(projectDynamic);
            return (edit && save) ? success() : error();
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            return AjaxResult.error();
        }

    }

}
