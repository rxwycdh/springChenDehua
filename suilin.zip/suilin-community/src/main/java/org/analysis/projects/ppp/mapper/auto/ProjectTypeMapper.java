package org.analysis.projects.ppp.mapper.auto;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.analysis.projects.ppp.model.auto.ProjectType;
import org.apache.ibatis.annotations.CacheNamespace;

/**
 * <p>
 * 项目类型信息 Mapper 接口
 * </p>
 *
 * @author Feliz
 * @since 2020-04-02
 */
@CacheNamespace(flushInterval = 3600000, size = 4096)
public interface ProjectTypeMapper extends BaseMapper<ProjectType> {

}
