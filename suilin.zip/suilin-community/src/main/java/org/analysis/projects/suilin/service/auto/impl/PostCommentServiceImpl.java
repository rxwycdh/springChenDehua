package org.analysis.projects.suilin.service.auto.impl;

import org.analysis.projects.suilin.model.auto.PostComment;
import org.analysis.projects.suilin.mapper.auto.PostCommentMapper;
import org.analysis.projects.suilin.service.auto.PostCommentService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 帖子评论表 服务实现类
 * </p>
 *
 * @author Feliz
 * @since 2020-08-19
 */
@Service
public class PostCommentServiceImpl extends ServiceImpl<PostCommentMapper, PostComment> implements PostCommentService {

}
