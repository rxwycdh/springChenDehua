package org.analysis.projects.oasystem.service.auto;

import com.baomidou.mybatisplus.extension.service.IService;
import org.analysis.projects.oasystem.model.auto.Position;

/**
 * <p>
 * 职位信息 服务类
 * </p>
 *
 * @author Feliz
 * @since 2019-06-14
 */
public interface PositionService extends IService<Position> {

}
