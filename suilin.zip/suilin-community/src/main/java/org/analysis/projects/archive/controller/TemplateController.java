package org.analysis.projects.archive.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.analysis.projects.archive.model.auto.Field;
import org.analysis.projects.archive.model.auto.Template;
import org.analysis.projects.archive.model.custom.TemplateVO;
import org.analysis.projects.archive.service.auto.FieldService;
import org.analysis.projects.archive.service.auto.TemplateService;
import org.analysis.system.common.base.BaseController;
import org.analysis.system.common.domain.AjaxResult;
import org.analysis.system.common.domain.TableSplitResult;
import org.analysis.system.common.domain.Tablepar;
import org.analysis.system.common.log.Log;
import org.analysis.system.common.support.Convert;
import org.analysis.system.model.custom.TitleVo;
import org.analysis.system.util.StringUtils;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * <p>
 * 信息模板 前端控制器
 * </p>
 *
 * @author Feliz
 * @since 2019-09-10 16:55:35
 */
@Controller
@Api(tags = {"信息模板"})
@RequestMapping("/archive/TemplateController")
public class TemplateController extends BaseController{

    private static Logger logger = LoggerFactory.getLogger(TemplateController.class);

    //跳转页面参数
    private String prefix = "projects/archive/template";

	@Autowired
	private TemplateService templateService;
	@Autowired
    private FieldService fieldService;


    @ApiOperation(value = "跳转信息模板页面", notes = "跳转信息模板页面", hidden = true)
    @GetMapping("/view")
    @RequiresPermissions("archive:template:view")
    public String view(Model model) {
        String str="信息模板";
        setTitle(model, new TitleVo(str+"列表", str+"管理", false, "欢迎进入"+str+"页面", false, false));
        return prefix + "/list";
    }

    @Log(title = "信息模板列表查询", action = "111")
    @ApiOperation(value = "获取信息模板列表", notes = "获取信息模板列表")
    @PostMapping("/list")
    @RequiresPermissions("archive:template:list")
    @ResponseBody
    public TableSplitResult<TemplateVO> list(Tablepar tablepar, String searchText) {

        QueryWrapper<Template> queryWrapper = new QueryWrapper<>();
        if (StringUtils.isNotEmpty(searchText)) {
            queryWrapper.and(wrapper -> wrapper
                    .like("id", searchText).or()
                    .like("template_name", searchText).or()
                    .like("template_img", searchText).or()
                    .like("template_field_ids", searchText).or()
                    .like("description", searchText).or()
            );
        }

        PageHelper.startPage(tablepar.getPageNum(), tablepar.getPageSize());
        List<Template> tempList = templateService.list(queryWrapper);
        PageInfo<Template> pageInfo = new PageInfo<>(tempList);


        List<TemplateVO> list = new ArrayList<>();
        for (Template t : tempList) {
            TemplateVO templateVO = new TemplateVO();
            try {
                BeanUtils.copyProperties(templateVO, t);
            } catch (Exception e) {
                logger.error(e.getMessage());
            }

            List<Field> fields = fieldService.listByIds(t.getTemplateFieldIds());
            List<String> fieldNameList = new ArrayList<>();
            if (fields.size() > 0) {
                for (Field f : fields) {
                    fieldNameList.add(f.getFieldName());
                }
            }

            String templateFields = StringUtils.join(fieldNameList, ",");
            templateVO.setTemplateFields(templateFields);

            list.add(templateVO);
        }


        return new TableSplitResult<>(pageInfo.getPageNum(), pageInfo.getTotal(), list);
    }

    @ApiOperation(value = "跳转新增信息模板页面", notes = "跳转新增信息模板页面", hidden = true)
    @GetMapping("/add")
    public String add() {
        return prefix + "/add";
    }

    @Log(title = "信息模板新增", action = "111")
    @ApiOperation(value = "添加信息模板", notes = "添加信息模板")
    @PostMapping("add")
    @RequiresPermissions("archive:template:add")
    @ResponseBody
    public AjaxResult add(Template template) {
        template.setCreateTime(LocalDateTime.now());
        boolean save = templateService.save(template);
        if (save) {
            return success();
        } else {
            return error();
        }
    }

    @Log(title = "信息模板删除", action = "111")
    @ApiOperation(value = "删除信息模板", notes = "根据id删除信息模板（可批量）")
    @PostMapping("/remove")
    @RequiresPermissions("archive:template:remove")
    @ResponseBody
    public AjaxResult remove(String ids) {
        List<String> idList= Convert.toListStrArray(ids);
        boolean save = templateService.removeByIds(idList);
        if (save) {
            return success();
        } else {
            return error();
        }
    }

    @ApiOperation(value = "检查信息模板是否存在", notes = "返回: 1-存在; 0-不存在")
    @PostMapping("/checkNameUnique")
    @ResponseBody
    public Integer checkNameUnique(Template template) {
        QueryWrapper<Template> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("template_name", template.getTemplateName());
        List<Template> list = templateService.list(queryWrapper);
        if (list.size() > 0) {
            return 1;
        } else {
            return 0;
        }
    }

    @ApiOperation(value = "跳转信息模板修改页面", notes = "跳转信息模板修改页面", hidden = true)
    @GetMapping("/edit/{id}")
    public String edit(@PathVariable("id") String id, ModelMap mmap) {
        mmap.put("template", templateService.getById(id));
        return prefix + "/edit";
    }

    @Log(title = "信息模板修改", action = "111")
    @ApiOperation(value = "修改信息模板", notes = "修改信息模板")
    @PostMapping("/edit")
    @RequiresPermissions("archive:template:edit")
    @ResponseBody
    public AjaxResult editSave(Template template) {
        template.setUpdateTime(LocalDateTime.now());
        boolean b = templateService.updateById(template);
        return b ? success() : error();
    }

	
}
