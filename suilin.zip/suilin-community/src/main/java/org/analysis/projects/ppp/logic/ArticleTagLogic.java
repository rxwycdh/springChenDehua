package org.analysis.projects.ppp.logic;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import org.analysis.projects.ppp.model.auto.ArticleTag;
import org.analysis.projects.ppp.model.auto.Tag;
import org.analysis.projects.ppp.service.auto.ArticleTagService;
import org.analysis.projects.ppp.service.auto.TagService;
import org.analysis.system.common.support.Convert;
import org.analysis.system.util.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Service
public class ArticleTagLogic {

    @Autowired
    private TagService tagService;
    @Autowired
    private ArticleTagService articleTagService;

    /**
     * 查询文章标签信息
     * @param articleId 文章id
     * @return
     */
    public String queryArticleTags(Integer articleId) {

        QueryWrapper<ArticleTag> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("article_id", articleId);
        List<ArticleTag> list = articleTagService.list(queryWrapper);

        List<Tag> tagList = new ArrayList<>();
        for (ArticleTag at : list) {
            tagList.add(tagService.getById(at.getTagId()));
        }

        List<String> tagsName = new ArrayList<>();
        for (Tag tag : tagList) {
            tagsName.add(tag.getName());
        }

        return String.join(",", tagsName);
    }

    /**
     * 新增文章标签（通过新增中间表数据）
     * @param articleId 文章id
     * @param tagsName 标签名字符串，逗号隔开
     * @throws Exception
     */
    public void addArticleTags(Integer articleId, String tagsName) throws Exception{

        if (StringUtils.isEmpty(tagsName)) {
            return;
        }
        List<String> tagsNameList = Convert.toListStrArray(tagsName);

        for (String tagName : tagsNameList) {
            ArticleTag articleTag = new ArticleTag();
            articleTag.setArticleId(articleId);

            QueryWrapper<Tag> queryWrapper = new QueryWrapper<>();
            queryWrapper.eq("name", tagName);
            Tag tag = tagService.getOne(queryWrapper);

            //标签已存在则直接新增中间表数据，否则新增标签以及中间表数据
            if (tag != null) {
                articleTag.setTagId(tag.getId());
                boolean save = articleTagService.save(articleTag);
                if (!save) {
                    throw new Exception("新增文章标签中间表数据出错");
                }
            }else {
                tag = new Tag();
                tag.setName(tagName);
                tag.setCreateTime(LocalDateTime.now());
                boolean save = tagService.save(tag);
                if (!save) {
                    throw new Exception("新增标签数据出错");
                }

                articleTag.setTagId(tag.getId());
                boolean save2 = articleTagService.save(articleTag);
                if (!save2) {
                    throw new Exception("新增文章标签中间表数据出错");
                }
            }

        }
    }


    /**
     * 删除文章标签（通过删除中间表数据）
     * @param articleId 文章id
     * @throws Exception
     */
    public void removeArticleTags(Integer articleId) throws Exception{

        QueryWrapper<ArticleTag> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("article_id", articleId);
        boolean remove = articleTagService.remove(queryWrapper);

        if (!remove) {
            throw new Exception("删除文章标签中间表数据出错");
        }
    }
}
