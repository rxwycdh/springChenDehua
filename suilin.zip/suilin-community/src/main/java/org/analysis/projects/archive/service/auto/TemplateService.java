package org.analysis.projects.archive.service.auto;

import org.analysis.projects.archive.model.auto.Template;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 档案模板 服务类
 * </p>
 *
 * @author Feliz
 * @since 2019-09-10
 */
public interface TemplateService extends IService<Template> {

}
