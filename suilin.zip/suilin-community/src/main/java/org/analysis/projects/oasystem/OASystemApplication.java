package org.analysis.projects.oasystem;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * 脑波项目启动器
 */
@MapperScan(value = "org.analysis.projects.oasystem.mapper")
@SpringBootApplication
public class OASystemApplication {

    public static void main(String[] args) {
        SpringApplication.run(OASystemApplication.class, args);
        System.out.println("=================================");
        System.out.println("==========脑波项目启动成功==========");
        System.out.println("=================================");
    }
}
