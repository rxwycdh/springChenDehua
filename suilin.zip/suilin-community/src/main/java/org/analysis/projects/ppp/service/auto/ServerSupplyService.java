package org.analysis.projects.ppp.service.auto;

import org.analysis.projects.ppp.model.auto.ServerSupply;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 服务版服务商信息 服务类
 * </p>
 *
 * @author Feliz
 * @since 2020-04-23
 */
public interface ServerSupplyService extends IService<ServerSupply> {

}
