package org.analysis.projects.ppp.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.analysis.projects.ppp.model.auto.ServiceType;
import org.analysis.projects.ppp.service.auto.ServiceTypeService;
import org.analysis.system.common.base.BaseController;
import org.analysis.system.common.domain.AjaxResult;
import org.analysis.system.common.domain.TableSplitResult;
import org.analysis.system.common.domain.Tablepar;
import org.analysis.system.common.log.Log;
import org.analysis.system.common.support.Convert;
import org.analysis.system.model.custom.TitleVo;
import org.analysis.system.util.ExcelUtils;
import org.analysis.system.util.StringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.io.InputStream;
import java.io.OutputStream;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;


/**
 * <p>
 * 服务分类 前端控制器
 * </p>
 *
 * @author Feliz
 * @since 2020-04-23 17:52:40
 */
@Controller
@Api(tags = {"服务分类"})
@RequestMapping("/ppp/ServiceTypeController")
public class ServiceTypeController extends BaseController{

    private static Logger logger = LoggerFactory.getLogger(ServiceTypeController.class);

    //跳转页面参数
    private String prefix = "projects/ppp/serviceType";

	@Autowired
	private ServiceTypeService serviceTypeService;

	//跳转服务分类页面
    @GetMapping("/view")
    @RequiresPermissions("ppp:serviceType:view")
    public String view(Model model) {
        String str="服务分类";
        setTitle(model, new TitleVo(str+"列表", str+"管理", false, "欢迎进入"+str+"页面", false, false));
        return prefix + "/list";
    }

    @Log(title = "服务分类列表查询", action = "111")
    @ApiOperation(value = "获取服务分类列表", notes = "获取服务分类列表")
    @PostMapping("/list")
    @RequiresPermissions("ppp:serviceType:list")
    @ResponseBody
    public TableSplitResult<ServiceType> list(Tablepar tablepar, String searchText) {

        QueryWrapper<ServiceType> queryWrapper = new QueryWrapper<>();
        if (StringUtils.isNotEmpty(searchText)) {
            queryWrapper.and(wrapper -> wrapper
                    .like("name", searchText).or()
                    .like("descripion", searchText).or()
            );
        }
        queryWrapper.orderByAsc("sort=0, sort");

        PageHelper.startPage(tablepar.getPageNum(), tablepar.getPageSize());
        List<ServiceType> list = serviceTypeService.list(queryWrapper);
        PageInfo<ServiceType> pageInfo = new PageInfo<ServiceType>(list);

        return new TableSplitResult<>(pageInfo.getPageNum(), pageInfo.getTotal(), pageInfo.getList());
    }

    @ApiOperation(value = "获取全部服务分类信息", notes = "获取全部服务分类信息")
    @PostMapping("/getAllServiceType")
    @ResponseBody
    public AjaxResult<TableSplitResult<ServiceType>> getAllServiceType() {
        try {
            QueryWrapper<ServiceType> queryWrapper = new QueryWrapper<>();
            queryWrapper.orderByAsc("sort=0, sort");
            List<ServiceType> list = serviceTypeService.list(queryWrapper);

            for (int i = 0; i < list.size(); i++) {
                if (0 == list.get(i).getType()) {
                    list.get(i).setDescripion("one");
                }else if (1 == list.get(i).getType()) {
                    list.get(i).setDescripion("two");
                }else {
                    list.get(i).setDescripion("third");
                }
            }
            return AjaxResult.successDataList(list);
        } catch (Exception e) {
            logger.error(e.toString());
            return AjaxResult.error(e.getMessage());
        }
    }

    //跳转服务分类新增页面
    @GetMapping("/add")
    public String add() {
        return prefix + "/add";
    }

    @Log(title = "服务分类新增", action = "111")
    @ApiOperation(value = "添加服务分类", notes = "添加服务分类")
    @PostMapping("add")
    @RequiresPermissions("ppp:serviceType:add")
    @ResponseBody
    public AjaxResult add(ServiceType serviceType) {

        serviceType.setCreateTime(LocalDateTime.now());
        boolean save = serviceTypeService.save(serviceType);
        return save ? success() : error();
    }

    @Log(title = "服务分类删除", action = "111")
    @ApiOperation(value = "删除服务分类", notes = "根据id删除服务分类（可批量）")
    @PostMapping("/remove")
    @RequiresPermissions("ppp:serviceType:remove")
    @ResponseBody
    public AjaxResult remove(String ids) {
        List<Integer> idList= Convert.toListIntArray(ids);
        boolean delete = serviceTypeService.removeByIds(idList);
        return delete ? success() : error();
    }

    @ApiOperation(value = "检查服务分类是否存在", notes = "返回: 1-存在; 0-不存在")
    @PostMapping("/checkUnique")
    @ResponseBody
    public Integer checkUnique(ServiceType serviceType) {
        QueryWrapper<ServiceType> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("name", serviceType.getName());
        List<ServiceType> list = serviceTypeService.list(queryWrapper);
        if (list.size() > 0) {
            return 1;
        } else {
            return 0;
        }
    }

    //跳转服务分类修改页面
    @GetMapping("/edit/{id}")
    public String edit(@PathVariable("id") Integer id, ModelMap modelMap) {
        modelMap.put("serviceType", serviceTypeService.getById(id));
        return prefix + "/edit";
    }

    @Log(title = "服务分类修改", action = "111")
    @ApiOperation(value = "修改服务分类", notes = "修改服务分类")
    @PostMapping("/edit")
    @RequiresPermissions("ppp:serviceType:edit")
    @ResponseBody
    public AjaxResult editSave(ServiceType serviceType) {
        if (serviceType.getType() != 2) {
            QueryWrapper<ServiceType> queryWrapper = new QueryWrapper<>();
            queryWrapper.eq("pid", serviceType.getId());
            List<ServiceType> list = serviceTypeService.list(queryWrapper);
            for (ServiceType st : list) {
                st.setSort(serviceType.getSort());
                editSave(st);
            }

        }

        serviceType.setUpdateTime(LocalDateTime.now());
        boolean edit = serviceTypeService.updateById(serviceType);
        return edit ? success() : error();
    }

    //获取父分类
    @PostMapping("/getParentServiceType/{type}")
    @ResponseBody
    public AjaxResult<List<ServiceType>> getParentServiceType(@PathVariable("type") Integer type, Integer id){

        if (type == 0) {
            return AjaxResult.successData(new ArrayList<>());
        }
        QueryWrapper<ServiceType> queryWrapper = new QueryWrapper<>();
        if ((id != null) && (id != 0)) {
            queryWrapper.ne("id", id);
        }
        queryWrapper.eq("type", type-1);
        queryWrapper.orderByAsc("sort=0, sort");
        List<ServiceType> list = serviceTypeService.list(queryWrapper);

        return AjaxResult.successData(list);
    }

    //跳转服务分类批量新增页面
    @GetMapping("/batchAdd")
    public String batchAdd() {
        return prefix + "/batchAdd";
    }

    @Log(title = "服务分类批量导入", action = "111")
    @ApiOperation(value = "批量导入服务分类", notes = "批量导入服务分类")
    @RequiresPermissions("ppp:serviceType:add")
    @Transactional(propagation = Propagation.REQUIRED)
    @PostMapping("/batchAdd")
    @ResponseBody
    public AjaxResult batchAdd(@RequestParam(value = "file", required = false) MultipartFile file) {
        try {
            String suffer = file.getOriginalFilename().substring(file.getOriginalFilename().indexOf(".") + 1);
            if ("xls".equals(suffer) || "xlsx".equals(suffer)) {
                InputStream in = file.getInputStream();
                Map<String, String> fields = new LinkedHashMap<String, String>();

                fields.put("类型名称", "name");
                fields.put("排序", "sort");
                fields.put("父节点id", "pid");
                fields.put("类型 0：一级分类；1：二级分类；2：三级分类", "type");
                fields.put("描述", "descripion");

                List<ServiceType> list = new ArrayList<ServiceType>();
                list = ExcelUtils.ExecltoList(in, ServiceType.class, fields);

                int sum = list.size();//总需导入数
                int successNum = 0;//成功导入数
                int failNum = 0;//失败导入数
                for (ServiceType o : list) {

                    if (checkUnique(o) == 0) {
                        add(o);
                        successNum++;
                    }else {
                        failNum++;
                    }
                }

                return success("总需导入数：" + sum + "</br>成功导入数：" + successNum +" </br>失败导入数：" + failNum);
            }
            return error("上传文件格式应为xls或xlsx");

        } catch (Exception e) {
            logger.error(ExceptionUtils.getFullStackTrace(e));
            return error("上传文件模板有误，请对比导入模板！");
        }
    }

    @Log(title = "服务分类导入模板获取", action = "111")
    @GetMapping("/getExcelModel")
    @ResponseBody
    public void getUserCardExcelModel(HttpServletResponse response) throws Exception {
        OutputStream out = null;
        //通过response对象获取outputStream流
        response.setContentType("application/octect-stream"); // 下载文件能正常显示中文
        response.setHeader("Content-Disposition", "attachment;filename=" + new String(("服务分类的导入模板.xls").getBytes("gb2312"), "ISO8859-1"));
        out = response.getOutputStream();

        Map<String, String> fields = new LinkedHashMap<String, String>();

        fields.put("name", "类型名称");
        fields.put("sort", "排序");
        fields.put("pid", "父节点id");
        fields.put("type", "类型 0：一级分类；1：二级分类；2：三级分类");
        fields.put("descripion", "描述");

        ExcelUtils.ListtoExecl(null, out, fields);
        out.flush();
        out.close();
    }


}
