package org.analysis.projects.ppp.mapper.auto;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.analysis.projects.ppp.model.auto.ClientUser;
import org.apache.ibatis.annotations.CacheNamespace;

/**
 * <p>
 * 用户版用户信息 Mapper 接口
 * </p>
 *
 * @author Feliz
 * @since 2020-03-31
 */
@CacheNamespace(flushInterval = 3600000, size = 4096)
public interface ClientUserMapper extends BaseMapper<ClientUser> {

}
