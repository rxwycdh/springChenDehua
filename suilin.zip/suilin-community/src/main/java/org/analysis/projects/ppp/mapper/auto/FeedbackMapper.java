package org.analysis.projects.ppp.mapper.auto;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.analysis.projects.ppp.model.auto.Feedback;
import org.apache.ibatis.annotations.CacheNamespace;

/**
 * <p>
 * 反馈信息 Mapper 接口
 * </p>
 *
 * @author Feliz
 * @since 2020-04-01
 */
@CacheNamespace(flushInterval = 3600000, size = 4096)
public interface FeedbackMapper extends BaseMapper<Feedback> {

}
