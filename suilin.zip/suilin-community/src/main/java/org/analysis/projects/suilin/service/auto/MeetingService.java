package org.analysis.projects.suilin.service.auto;

import org.analysis.projects.suilin.model.auto.Meeting;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 会议纪要 服务类
 * </p>
 *
 * @author Feliz
 * @since 2020-07-28
 */
public interface MeetingService extends IService<Meeting> {

}
