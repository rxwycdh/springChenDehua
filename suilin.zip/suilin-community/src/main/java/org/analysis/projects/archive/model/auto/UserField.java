package org.analysis.projects.archive.model.auto;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;

/**
 * <p>
 * 信息用户字段值
 * </p>
 *
 * @author Feliz
 * @since 2019-09-10
 */
@TableName("archive_user_field")
@ApiModel(value="UserField对象", description="信息用户字段值")
public class UserField implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "用户id")
    @TableField("user_id")
    private Integer userId;

    @ApiModelProperty(value = "字段id")
    @TableField("field_id")
    private Integer fieldId;

    @ApiModelProperty(value = "值")
    @TableField("value")
    private String value;

    public UserField() {
    }

    public UserField(Integer userId, Integer fieldId, String value) {
        this.userId = userId;
        this.fieldId = fieldId;
        this.value = value;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public Integer getFieldId() {
        return fieldId;
    }

    public void setFieldId(Integer fieldId) {
        this.fieldId = fieldId;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    @Override
    public String toString() {
        return "UserField{" +
        "id=" + id +
        ", userId=" + userId +
        ", fieldId=" + fieldId +
        ", value=" + value +
        "}";
    }
}
