package org.analysis.projects.ppp.mapper.auto;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.analysis.projects.ppp.model.auto.ProjectDynamic;
import org.apache.ibatis.annotations.CacheNamespace;

/**
 * <p>
 * 项目动态信息 Mapper 接口
 * </p>
 *
 * @author Feliz
 * @since 2020-04-05
 */
@CacheNamespace(flushInterval = 3600000, size = 4096)
public interface ProjectDynamicMapper extends BaseMapper<ProjectDynamic> {

}
