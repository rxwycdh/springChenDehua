package org.analysis.projects.suilin.service.auto;

import org.analysis.projects.suilin.model.auto.PostCommentReply;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 评论回复表 服务类
 * </p>
 *
 * @author Feliz
 * @since 2020-08-19
 */
public interface PostCommentReplyService extends IService<PostCommentReply> {

}
