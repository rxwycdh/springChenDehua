package org.analysis.projects.ppp.service.auto.impl;

import org.analysis.projects.ppp.model.auto.Article;
import org.analysis.projects.ppp.mapper.auto.ArticleMapper;
import org.analysis.projects.ppp.service.auto.ArticleService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 文章信息表 服务实现类
 * </p>
 *
 * @author Feliz
 * @since 2020-03-29
 */
@Service
public class ArticleServiceImpl extends ServiceImpl<ArticleMapper, Article> implements ArticleService {

}
