package org.analysis.projects.suilin.service.auto.impl;

import org.analysis.projects.suilin.model.auto.Meeting;
import org.analysis.projects.suilin.mapper.auto.MeetingMapper;
import org.analysis.projects.suilin.service.auto.MeetingService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 会议纪要 服务实现类
 * </p>
 *
 * @author Feliz
 * @since 2020-07-28
 */
@Service
public class MeetingServiceImpl extends ServiceImpl<MeetingMapper, Meeting> implements MeetingService {

}
