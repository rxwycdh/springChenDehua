package org.analysis.projects.brainwave.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import org.analysis.projects.brainwave.model.auto.*;
import org.analysis.projects.brainwave.model.custom.BrainWaveData;
import org.analysis.projects.brainwave.model.custom.DataQueryCondition;
import org.analysis.projects.brainwave.service.auto.*;
import org.analysis.projects.brainwave.service.custom.BrainWaveDataService;
import org.analysis.projects.brainwave.util.EEGUtil;
import org.analysis.system.common.base.BaseController;
import org.analysis.system.common.domain.AjaxResult;
import org.analysis.system.common.domain.TableSplitResult;
import org.analysis.system.common.domain.Tablepar;
import org.analysis.system.model.auto.TsysFile;
import org.analysis.system.model.custom.TitleVo;
import org.analysis.system.util.LocalDateTimeUtils;
import org.analysis.system.util.StringUtils;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * <p>
 * 前端控制器
 * </p>
 *
 * @author Feliz
 * @since 2019-05-10
 */
@Controller
@Api(tags = {"脑波数据"}, position = 1)
@RequestMapping("/brainwave/DataController")
public class DataController extends BaseController {
    private static Logger logger = LoggerFactory.getLogger(DataController.class);

    @Autowired
    private RawDataService rawDataService;
    @Autowired
    private AlphaDataService alphaDataService;
    @Autowired
    private BetaDataService betaDataService;
    @Autowired
    private DeltaDataService deltaDataService;
    @Autowired
    private GammaDataService gammaDataService;
    @Autowired
    private ThetaDataService thetaDataService;
    @Autowired
    private OtherDataService otherDataService;
    @Autowired
    private EegDeviceService eegDeviceService;
    @Autowired
    private EegUserService eegUserService;
    @Autowired
    private EegSceneService eegSceneService;
    @Autowired
    private BrainWaveDataService brainWaveDataService;

    //跳转页面参数
    private String prefix = "projects/brainwave/data";

    @ApiOperation(value = "跳转脑波列表页面", notes = "跳转脑波数据列表页面", hidden = true)
    @GetMapping("view")
    @RequiresPermissions("brainwave:data:view")
    public String view(Model model) {
        setTitle(model, new TitleVo("脑波数据", "脑波展示", false, "欢迎进入脑波展示页面", false, false));
        return prefix + "/list";
    }

    @ApiOperation(value = "跳转脑波图表页面", notes = "跳转脑波图表页面", hidden = true)
    @GetMapping("chart")
    @RequiresPermissions("brainwave:data:chart")
    public String chart(Model model) {
        setTitle(model, new TitleVo("脑波图表", "脑波展示", false, "欢迎进入脑波展示页面", false, false));
        return prefix + "/chart";
    }


    @ApiOperation(value = "跳转上传数据页面", notes = "跳转上传数据页面", hidden = true)
    @GetMapping("/add")
    public String add() {
        return prefix + "/import";
    }


    @ApiOperation(value = "上传脑波数据", notes = "上传脑波数据并自动分割数据（异步执行）")
    @ApiImplicitParam(name = "dataId", value = "文件id")
    @PostMapping("add")
    @RequiresPermissions("brainwave:data:add")
    @ResponseBody
    public AjaxResult add(TsysFile file, Integer dataId, DataQueryCondition dataQueryCondition) {
        try {
            if (dataId == null) {
                return error("数据文件为空");
            }
            int b = sysFileService.insertSelective(file, dataId);
            if (b > 0) {
                ArrayList<String> datas = brainWaveDataService.splitDataFile(dataId);
                brainWaveDataService.saveBatchRawData(datas, dataQueryCondition);

                return success("数据上传成功");
            } else {
                logger.error("数据文件为空");
                return error("数据文件为空");
            }
        } catch (Exception e) {
            logger.error("分割脑波数据出错--" + ExceptionUtils.getFullStackTrace(e));
            return error("分割脑波数据出错"); //返回你自己的错误信息
        }
    }

    @ApiOperation(value = "获取脑波列表数据", notes = "获取脑波列表数据")
    @PostMapping("list")
    @RequiresPermissions("brainwave:data:list")
    @ResponseBody
    public TableSplitResult<BrainWaveData> list(Tablepar tablepar, String searchText, DataQueryCondition dataQueryCondition) {

        QueryWrapper queryWrapper = new QueryWrapper<>();

        if (StringUtils.isEmpty(searchText)) {
            searchText = "";
        }

        if (dataQueryCondition.getEegUser() != null) {
            queryWrapper.eq("user_id", dataQueryCondition.getEegUser());
        }

        if (dataQueryCondition.getEegDevice() != null) {
            queryWrapper.eq("device_id", dataQueryCondition.getEegDevice());
        }

        if (dataQueryCondition.getEegScene() != null) {
            queryWrapper.eq("scene_id", dataQueryCondition.getEegScene());
        }

        if (dataQueryCondition.getStartTime() != null || dataQueryCondition.getEndTime() != null) {
            if (dataQueryCondition.getStartTime() != null) {
                queryWrapper.ge("time", dataQueryCondition.getStartTime());
            } else if (dataQueryCondition.getEndTime() != null) {
                queryWrapper.le("time", dataQueryCondition.getEndTime());
            } else {
                queryWrapper.between("time", dataQueryCondition.getStartTime(), dataQueryCondition.getEndTime());
            }
        }

        //time is null，time字段为空时排最后
        queryWrapper.orderByAsc("user_id is null, user_id", "device_id is null, device_id", "time is null, time");

        PageHelper.startPage(tablepar.getPageNum(), tablepar.getPageSize());
        PageInfo<AlphaData> alphaDataIPage = new PageInfo<AlphaData>(alphaDataService.list(queryWrapper));
        PageHelper.startPage(tablepar.getPageNum(), tablepar.getPageSize());
        PageInfo<BetaData> betaDataIPage = new PageInfo<BetaData>(betaDataService.list(queryWrapper));
        PageHelper.startPage(tablepar.getPageNum(), tablepar.getPageSize());
        PageInfo<DeltaData> deltaDataIPage = new PageInfo<DeltaData>(deltaDataService.list(queryWrapper));
        PageHelper.startPage(tablepar.getPageNum(), tablepar.getPageSize());
        PageInfo<GammaData> gammaDataIPage = new PageInfo<GammaData>(gammaDataService.list(queryWrapper));
        PageHelper.startPage(tablepar.getPageNum(), tablepar.getPageSize());
        PageInfo<ThetaData> thetaDataIPage = new PageInfo<ThetaData>(thetaDataService.list(queryWrapper));
        PageHelper.startPage(tablepar.getPageNum(), tablepar.getPageSize());
        PageInfo<OtherData> otherDataIPage = new PageInfo<OtherData>(otherDataService.list(queryWrapper));


        List<BrainWaveData> brainwaveList = new ArrayList<>();
        try {
            BrainWaveData brainWaveData = null;
            for (int i = 0; i < otherDataIPage.getList().size(); i++) {
                brainWaveData = new BrainWaveData();

                if (alphaDataIPage.getList().size() > i) {
                    AlphaData data = alphaDataIPage.getList().get(i);
                    if (data.getTime().toString().equals(otherDataIPage.getList().get(i).getTime().toString())) {
                        int lowAlpha = EEGUtil.getEEGPower(data.getLowAlpha1(), data.getLowAlpha2(), data.getLowAlpha3());
                        int highAlpha = EEGUtil.getEEGPower(data.getHighAlpha1(), data.getHighAlpha2(), data.getLowAlpha3());
                        brainWaveData.setLowAlpha(lowAlpha);
                        brainWaveData.setHighAlpha(highAlpha);
                    }
                }
                if (betaDataIPage.getList().size() > i) {
//                    BeanUtils.copyProperties(brainWaveData,betaDataIPage.getRecords().get(i));
                    BetaData data = betaDataIPage.getList().get(i);
                    if (data.getTime().toString().equals(otherDataIPage.getList().get(i).getTime().toString())) {
                        int lowBeta = EEGUtil.getEEGPower(data.getLowBeta1(), data.getLowBeta2(), data.getLowBeta3());
                        int highBeta = EEGUtil.getEEGPower(data.getHighBeta1(), data.getHighBeta2(), data.getHighBeta3());
                        brainWaveData.setLowBeta(lowBeta);
                        brainWaveData.setHighBeta(highBeta);
                    }
                }
                if (deltaDataIPage.getList().size() > i) {
//                    BeanUtils.copyProperties(brainWaveData,deltaDataIPage.getRecords().get(i));
                    DeltaData data = deltaDataIPage.getList().get(i);
                    if (data.getTime().toString().equals(otherDataIPage.getList().get(i).getTime().toString())) {
                        int delta = EEGUtil.getEEGPower(data.getDelta1(), data.getDelta2(), data.getDelta3());
                        brainWaveData.setDelta(delta);
                    }
                }
                if (gammaDataIPage.getList().size() > i) {
//                    BeanUtils.copyProperties(brainWaveData,gammaDataIPage.getRecords().get(i));
                    GammaData data = gammaDataIPage.getList().get(i);
                    if (data.getTime().toString().equals(otherDataIPage.getList().get(i).getTime().toString())) {
                        int lowGamma = EEGUtil.getEEGPower(data.getLowGamma1(), data.getLowGamma2(), data.getLowGamma3());
                        int middleGamma = EEGUtil.getEEGPower(data.getMiddleGamma1(), data.getMiddleGamma2(), data.getMiddleGamma3());
                        brainWaveData.setLowGamma(lowGamma);
                        brainWaveData.setMiddleGamma(middleGamma);
                    }
                }
                if (thetaDataIPage.getList().size() > i) {
//                    BeanUtils.copyProperties(brainWaveData,thetaDataIPage.getRecords().get(i));
                    ThetaData data = thetaDataIPage.getList().get(i);
                    if (data.getTime().toString().equals(otherDataIPage.getList().get(i).getTime().toString())) {
                        int theta = EEGUtil.getEEGPower(data.getTheta1(), data.getTheta2(), data.getTheta3());
                        brainWaveData.setTheta(theta);
                    }
                }
                if (otherDataIPage.getList().size() > i) {
                    //把一个类的属性值赋值给另一个类的相同的属性
                    BeanUtils.copyProperties(brainWaveData, otherDataIPage.getList().get(i));

                    EegUser eegUser = eegUserService.getById(otherDataIPage.getList().get(i).getUserId());
                    brainWaveData.setUserName(eegUser.getUserName());
                    EegDevice eegDevice = eegDeviceService.getById(otherDataIPage.getList().get(i).getDeviceId());
                    brainWaveData.setDeviceName(eegDevice.getDeviceName());
                    EegScene eegScene = eegSceneService.getById(otherDataIPage.getList().get(i).getSceneId());
                    brainWaveData.setSceneName(eegScene.getSceneName());
                }

                brainwaveList.add(brainWaveData);
            }

        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.toString());
        }

        return new TableSplitResult<BrainWaveData>((int) otherDataIPage.getPageNum(), otherDataIPage.getTotal(), brainwaveList);
    }


    @ApiOperation(value = "获取脑波图表数据", notes = "获取脑波图表数据")
    @PostMapping("getbwdata")
    @ResponseBody
    public Map<String, List> getBwData(DataQueryCondition dataQueryCondition) {

        QueryWrapper queryWrapper = new QueryWrapper();
        //展示条件
        if (dataQueryCondition.getEegUser() == null && dataQueryCondition.getEegDevice() == null &&
                dataQueryCondition.getStartTime() == null && dataQueryCondition.getEndTime() == null) {
            return null;
        }

        if (dataQueryCondition.getEegUser() != null) {

            queryWrapper.eq("user_id", dataQueryCondition.getEegUser());
        }

        if (dataQueryCondition.getEegDevice() != null) {
            queryWrapper.eq("device_id", dataQueryCondition.getEegDevice());
        }

        if (dataQueryCondition.getEegScene() != null) {
            queryWrapper.eq("scene_id", dataQueryCondition.getEegScene());
        }

        if (dataQueryCondition.getStartTime() != null && dataQueryCondition.getStartTime() != null) {
            queryWrapper.between("time", dataQueryCondition.getStartTime(), dataQueryCondition.getEndTime());
        }

        //time is null，time字段为空时排最后
        queryWrapper.orderByAsc("time is null, time");

        List<AlphaData> alphaDataIPage = alphaDataService.list(queryWrapper);
        List<BetaData> betaDataIPage = betaDataService.list(queryWrapper);
        List<DeltaData> deltaDataIPage = deltaDataService.list(queryWrapper);
        List<GammaData> gammaDataIPage = gammaDataService.list(queryWrapper);
        List<ThetaData> thetaDataIPage = thetaDataService.list(queryWrapper);
        List<OtherData> otherDataIPage = otherDataService.list(queryWrapper);

        Map<String, List> brainwaveMap = new HashMap<>();

        //计算EEG值
        List lowAlphaDataList = new ArrayList();
        List highAlphaDataList = new ArrayList();
        for (AlphaData data : alphaDataIPage) {
            int lowAlpha = EEGUtil.getEEGPower(data.getLowAlpha1(), data.getLowAlpha2(), data.getLowAlpha3());
            int highAlpha = EEGUtil.getEEGPower(data.getHighAlpha1(), data.getHighAlpha2(), data.getLowAlpha3());
            lowAlphaDataList.add(lowAlpha);
            highAlphaDataList.add(highAlpha);
        }

        List lowBetaDataList = new ArrayList();
        List highBetaDataList = new ArrayList();
        for (BetaData data : betaDataIPage) {
            int lowBeta = EEGUtil.getEEGPower(data.getLowBeta1(), data.getLowBeta2(), data.getLowBeta3());
            int highBeta = EEGUtil.getEEGPower(data.getHighBeta1(), data.getHighBeta2(), data.getHighBeta3());
            lowBetaDataList.add(lowBeta);
            highBetaDataList.add(highBeta);
        }

        List deltaDataList = new ArrayList();
        for (DeltaData data : deltaDataIPage) {
            int delta = EEGUtil.getEEGPower(data.getDelta1(), data.getDelta2(), data.getDelta3());
            deltaDataList.add(delta);
        }

        List lowGammaDataList = new ArrayList();
        List middleGammaDataList = new ArrayList();
        for (GammaData data : gammaDataIPage) {
            int lowGamma = EEGUtil.getEEGPower(data.getLowGamma1(), data.getLowGamma2(), data.getLowGamma3());
            int middleGamma = EEGUtil.getEEGPower(data.getMiddleGamma1(), data.getMiddleGamma2(), data.getMiddleGamma3());
            lowGammaDataList.add(lowGamma);
            middleGammaDataList.add(middleGamma);
        }

        List thetaDataList = new ArrayList();
        for (ThetaData data : thetaDataIPage) {
            int theta = EEGUtil.getEEGPower(data.getTheta1(), data.getTheta2(), data.getTheta3());
            thetaDataList.add(theta);
        }

        List attentionDataList = new ArrayList();
        List meditationDataList = new ArrayList();
        for (OtherData data : otherDataIPage) {
            attentionDataList.add(data.getAttention());
            meditationDataList.add(data.getMeditation());
        }
        //计算EEG值 结束

        //获取时间
        List timeList = new ArrayList<>();
        for (OtherData data : otherDataIPage) {
            timeList.add(LocalDateTimeUtils.formatTime(data.getTime(), "yyyy-MM-dd HH:mm:ss"));
        }

        brainwaveMap.put("LowAlpha", lowAlphaDataList);
        brainwaveMap.put("HighAlpha", highAlphaDataList);
        brainwaveMap.put("LowBeta", lowBetaDataList);
        brainwaveMap.put("HighBeta", highBetaDataList);
        brainwaveMap.put("Delta", deltaDataList);
        brainwaveMap.put("LowGamma", lowGammaDataList);
        brainwaveMap.put("MiddleGamma", middleGammaDataList);
        brainwaveMap.put("Theta", thetaDataList);
        brainwaveMap.put("Attention", attentionDataList);
        brainwaveMap.put("Meditation", meditationDataList);
        brainwaveMap.put("Time", timeList);

        return brainwaveMap;
    }

}

