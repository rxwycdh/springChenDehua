package org.analysis.projects.suilin.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.analysis.projects.suilin.model.auto.Owner;
import org.analysis.projects.suilin.service.auto.OwnerService;
import org.analysis.system.common.domain.AjaxResult;
import org.analysis.system.common.domain.TableSplitResult;
import org.analysis.system.common.domain.Tablepar;
import org.analysis.system.common.support.Convert;
import org.analysis.system.model.custom.TitleVo;
import org.analysis.system.util.StringUtils;
import org.analysis.system.common.log.Log;
import org.analysis.system.util.ExcelUtils;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.analysis.system.common.base.BaseController;

import java.time.LocalDateTime;
import javax.servlet.http.HttpServletResponse;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.*;


/**
 * <p>
 * 业主信息 前端控制器
 * </p>
 *
 * @author Feliz
 * @since 2020-07-28 16:53:33
 */
@Controller
@Api(tags = {"业主信息"})
@RequestMapping("/suilin/OwnerController")
public class OwnerController extends BaseController{

    private static Logger logger = LoggerFactory.getLogger(OwnerController.class);

    //跳转页面参数
    private String prefix = "projects/suilin/owner";

	@Autowired
	private OwnerService ownerService;

	//跳转业主信息页面
    @GetMapping("/view")
    @RequiresPermissions("suilin:owner:view")
    public String view(Model model) {
        String str="业主信息";
        setTitle(model, new TitleVo(str+"列表", str+"管理", false, "欢迎进入"+str+"页面", false, false));
        return prefix + "/list";
    }

    @Log(title = "业主信息列表查询", action = "111")
    @ApiOperation(value = "获取业主信息列表", notes = "获取业主信息列表")
    @PostMapping("/list")
    @RequiresPermissions("suilin:owner:list")
    @ResponseBody
    public TableSplitResult<Owner> list(Tablepar tablepar, String searchText) {

        QueryWrapper<Owner> queryWrapper = new QueryWrapper<>();
        if (StringUtils.isNotEmpty(searchText)) {
            queryWrapper.and(wrapper -> wrapper
                    .like("id", searchText).or()
                    .like("suilin_user_id", searchText).or()
                    .like("name", searchText).or()
                    .like("gender", searchText).or()
                    .like("phone", searchText).or()
                    .like("id_card_type", searchText).or()
                    .like("id_card", searchText).or()
                    .like("id_card_file_id", searchText).or()
                    .like("property_file_id", searchText).or()
                    .like("room_number", searchText).or()
                    .like("room_area", searchText).or()
                    .like("position", searchText).or()
            );
        }

        PageHelper.startPage(tablepar.getPageNum(), tablepar.getPageSize());
        List<Owner> list = ownerService.list(queryWrapper);
        PageInfo<Owner> pageInfo = new PageInfo<Owner>(list);

        return new TableSplitResult<>(pageInfo.getPageNum(), pageInfo.getTotal(), pageInfo.getList());
    }

    @ApiOperation(value = "获取全部业主信息信息", notes = "获取全部业主信息信息")
    @PostMapping("/getAllOwner")
    @ResponseBody
    public AjaxResult<TableSplitResult<Owner>> getAllOwner() {
        try {
            List<Owner> list = ownerService.list();
            return AjaxResult.successDataList(list);
        } catch (Exception e) {
            logger.error(e.toString());
            return AjaxResult.error(e.getMessage());
        }
    }

    //跳转业主信息新增页面
    @GetMapping("/add")
    public String add() {
        return prefix + "/add";
    }

    @Log(title = "业主信息新增", action = "111")
    @ApiOperation(value = "添加业主信息", notes = "添加业主信息")
    @PostMapping("add")
    @RequiresPermissions("suilin:owner:add")
    @ResponseBody
    public AjaxResult add(Owner owner) {
        owner.setCreateTime(LocalDateTime.now());
        boolean save = ownerService.save(owner);
        return save ? success() : error();
    }

    @Log(title = "业主信息删除", action = "111")
    @ApiOperation(value = "删除业主信息", notes = "根据id删除业主信息（可批量）")
    @PostMapping("/remove")
    @RequiresPermissions("suilin:owner:remove")
    @ResponseBody
    public AjaxResult remove(String ids) {
        List<Integer> idList= Convert.toListIntArray(ids);
        boolean delete = ownerService.removeByIds(idList);
        return delete ? success() : error();
    }

    @ApiOperation(value = "检查业主信息是否存在", notes = "返回: 1-存在; 0-不存在")
    @PostMapping("/checkUnique")
    @ResponseBody
    public Integer checkUnique(Owner owner) {
        QueryWrapper<Owner> queryWrapper = new QueryWrapper<>();
        //TODO 注意是否正确，默认检测name字段
        //queryWrapper.eq("name", owner.getName());
        List<Owner> list = ownerService.list(queryWrapper);
        if (list.size() > 0) {
            return 1;
        } else {
            return 0;
        }
    }

    //跳转业主信息修改页面
    @GetMapping("/edit/{id}")
    public String edit(@PathVariable("id") Integer id, ModelMap modelMap) {
        modelMap.put("owner", ownerService.getById(id));
        return prefix + "/edit";
    }

    @Log(title = "业主信息修改", action = "111")
    @ApiOperation(value = "修改业主信息", notes = "修改业主信息")
    @PostMapping("/edit")
    @RequiresPermissions("suilin:owner:edit")
    @ResponseBody
    public AjaxResult editSave(Owner owner) {
        owner.setUpdateTime(LocalDateTime.now());
        boolean edit = ownerService.updateById(owner);
        return edit ? success() : error();
    }


    //跳转业主信息批量新增页面
    @GetMapping("/batchAdd")
    public String batchAdd() {
        return prefix + "/batchAdd";
    }

    @Log(title = "业主信息批量导入", action = "111")
    @ApiOperation(value = "批量导入业主信息", notes = "批量导入业主信息")
    @RequiresPermissions("suilin:owner:add")
    @Transactional(propagation = Propagation.REQUIRED)
    @PostMapping("/batchAdd")
    @ResponseBody
    public AjaxResult batchAdd(@RequestParam(value = "file", required = false) MultipartFile file) {
        try {
            String suffer = file.getOriginalFilename().substring(file.getOriginalFilename().indexOf(".") + 1);
            if ("xls".equals(suffer) || "xlsx".equals(suffer)) {
                InputStream in = file.getInputStream();
                Map<String, String> fields = new LinkedHashMap<String, String>();

                fields.put("用户id", "suilinUserId");
                fields.put("姓名", "name");
                fields.put("性别；0：未知；1：男性；2：女性", "gender");
                fields.put("手机号码", "phone");
                fields.put("证件类型", "idCardType");
                fields.put("证件号码", "idCard");
                fields.put("身份证照file-id", "idCardFileId");
                fields.put("房产证照file-id", "propertyFileId");
                fields.put("楼栋&房号", "roomNumber");
                fields.put("房屋面积", "roomArea");
                fields.put("职位", "position");

                List<Owner> list = new ArrayList<Owner>();
                list = ExcelUtils.ExecltoList(in, Owner.class, fields);

                int sum = list.size();//总需导入数
                int successNum = 0;//成功导入数
                int failNum = 0;//失败导入数
                for (Owner o : list) {

                    if (checkUnique(o) == 0) {
                        add(o);
                        successNum++;
                    }else {
                        failNum++;
                    }
                }

                return success("总需导入数：" + sum + "</br>成功导入数：" + successNum +" </br>失败导入数：" + failNum);
            }
            return error("上传文件格式应为xls或xlsx");

        } catch (Exception e) {
            logger.error(ExceptionUtils.getFullStackTrace(e));
            return error("上传文件模板有误，请对比导入模板！");
        }
    }

    @Log(title = "业主信息导入模板获取", action = "111")
    @GetMapping("/getExcelModel")
    @ResponseBody
    public void getUserCardExcelModel(HttpServletResponse response) throws Exception {
        OutputStream out = null;
        //通过response对象获取outputStream流
        response.setContentType("application/octect-stream"); // 下载文件能正常显示中文
        response.setHeader("Content-Disposition", "attachment;filename=" + new String(("业主信息的导入模板.xls").getBytes("gb2312"), "ISO8859-1"));
        out = response.getOutputStream();

        Map<String, String> fields = new LinkedHashMap<String, String>();

        fields.put("suilinUserId", "用户id");
        fields.put("name", "姓名");
        fields.put("gender", "性别；0：未知；1：男性；2：女性");
        fields.put("phone", "手机号码");
        fields.put("idCardType", "证件类型");
        fields.put("idCard", "证件号码");
        fields.put("idCardFileId", "身份证照file-id");
        fields.put("propertyFileId", "房产证照file-id");
        fields.put("roomNumber", "楼栋&房号");
        fields.put("roomArea", "房屋面积");
        fields.put("position", "职位");

        ExcelUtils.ListtoExecl(null, out, fields);
        out.flush();
        out.close();
    }

	
}
