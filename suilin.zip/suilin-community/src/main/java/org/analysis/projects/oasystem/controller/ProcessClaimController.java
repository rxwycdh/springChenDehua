package org.analysis.projects.oasystem.controller;


import com.baomidou.dynamic.datasource.annotation.DS;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.analysis.projects.oasystem.model.auto.ClaimDetail;
import org.analysis.projects.oasystem.model.auto.ProcessClaim;
import org.analysis.projects.oasystem.service.auto.ClaimDetailService;
import org.analysis.projects.oasystem.service.auto.ProcessClaimService;
import org.analysis.system.common.base.BaseController;
import org.analysis.system.common.domain.AjaxResult;
import org.analysis.system.common.support.Convert;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.interceptor.TransactionAspectSupport;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * <p>
 * 费用报销 前端控制器
 * </p>
 *
 * @author Feliz
 * @since 2019-06-21
 */
@Api(tags = {"费用报销"})
@Controller
@RequestMapping("/oasystem/process-claim")
public class ProcessClaimController extends BaseController {

    private static Logger logger = LoggerFactory.getLogger(ProcessClaimController.class);

    @Autowired
    private ProcessClaimService processClaimService;
    @Autowired
    private ClaimDetailService claimDetailService;

    //跳转页面参数
    private String prefix = "projects/oasystem/process/claim";

    @ApiOperation(value = "跳转费用报销页面", notes = "跳转费用报销页面", hidden = true)
    @GetMapping("/add")
    public String add() {
        return prefix + "/add";
    }

    @ApiOperation(value = "添加费用报销单", notes = "添加费用报销单")
    @DS("db_oasystem")
    @Transactional
    @PostMapping("add")
    @RequiresPermissions("oasystem:claim:add")
    @ResponseBody
    public AjaxResult add(ProcessClaim processClaim, ClaimDetail claimDetail) {

        try {
            boolean b = claimDetailService.save(claimDetail);
            processClaim.setDetailIds(String.valueOf(claimDetail.getId()));
            boolean save = processClaimService.save(processClaim);
            if (save && b) {
                return success();
            } else {
                logger.error("添加出错");
                return error();
            }
        } catch (Exception e) {
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly(); //手动回滚失误
            logger.error(ExceptionUtils.getFullStackTrace(e));
            return error();
        }
    }

    @ApiOperation(value = "删除费用报销单", notes = "根据id删除费用报销单（批量）")
    @PostMapping("remove")
    @RequiresPermissions("oasystem:claim:remove")
    @ResponseBody
    public AjaxResult remove(String ids) {
        List<String> idList= Convert.toListStrArray(ids);
        boolean remove = processClaimService.removeByIds(idList);
        if (remove) {
            return success();
        } else {
            return error();
        }
    }

    @ApiOperation(value = "跳转费用报销单修改页面", notes = "跳转到费用报销单修改页面", hidden = true)
    @GetMapping("/edit/{id}")
    public String edit(@PathVariable("id") String id, ModelMap mmap) {
        mmap.put("claim", processClaimService.getById(id));
        return prefix + "/edit";
    }

    @ApiOperation(value = "修改费用报销单", notes = "修改保存费用报销单")
    @PostMapping("/edit")
    @RequiresPermissions("oasystem:claim:edit")
    @ResponseBody
    public AjaxResult editSave(ProcessClaim processClaim) {
        boolean b = processClaimService.updateById(processClaim);
        return b ? success() : error();
    }

}

