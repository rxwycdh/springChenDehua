package org.analysis.projects.oasystem.controller;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.analysis.projects.oasystem.model.auto.Notice;
import org.analysis.projects.oasystem.model.auto.ObjectStatus;
import org.analysis.projects.oasystem.model.auto.Staff;
import org.analysis.projects.oasystem.model.auto.StaffUser;
import org.analysis.projects.oasystem.model.custom.NoticeVO;
import org.analysis.projects.oasystem.service.auto.NoticeService;
import org.analysis.projects.oasystem.service.auto.ObjectStatusService;
import org.analysis.projects.oasystem.service.auto.StaffService;
import org.analysis.projects.oasystem.service.auto.StaffUserService;
import org.analysis.system.common.base.BaseController;
import org.analysis.system.common.domain.AjaxResult;
import org.analysis.system.common.domain.TableSplitResult;
import org.analysis.system.common.domain.Tablepar;
import org.analysis.system.common.support.Convert;
import org.analysis.system.model.auto.TsysUser;
import org.analysis.system.model.custom.TitleVo;
import org.analysis.system.shiro.util.ShiroUtils;
import org.analysis.system.util.StringUtils;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * <p>
 * 公告信息 前端控制器
 * </p>
 *
 * @author Feliz
 * @since 2019-06-14
 */
@Api(tags = {"公告信息"})
@Controller
@RequestMapping("/oasystem/notice")
public class NoticeController extends BaseController {

    private static Logger logger = LoggerFactory.getLogger(NoticeController.class);

    @Autowired
    private NoticeService noticeService;
    @Autowired
    private StaffService staffService;
    @Autowired
    private StaffUserService staffUserService;
    @Autowired
    private ObjectStatusService objectStatusService;


    //跳转页面参数
    private String prefix = "projects/oasystem/notice";


    @ApiOperation(value = "跳转公告管理页面", notes = "跳转到公告管理页面", hidden = true)
    @GetMapping("view")
    @RequiresPermissions("oasystem:notice:view")
    public String view(Model model) {
        setTitle(model, new TitleVo("公告列表", "公告管理", false, "欢迎进入公告管理页面", false, false));
        return prefix + "/list";
    }

    @ApiOperation(value = "获取公告列表", notes = "获取公告列表")
    @PostMapping("list")
    @RequiresPermissions("oasystem:notice:list")
    @ResponseBody
    public TableSplitResult<NoticeVO> list(Tablepar tablepar, String searchText) {

        try {
            QueryWrapper<Notice> queryWrapper = new QueryWrapper<>();
            if (StringUtils.isNotEmpty(searchText)) {
                queryWrapper.like("title", searchText).or().like("content", searchText).or().like("description", searchText);
            }

            PageHelper.startPage(tablepar.getPageNum(), tablepar.getPageSize());
            List<Notice> noticeList = noticeService.list(queryWrapper);

            //置顶排序,先删后加
            for (int i = 0; i < noticeList.size(); i++) {
                Notice notice = noticeList.get(i);
                if (notice.getTop() == 1) {
                    noticeList.remove(notice);
                    noticeList.add(0, notice);
                }
            }

            List<NoticeVO> list = new ArrayList<>();
            for (int i = 0; i < noticeList.size(); i++) {
                NoticeVO noticeVO = new NoticeVO();
                BeanUtils.copyProperties(noticeVO, noticeList.get(i));

                Staff staff = staffService.getById(noticeList.get(i).getStaffId());
                if (staff != null) {
                    noticeVO.setStaffName(staff.getName());
                }

                ObjectStatus status = objectStatusService.getById(noticeList.get(i).getStatusId());
                noticeVO.setStatus(status);

                list.add(noticeVO);
            }

            PageInfo<NoticeVO> pageInfo = new PageInfo<>(list);

            return new TableSplitResult<>(pageInfo.getPageNum(), pageInfo.getTotal(), pageInfo.getList());
        } catch (Exception e) {
            logger.error(ExceptionUtils.getFullStackTrace(e));
            return null;
        }
    }


    @ApiOperation(value = "跳转新增公告页面", notes = "跳转新增公告页面", hidden = true)
    @GetMapping("/add")
    public String add() {
        return prefix + "/add";
    }

    @ApiOperation(value = "添加公告", notes = "添加新的公告")
    @PostMapping("add")
    @RequiresPermissions("oasystem:notice:add")
    @ResponseBody
    public AjaxResult add(Notice notice) {

        TsysUser user = ShiroUtils.getUser();
        QueryWrapper<StaffUser> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("user_id", user.getId());
        List<StaffUser> list = staffUserService.list(queryWrapper);

        if (list.size() >0 ) {
            notice.setStaffId(list.get(0).getStaffId());
        }
        notice.setNoticeTime(LocalDateTime.now());
        boolean save = noticeService.save(notice);
        if (save) {
            return success();
        } else {
            return error();
        }
    }

    @ApiOperation(value = "删除公告", notes = "根据id删除公告（批量）")
    @PostMapping("remove")
    @RequiresPermissions("oasystem:notice:remove")
    @ResponseBody
    public AjaxResult remove(String ids) {
        List<String> idList= Convert.toListStrArray(ids);
        boolean save = noticeService.removeByIds(idList);
        if (save) {
            return success();
        } else {
            return error();
        }
    }

    @ApiOperation(value = "跳转公告修改页面", notes = "跳转到公告修改页面", hidden = true)
    @GetMapping("/edit/{id}")
    public String edit(@PathVariable("id") String id, ModelMap mmap) {
        mmap.put("notice", noticeService.getById(id));
        return prefix + "/edit";
    }

    @ApiOperation(value = "修改公告", notes = "修改保存公告")
    @PostMapping("/edit")
    @RequiresPermissions("oasystem:Notice:edit")
    @ResponseBody
    public AjaxResult editSave(Notice notice) {
        boolean b = noticeService.updateById(notice);
        return b ? success() : error();
    }

    @ApiOperation(value = "跳转查看公告详情页面", notes = "跳转查看公告详情页面", hidden = true)
    @GetMapping("/detail/{id}")
    public String viewdetail(@PathVariable("id") String id, ModelMap mmap) {
        try {
            NoticeVO noticeVO = new NoticeVO();
            Notice notice = noticeService.getById(id);
            BeanUtils.copyProperties(noticeVO, notice);

            Staff staff = staffService.getById(notice.getStaffId());
            if (staff != null) {
                noticeVO.setStaffName(staff.getName());
            }

            ObjectStatus status = objectStatusService.getById(notice.getStatusId());
            noticeVO.setStatus(status);

            mmap.put("notice", noticeVO);
            return prefix + "/detail";
        } catch (Exception e) {
            logger.error(ExceptionUtils.getFullStackTrace(e));
            return prefix + "/list";
        }
    }
}

