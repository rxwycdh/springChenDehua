package org.analysis.projects.ppp.mapper.auto;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.analysis.projects.ppp.model.auto.Project;
import org.apache.ibatis.annotations.CacheNamespace;

/**
 * <p>
 * 项目信息 Mapper 接口
 * </p>
 *
 * @author Feliz
 * @since 2020-04-03
 */
@CacheNamespace(flushInterval = 3600000, size = 4096)
public interface ProjectMapper extends BaseMapper<Project> {

}
