package org.analysis.projects.oasystem.service.auto.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.analysis.projects.oasystem.mapper.auto.ProcessTripMapper;
import org.analysis.projects.oasystem.model.auto.ProcessTrip;
import org.analysis.projects.oasystem.service.auto.ProcessTripService;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 出差申请 服务实现类
 * </p>
 *
 * @author Feliz
 * @since 2019-06-22
 */
@Service
public class ProcessTripServiceImpl extends ServiceImpl<ProcessTripMapper, ProcessTrip> implements ProcessTripService {

}
