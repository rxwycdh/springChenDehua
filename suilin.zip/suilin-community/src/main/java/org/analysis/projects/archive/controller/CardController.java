package org.analysis.projects.archive.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.analysis.projects.archive.model.auto.Card;
import org.analysis.projects.archive.model.auto.Field;
import org.analysis.projects.archive.model.auto.Template;
import org.analysis.projects.archive.model.custom.CardVO;
import org.analysis.projects.archive.model.custom.TemplateVO;
import org.analysis.projects.archive.service.auto.CardService;
import org.analysis.projects.archive.service.auto.FieldService;
import org.analysis.projects.archive.service.auto.TemplateService;
import org.analysis.system.common.base.BaseController;
import org.analysis.system.common.domain.AjaxResult;
import org.analysis.system.common.domain.TableSplitResult;
import org.analysis.system.common.domain.Tablepar;
import org.analysis.system.common.log.Log;
import org.analysis.system.common.support.Convert;
import org.analysis.system.mapper.auto.TsysPermissionRoleMapper;
import org.analysis.system.mapper.custom.PermissionDao;
import org.analysis.system.model.auto.TsysPremission;
import org.analysis.system.model.auto.TsysPremissionExample;
import org.analysis.system.model.auto.TsysRole;
import org.analysis.system.model.auto.TsysRoleExample;
import org.analysis.system.model.custom.TitleVo;
import org.analysis.system.util.StringUtils;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * <p>
 * 信息卡片 前端控制器
 * </p>
 *
 * @author Feliz
 * @since 2019-09-10 16:55:35
 */
@Controller
@Api(tags = {"信息卡片"})
@RequestMapping("/archive/CardController")
public class CardController extends BaseController{

    private static Logger logger = LoggerFactory.getLogger(CardController.class);

    //跳转页面参数
    private String prefix = "projects/archive/card";

    @Autowired
    private TemplateController templateController;
	@Autowired
	private CardService cardService;
	@Autowired
    private FieldService fieldService;
	@Autowired
    private TemplateService templateService;
    @Autowired
    private TsysPermissionRoleMapper tsysPermissionRoleMapper;
    @Autowired
    private PermissionDao permissionDao;

    //信息个人用户角色名称
    private String archiveUserRoleName = "archiveUserRoleName";
    //信息管理员角色名称
    private String archiveAdminRoleName = "archiveAdminRoleName";


    @ApiOperation(value = "跳转信息卡片页面", notes = "跳转信息卡片页面", hidden = true)
    @GetMapping("/view")
    @RequiresPermissions("archive:card:view")
    public String view(Model model) {
        String str="信息卡片";
        setTitle(model, new TitleVo(str+"列表", str+"管理", false, "欢迎进入"+str+"页面", false, false));
        return prefix + "/list";
    }

    @Log(title = "信息卡片列表查询", action = "111")
    @ApiOperation(value = "获取信息卡片列表", notes = "获取信息卡片列表")
    @PostMapping("/list")
    @RequiresPermissions("archive:card:list")
    @ResponseBody
    public TableSplitResult<CardVO> list(Tablepar tablepar, String searchText) {

        QueryWrapper<Card> queryWrapper = new QueryWrapper<>();
        if (StringUtils.isNotEmpty(searchText)) {
            queryWrapper.and(wrapper -> wrapper
                    .like("id", searchText).or()
                    .like("card_name", searchText).or()
                    .like("card_field_ids", searchText).or()
                    .like("description", searchText).or()
            );
        }

        PageHelper.startPage(tablepar.getPageNum(), tablepar.getPageSize());
        List<Card> cardlist = cardService.list(queryWrapper);
        PageInfo<Card> pageInfo = new PageInfo<>(cardlist);


        List<CardVO> list = new ArrayList<>();
        for (Card t : cardlist) {
            CardVO cardVO = new CardVO();
            try {
                BeanUtils.copyProperties(cardVO, t);
            } catch (Exception e) {
                logger.error(e.getMessage());
            }

            List<Field> fields = fieldService.listByIds(t.getCardFieldIds());
            List<String> fieldNameList = new ArrayList<>();
            if (fields.size() > 0) {
                for (Field f : fields) {
                    fieldNameList.add(f.getFieldName());
                }
            }

            String templateFields = StringUtils.join(fieldNameList, ",");
            cardVO.setTemplateFields(templateFields);

            list.add(cardVO);
        }

        return new TableSplitResult<>(pageInfo.getPageNum(), pageInfo.getTotal(), list);
    }

    @ApiOperation(value = "跳转从模板新增信息卡片页面", notes = "跳转新增信息卡片页面", hidden = true)
    @GetMapping("/addFromTemp")
    public String addFromTemp(Tablepar tablepar, Model model) {

        //分页
        if (tablepar.getPageNum() == 0 && tablepar.getPageSize() == 0) {
            tablepar.setPageNum(1);
            tablepar.setPageSize(5);
        }
        TableSplitResult<TemplateVO> list = templateController.list(tablepar, null);

        model.addAttribute("templateList", list);
        return prefix + "/addFromTemp";
    }

    @ApiOperation(value = "跳转重启名卡片页面", notes = "跳转重启名卡片页面", hidden = true)
    @GetMapping("/addRename")
    public String addRename(Integer tempId, Model model) {

        Template template = templateService.getById(tempId);
        model.addAttribute("tempId", tempId);
        model.addAttribute("cardName", template.getTemplateName());
        model.addAttribute("description", template.getDescription());
        return prefix + "/addRename";
    }

    @Log(title = "从模板新增信息卡片", action = "111")
    @ApiOperation(value = "添加信息卡片", notes = "添加信息卡片")
    @PostMapping("addFromTemp")
    @RequiresPermissions("archive:card:add")
    @Transactional
    @ResponseBody
    public AjaxResult addFromTemp(Integer tempId, String cardName, String description) {

        Template template = templateService.getById(tempId);

        Card card = new Card();
        //卡片名称 = 模板名称 + 当前时间毫秒值
        card.setCardName(cardName);
        card.setDescription(description);
        card.setCardFieldIds(template.getTemplateFieldIds());
        card.setCreateTime(LocalDateTime.now());
        boolean save = cardService.save(card);

        //同时新建菜单
        TsysPremission tsysPremission = new TsysPremission(card.getCardName(), "", "/archive/UserCardController/view/"+card.getId(),
                134, "archive:userCard:"+card.getId(), 1, "fa fa-address-card-o", 10);
        int i = sysPremissionService.insertSelective(tsysPremission);

        //获取字典
        String aUserRoleName = sysKvSettingService.getValueByDicKey(archiveUserRoleName);
        String aAdminRoleName = sysKvSettingService.getValueByDicKey(archiveAdminRoleName);

        //获取信息个人用户角色
        TsysRoleExample tsysRoleExample = new TsysRoleExample();
        tsysRoleExample.createCriteria().andNameEqualTo(aUserRoleName);
        TsysRole aUserRole = sysRoleService.selectByExample(tsysRoleExample).get(0);

        //获取信息个人用户管理员角色
        TsysRoleExample tsysRoleExample2 = new TsysRoleExample();
        tsysRoleExample2.createCriteria().andNameEqualTo(aAdminRoleName);
        TsysRole aAdminRole = sysRoleService.selectByExample(tsysRoleExample2).get(0);

        //获取权限
        TsysPremission archivePremission = sysPremissionService.selectByPrimaryKey(i);

        //获取所有权限
        List<TsysPremission> aUserRolePremissions = permissionDao.queryRoleId(aUserRole.getId());
        List<TsysPremission> aAdminRolePremissions = permissionDao.queryRoleId(aAdminRole.getId());

        String aUserPerm = "";
        String aAdminPerm = "";
        for (TsysPremission t : aUserRolePremissions) {
            aUserPerm = aUserPerm + "," + t.getId();
        }
        aUserPerm = aUserPerm + "," + archivePremission.getId();

        for (TsysPremission t : aAdminRolePremissions) {
            aAdminPerm = aAdminPerm + "," + t.getId();
        }
        aAdminPerm = aAdminPerm + "," + archivePremission.getId();

        sysRoleService.updateRoleAndPrem(aUserRole,aUserPerm);
        sysRoleService.updateRoleAndPrem(aAdminRole,aAdminPerm);

        if (save) {
            return success();
        }else {
            return error();
        }

    }

    @ApiOperation(value = "跳转新增信息卡片页面", notes = "跳转新增信息卡片页面", hidden = true)
    @GetMapping("/add")
    public String add() {
        return prefix + "/add";
    }

    @Log(title = "信息卡片新增", action = "111")
    @ApiOperation(value = "添加信息卡片", notes = "添加信息卡片")
    @PostMapping("add")
    @RequiresPermissions("archive:card:add")
    @Transactional
    @ResponseBody
    public AjaxResult add(Card card) {
        card.setCreateTime(LocalDateTime.now());
        boolean save = cardService.save(card);

        //同时新建菜单
        TsysPremission tsysPremission = new TsysPremission(card.getCardName(), "", "/archive/UserCardController/view/"+card.getId(),
                134, "archive:userCard:"+card.getId(), 1, "fa fa-address-card-o", 10);
        int i = sysPremissionService.insertSelective(tsysPremission);


        //获取字典
        String aUserRoleName = sysKvSettingService.getValueByDicKey(archiveUserRoleName);
        String aAdminRoleName = sysKvSettingService.getValueByDicKey(archiveAdminRoleName);

        //获取信息个人用户角色
        TsysRoleExample tsysRoleExample = new TsysRoleExample();
        tsysRoleExample.createCriteria().andNameEqualTo(aUserRoleName);
        TsysRole aUserRole = sysRoleService.selectByExample(tsysRoleExample).get(0);

        //获取信息个人用户管理员角色
        TsysRoleExample tsysRoleExample2 = new TsysRoleExample();
        tsysRoleExample2.createCriteria().andNameEqualTo(aAdminRoleName);
        TsysRole aAdminRole = sysRoleService.selectByExample(tsysRoleExample2).get(0);

        //获取权限
        TsysPremission archivePremission = sysPremissionService.selectByPrimaryKey(i);

        //获取所有权限
        List<TsysPremission> aUserRolePremissions = permissionDao.queryRoleId(aUserRole.getId());
        List<TsysPremission> aAdminRolePremissions = permissionDao.queryRoleId(aAdminRole.getId());

        String aUserPerm = "";
        String aAdminPerm = "";
        for (TsysPremission t : aUserRolePremissions) {
            aUserPerm = aUserPerm + "," + t.getId();
        }
        aUserPerm = aUserPerm + "," + archivePremission.getId();

        for (TsysPremission t : aAdminRolePremissions) {
            aAdminPerm = aAdminPerm + "," + t.getId();
        }
        aAdminPerm = aAdminPerm + "," + archivePremission.getId();

        sysRoleService.updateRoleAndPrem(aUserRole,aUserPerm);
        sysRoleService.updateRoleAndPrem(aAdminRole,aAdminPerm);

        if (save) {
            return success();
        } else {
            return error();
        }
    }

    @Log(title = "信息卡片删除", action = "111")
    @ApiOperation(value = "删除信息卡片", notes = "根据id删除信息卡片（可批量）")
    @PostMapping("/remove")
    @RequiresPermissions("archive:card:remove")
    @Transactional
    @ResponseBody
    public AjaxResult remove(String ids) {
        List<Integer> idList= Convert.toListIntArray(ids);

        try {
            //同时删除菜单
            for (Integer id : idList) {
                Card card = cardService.getById(id);
                TsysPremissionExample example = new TsysPremissionExample();
                example.createCriteria().andNameEqualTo(card.getCardName());
                sysPremissionService.deleteByExample(example);
            }
        } catch (Exception e) {
            logger.error("菜单不存在"+e.toString());
        }

        boolean delete = cardService.removeByIds(idList);
        if (delete) {
            return success();
        } else {
            return error();
        }
    }

    @ApiOperation(value = "检查信息卡片是否存在", notes = "返回: 1-存在; 0-不存在")
    @PostMapping("/checkNameUnique")
    @ResponseBody
    public Integer checkNameUnique(Card card) {
        QueryWrapper<Card> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("card_name", card.getCardName());
        List<Card> list = cardService.list(queryWrapper);
        if (list.size() > 0) {
            return 1;
        } else {
            return 0;
        }
    }

    @ApiOperation(value = "跳转信息卡片修改页面", notes = "跳转信息卡片修改页面", hidden = true)
    @GetMapping("/edit/{id}")
    public String edit(@PathVariable("id") String id, ModelMap mmap) {
        mmap.put("card", cardService.getById(id));
        return prefix + "/edit";
    }

    @Log(title = "信息卡片修改", action = "111")
    @ApiOperation(value = "修改信息卡片", notes = "修改信息卡片")
    @PostMapping("/edit")
    @RequiresPermissions("archive:card:edit")
    @ResponseBody
    public AjaxResult editSave(Card card) {
        card.setUpdateTime(LocalDateTime.now());

        boolean b = cardService.updateById(card);
        return b ? success() : error();
    }
	
}
