package org.analysis.projects.oasystem.controller;


import org.analysis.system.common.base.BaseController;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * <p>
 * 类型信息 前端控制器
 * </p>
 *
 * @author Feliz
 * @since 2019-06-14
 */
@Controller
@RequestMapping("/oasystem/object-type")
public class ObjectTypeController extends BaseController {

}

