package org.analysis.projects.ppp.model.custom;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;

/**
 * <p>
 * 项目类型信息
 * </p>
 *
 * @author Feliz
 * @since 2020-04-02
 */
@ApiModel(value="ProjectTypeIF对象", description="项目类型信息")
public class ProjectTypeIF implements Serializable {

    private static final long serialVersionUID = 1L;

    private Integer id;

    @ApiModelProperty(value = "类型名称")
    private String name;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "ProjectTypeIF{" +
                "id=" + id +
                ", name='" + name + '\'' +
                '}';
    }
}
