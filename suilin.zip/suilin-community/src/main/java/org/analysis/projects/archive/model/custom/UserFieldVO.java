package org.analysis.projects.archive.model.custom;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.analysis.system.model.auto.TsysUser;

import java.io.Serializable;
import java.util.List;

/**
 * <p>
 * 用户-信息字段list
 * </p>
 *
 * @author Feliz
 * @since 2019-09-21
 */
@ApiModel(value="UserFieldVO对象", description="用户-信息字段list")
public class UserFieldVO implements Serializable {

    @ApiModelProperty(value = "用户")
    private TsysUser user;

    @ApiModelProperty(value = "档案卡片id")
    private Integer cardId;

    @ApiModelProperty(value = "字段值集合")
    private List<FieldValue> fieldValueList;

    public TsysUser getUser() {
        return user;
    }

    public void setUser(TsysUser user) {
        this.user = user;
    }

    public Integer getCardId() {
        return cardId;
    }

    public void setCardId(Integer cardId) {
        this.cardId = cardId;
    }

    public List<FieldValue> getFieldValueList() {
        return fieldValueList;
    }

    public void setFieldValueList(List<FieldValue> fieldValueList) {
        this.fieldValueList = fieldValueList;
    }

    @Override
    public String toString() {
        return "UserFieldVO{" +
                "user=" + user +
                ", cardId=" + cardId +
                ", fieldValueList=" + fieldValueList +
                '}';
    }
}
