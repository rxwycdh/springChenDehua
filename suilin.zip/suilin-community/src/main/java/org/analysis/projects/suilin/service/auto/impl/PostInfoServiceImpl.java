package org.analysis.projects.suilin.service.auto.impl;

import org.analysis.projects.suilin.model.auto.PostInfo;
import org.analysis.projects.suilin.mapper.auto.PostInfoMapper;
import org.analysis.projects.suilin.service.auto.PostInfoService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 帖子表 服务实现类
 * </p>
 *
 * @author Feliz
 * @since 2020-08-19
 */
@Service
public class PostInfoServiceImpl extends ServiceImpl<PostInfoMapper, PostInfo> implements PostInfoService {

}
