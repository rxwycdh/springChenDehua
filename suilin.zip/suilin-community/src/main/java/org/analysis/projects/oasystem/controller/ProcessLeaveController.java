package org.analysis.projects.oasystem.controller;


import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.analysis.projects.oasystem.model.auto.ProcessLeave;
import org.analysis.projects.oasystem.service.auto.LeaveNoteService;
import org.analysis.projects.oasystem.service.auto.ProcessLeaveService;
import org.analysis.system.common.base.BaseController;
import org.analysis.system.common.domain.AjaxResult;
import org.analysis.system.common.support.Convert;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * <p>
 * 请假申请 前端控制器
 * </p>
 *
 * @author Feliz
 * @since 2019-06-22
 */
@Api(tags = {"请假申请"})
@Controller
@RequestMapping("/oasystem/process-leave")
public class ProcessLeaveController extends BaseController {

    private static Logger logger = LoggerFactory.getLogger(ProcessLeaveController.class);

    @Autowired
    private ProcessLeaveService processLeaveService;
    @Autowired
    private LeaveNoteService leaveNoteService;

    //跳转页面参数
    private String prefix = "projects/oasystem/process/leave";

    @ApiOperation(value = "跳转请假申请页面", notes = "跳转请假申请页面", hidden = true)
    @GetMapping("/add")
    public String add(ModelMap mmap) {
        mmap.put("leaveNotes", leaveNoteService.list());
        return prefix + "/add";
    }

    @ApiOperation(value = "添加请假申请单", notes = "添加请假申请单")
    @PostMapping("add")
    @RequiresPermissions("oasystem:leave:add")
    @ResponseBody
    public AjaxResult add(ProcessLeave processLeave) {
        try {
            boolean save = processLeaveService.save(processLeave);
            return save ? success() : error();
        } catch (Exception e) {
            logger.error(ExceptionUtils.getFullStackTrace(e));
            return error();
        }
    }

    @ApiOperation(value = "删除请假申请单", notes = "根据id删除请假申请单（批量）")
    @PostMapping("remove")
    @RequiresPermissions("oasystem:leave:remove")
    @ResponseBody
    public AjaxResult remove(String ids) {
        List<String> idList= Convert.toListStrArray(ids);
        boolean remove = processLeaveService.removeByIds(idList);
        return remove ? success() : error();
    }

    @ApiOperation(value = "跳转请假申请修改页面", notes = "跳转到请假申请修改页面", hidden = true)
    @GetMapping("/edit/{id}")
    public String edit(@PathVariable("id") String id, ModelMap mmap) {
        mmap.put("leave", processLeaveService.getById(id));
        return prefix + "/edit";
    }

    @ApiOperation(value = "修改请假申请单", notes = "修改保存请假申请单")
    @PostMapping("/edit")
    @RequiresPermissions("oasystem:leave:edit")
    @ResponseBody
    public AjaxResult editSave(ProcessLeave processLeave) {
        boolean b = processLeaveService.updateById(processLeave);
        return b ? success() : error();
    }
}

