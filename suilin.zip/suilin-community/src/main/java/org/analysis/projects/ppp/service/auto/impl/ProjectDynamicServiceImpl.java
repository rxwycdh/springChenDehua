package org.analysis.projects.ppp.service.auto.impl;

import org.analysis.projects.ppp.model.auto.ProjectDynamic;
import org.analysis.projects.ppp.mapper.auto.ProjectDynamicMapper;
import org.analysis.projects.ppp.service.auto.ProjectDynamicService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 项目动态信息 服务实现类
 * </p>
 *
 * @author Feliz
 * @since 2020-04-05
 */
@Service
public class ProjectDynamicServiceImpl extends ServiceImpl<ProjectDynamicMapper, ProjectDynamic> implements ProjectDynamicService {

}
