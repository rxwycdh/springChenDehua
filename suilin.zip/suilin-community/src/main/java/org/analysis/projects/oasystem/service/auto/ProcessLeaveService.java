package org.analysis.projects.oasystem.service.auto;

import com.baomidou.mybatisplus.extension.service.IService;
import org.analysis.projects.oasystem.model.auto.ProcessLeave;

/**
 * <p>
 * 请假申请 服务类
 * </p>
 *
 * @author Feliz
 * @since 2019-06-22
 */
public interface ProcessLeaveService extends IService<ProcessLeave> {

}
