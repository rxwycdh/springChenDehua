package org.analysis.projects.brainwave.mapper.auto;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.analysis.projects.brainwave.model.auto.AlphaData;
import org.apache.ibatis.annotations.CacheNamespace;

/**
 * <p>
 * alpha脑波数据表 Mapper 接口
 * </p>
 *
 * @author Feliz
 * @since 2019-06-06
 */
@DS("db_brainwave")
@CacheNamespace(flushInterval = 3600000, size = 4096)
public interface AlphaDataMapper extends BaseMapper<AlphaData> {

}
