package org.analysis.projects.ppp.mapper.auto;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.analysis.projects.ppp.model.auto.ServiceType;
import org.apache.ibatis.annotations.CacheNamespace;

/**
 * <p>
 * 服务分类 Mapper 接口
 * </p>
 *
 * @author Feliz
 * @since 2020-04-23
 */
@CacheNamespace(flushInterval = 3600000, size = 4096)
public interface ServiceTypeMapper extends BaseMapper<ServiceType> {

}
