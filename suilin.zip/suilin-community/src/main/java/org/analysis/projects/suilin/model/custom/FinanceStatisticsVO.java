package org.analysis.projects.suilin.model.custom;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.analysis.projects.suilin.model.auto.Finance;

import java.util.List;

/**
 * @author ChenDehua  597701764@qq.com
 * @date 2020/8/12 20:15
 */
@ApiModel("财务统计显示参数")
@Data
public class FinanceStatisticsVO {

    /**
     * 合计
     */
    @ApiModelProperty(value = "合计")
    private Double amount;

    /**
     * 总收入
     */
    @ApiModelProperty(value = "总收入")
    private Double incomeAmount;

    /**
     * 支出
     */
    @ApiModelProperty(value = "支出")
    private Double expensesAmount;

    /**
     * 余额
     */
    @ApiModelProperty(value = "余额")
    private Double balance;
    /**
     * 财务列表
     */
    @ApiModelProperty(value = "财务列表")
    private List<Finance> financeList;
}
