package org.analysis.projects.ppp.service.auto.impl;

import org.analysis.projects.ppp.model.auto.ProjectType;
import org.analysis.projects.ppp.mapper.auto.ProjectTypeMapper;
import org.analysis.projects.ppp.service.auto.ProjectTypeService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 项目类型信息 服务实现类
 * </p>
 *
 * @author Feliz
 * @since 2020-04-02
 */
@Service
public class ProjectTypeServiceImpl extends ServiceImpl<ProjectTypeMapper, ProjectType> implements ProjectTypeService {

}
