package org.analysis.projects.suilin.controller;

import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.analysis.projects.suilin.model.auto.Community;
import org.analysis.projects.suilin.model.auto.Finance;
import org.analysis.projects.suilin.model.custom.FinanceStatisticsVO;
import org.analysis.projects.suilin.model.custom.FinanceSummaryVO;
import org.analysis.projects.suilin.service.auto.CommunityService;
import org.analysis.projects.suilin.service.auto.FinanceService;
import org.analysis.projects.suilin.service.custom.FinanceCustomService;
import org.analysis.system.common.domain.AjaxResult;
import org.analysis.system.common.domain.TableSplitResult;
import org.analysis.system.common.domain.Tablepar;
import org.analysis.system.common.support.Convert;
import org.analysis.system.model.custom.TitleVo;
import org.analysis.system.util.StringUtils;
import org.analysis.system.common.log.Log;
import org.analysis.system.util.ExcelUtils;
import java.util.Date;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.analysis.system.common.base.BaseController;

import java.time.LocalDateTime;
import javax.servlet.http.HttpServletResponse;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.*;


/**
 * <p>
 * 财务信息 前端控制器
 * </p>
 *
 * @author Feliz
 * @since 2020-07-28 17:17:34
 */
@Controller
@Api(tags = {"财务信息"})
@RequestMapping("/suilin/FinanceController")
public class FinanceController extends BaseController{

    private static Logger logger = LoggerFactory.getLogger(FinanceController.class);

    //跳转页面参数
    private String prefix = "projects/suilin/finance";

	@Autowired
	private FinanceService financeService;

    @Autowired
    private CommunityService communityService;

    @Autowired
    private FinanceCustomService financeCustomService;

	//跳转财务信息页面
    @GetMapping("/view")
    @RequiresPermissions("suilin:finance:view")
    public String view(Model model) {
        String str="财务信息";
        setTitle(model, new TitleVo(str+"列表", str+"管理", false, "欢迎进入"+str+"页面", false, false));
        return prefix + "/list";
    }

    @Log(title = "财务信息列表查询", action = "111")
    @ApiOperation(value = "获取财务信息列表", notes = "获取财务信息列表")
    @PostMapping("/list")
    @RequiresPermissions("suilin:finance:list")
    @ResponseBody
    public TableSplitResult<Finance> list(Tablepar tablepar, String searchText) {

        QueryWrapper<Finance> queryWrapper = new QueryWrapper<>();
        if (StringUtils.isNotEmpty(searchText)) {
            queryWrapper.and(wrapper -> wrapper
                    .like("id", searchText).or()
                    .like("date", searchText).or()
                    .like("summary", searchText).or()
                    .like("income", searchText).or()
                    .like("outcome", searchText).or()
                    .like("balance", searchText).or()
                    .like("materials_file_id", searchText).or()
                    .like("remark", searchText).or()
            );
        }

        PageHelper.startPage(tablepar.getPageNum(), tablepar.getPageSize());
        List<Finance> list = financeService.list(queryWrapper);
        PageInfo<Finance> pageInfo = new PageInfo<Finance>(list);


        return new TableSplitResult<>(pageInfo.getPageNum(), pageInfo.getTotal(), pageInfo.getList());
    }

    @ApiOperation(value = "获取全部财务信息信息", notes = "获取全部财务信息信息")
    @PostMapping("/getAllFinance")
    @ResponseBody
    public AjaxResult<TableSplitResult<Finance>> getAllFinance() {
        try {
            List<Finance> list = financeService.list();
            return AjaxResult.successDataList(list);
        } catch (Exception e) {
            logger.error(e.toString());
            return AjaxResult.error(e.getMessage());
        }
    }

    //跳转财务信息新增页面
    @GetMapping("/add")
    public String add() {
        return prefix + "/add";
    }

    @Log(title = "财务信息新增", action = "111")
    @ApiOperation(value = "添加财务信息", notes = "添加财务信息")
    @PostMapping("add")
    @RequiresPermissions("suilin:finance:add")
    @ResponseBody
    public AjaxResult add(Finance finance) {
        finance.setCreateTime(LocalDateTime.now());
        boolean save = financeService.save(finance);
        return save ? success() : error();
    }

    @Log(title = "财务信息删除", action = "111")
    @ApiOperation(value = "删除财务信息", notes = "根据id删除财务信息（可批量）")
    @PostMapping("/remove")
    @RequiresPermissions("suilin:finance:remove")
    @ResponseBody
    public AjaxResult remove(String ids) {
        List<Integer> idList= Convert.toListIntArray(ids);
        boolean delete = financeService.removeByIds(idList);
        return delete ? success() : error();
    }

    @ApiOperation(value = "检查财务信息是否存在", notes = "返回: 1-存在; 0-不存在")
    @PostMapping("/checkUnique")
    @ResponseBody
    public Integer checkUnique(Finance finance) {
        QueryWrapper<Finance> queryWrapper = new QueryWrapper<>();
        //TODO 注意是否正确，默认检测name字段
        //queryWrapper.eq("name", finance.getName());
        List<Finance> list = financeService.list(queryWrapper);
        if (list.size() > 0) {
            return 1;
        } else {
            return 0;
        }
    }

    //跳转财务信息修改页面
    @GetMapping("/edit/{id}")
    public String edit(@PathVariable("id") Integer id, ModelMap modelMap) {
        modelMap.put("finance", financeService.getById(id));
        return prefix + "/edit";
    }

    @Log(title = "财务信息修改", action = "111")
    @ApiOperation(value = "修改财务信息", notes = "修改财务信息")
    @PostMapping("/edit")
    @RequiresPermissions("suilin:finance:edit")
    @ResponseBody
    public AjaxResult editSave(Finance finance) {
        finance.setUpdateTime(LocalDateTime.now());
        boolean edit = financeService.updateById(finance);
        return edit ? success() : error();
    }


    //跳转财务信息批量新增页面
    @GetMapping("/batchAdd")
    public String batchAdd() {
        return prefix + "/batchAdd";
    }

    @Log(title = "财务信息批量导入", action = "111")
    @ApiOperation(value = "批量导入财务信息", notes = "批量导入财务信息")
    @RequiresPermissions("suilin:finance:add")
    @Transactional(propagation = Propagation.REQUIRED)
    @PostMapping("/batchAdd")
    @ResponseBody
    public AjaxResult batchAdd(@RequestParam(value = "file", required = false) MultipartFile file) {
        try {
            String suffer = file.getOriginalFilename().substring(file.getOriginalFilename().indexOf(".") + 1);
            if ("xls".equals(suffer) || "xlsx".equals(suffer)) {
                InputStream in = file.getInputStream();
                Map<String, String> fields = new LinkedHashMap<String, String>();

                fields.put("日期", "date");
                fields.put("摘要", "summary");
                fields.put("收入，单位分", "income");
                fields.put("支出，单位分", "outcome");
                fields.put("余额，单位分", "balance");
                fields.put("证明/合同材料file-id", "materialsFileId");
                fields.put("备注", "remark");

                List<Finance> list = new ArrayList<Finance>();
                list = ExcelUtils.ExecltoList(in, Finance.class, fields);

                int sum = list.size();//总需导入数
                int successNum = 0;//成功导入数
                int failNum = 0;//失败导入数
                for (Finance o : list) {

                    if (checkUnique(o) == 0) {
                        add(o);
                        successNum++;
                    }else {
                        failNum++;
                    }
                }

                return success("总需导入数：" + sum + "</br>成功导入数：" + successNum +" </br>失败导入数：" + failNum);
            }
            return error("上传文件格式应为xls或xlsx");

        } catch (Exception e) {
            logger.error(ExceptionUtils.getFullStackTrace(e));
            return error("上传文件模板有误，请对比导入模板！");
        }
    }

    @Log(title = "财务信息导入模板获取", action = "111")
    @GetMapping("/getExcelModel")
    @ResponseBody
    public void getUserCardExcelModel(HttpServletResponse response) throws Exception {
        OutputStream out = null;
        //通过response对象获取outputStream流
        response.setContentType("application/octect-stream"); // 下载文件能正常显示中文
        response.setHeader("Content-Disposition", "attachment;filename=" + new String(("财务信息的导入模板.xls").getBytes("gb2312"), "ISO8859-1"));
        out = response.getOutputStream();

        Map<String, String> fields = new LinkedHashMap<String, String>();

        fields.put("date", "日期");
        fields.put("summary", "摘要");
        fields.put("income", "收入，单位分");
        fields.put("outcome", "支出，单位分");
        fields.put("balance", "余额，单位分");
        fields.put("materialsFileId", "证明/合同材料file-id");
        fields.put("remark", "备注");

        ExcelUtils.ListtoExecl(null, out, fields);
        out.flush();
        out.close();
    }

	@ApiOperation("获取小区财务统计")
    @PostMapping("/statistics")
    @ResponseBody
    public AjaxResult<FinanceStatisticsVO> getFinanceStatistics(@RequestParam String date) {

        DateTime dateTime = DateUtil.parse(date);
        DateTime start = DateUtil.beginOfMonth(dateTime);
        DateTime end = DateUtil.endOfMonth(dateTime);

        FinanceStatisticsVO financeStatistics = financeCustomService.getFinanceStatistics(start, end);
        return AjaxResult.successData(financeStatistics);
    }

    @ApiOperation("获取小区财务概况")
    @GetMapping("/statistics/finance")
    @ResponseBody
    public AjaxResult<FinanceSummaryVO> getFinanceStatistics() {
        return AjaxResult.successData(financeCustomService.getFinanceSummary());
    }
}
