package org.analysis.projects.suilin.mapper.auto;

import org.analysis.projects.suilin.model.auto.PostInfo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 帖子表 Mapper 接口
 * </p>
 *
 * @author Feliz
 * @since 2020-08-19
 */
public interface PostInfoMapper extends BaseMapper<PostInfo> {

}
