package org.analysis.projects.brainwave.controller;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.analysis.projects.brainwave.model.auto.EegDevice;
import org.analysis.projects.brainwave.service.auto.EegDeviceService;
import org.analysis.system.common.base.BaseController;
import org.analysis.system.common.domain.AjaxResult;
import org.analysis.system.common.domain.TableSplitResult;
import org.analysis.system.common.domain.Tablepar;
import org.analysis.system.common.support.Convert;
import org.analysis.system.model.custom.TitleVo;
import org.analysis.system.util.StringUtils;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

/**
 * <p>
 * 前端控制器
 * </p>
 *
 * @author Feliz
 * @since 2019-05-20
 */
@Controller
@Api(tags = {"脑波设备"})
@RequestMapping("/brainwave/eeg-device")
public class EegDeviceController extends BaseController {

    private static Logger logger = LoggerFactory.getLogger(EegDeviceController.class);

    @Autowired
    private EegDeviceService eegDeviceService;

    //跳转页面参数
    private String prefix = "projects/brainwave/device";

    @ApiOperation(value = "获取全部设备数据", notes = "获取全部设备数据")
    @PostMapping("getalleegdevice")
    @ResponseBody
    public AjaxResult<TableSplitResult<EegDevice>> getAllEegDevice() {
        try {
            List<EegDevice> list = eegDeviceService.list();
            return AjaxResult.successDataList(list);
        } catch (Exception e) {
            logger.error(e.toString());
            return AjaxResult.error(e.getMessage());
        }
    }

    @ApiOperation(value = "跳转脑波设备管理页面", notes = "跳转到脑波设备管理页面", hidden = true)
    @GetMapping("view")
    @RequiresPermissions("brainwave:device:view")
    public String view(Model model) {
        setTitle(model, new TitleVo("设备列表", "穿戴设备管理", false, "欢迎进入穿戴设备管理页面", false, false));
        return prefix + "/list";
    }

    @ApiOperation(value = "获取设备列表", notes = "获取设备列表")
    @PostMapping("list")
    @RequiresPermissions("brainwave:device:list")
    @ResponseBody
    public TableSplitResult<EegDevice> list(Tablepar tablepar, String searchText) {

        QueryWrapper<EegDevice> queryWrapper = new QueryWrapper<>();
        if (StringUtils.isNotEmpty(searchText)) {
            queryWrapper.like("device_name", searchText).or().like("device_type", searchText).or().like("description", searchText);
        }

        PageHelper.startPage(tablepar.getPageNum(), tablepar.getPageSize());
        List<EegDevice> list = eegDeviceService.list(queryWrapper);
        PageInfo<EegDevice> pageInfo = new PageInfo<EegDevice>(list);

        return new TableSplitResult<>(pageInfo.getPageNum(), pageInfo.getTotal(), pageInfo.getList());
    }


    @ApiOperation(value = "跳转新增设备页面", notes = "跳转新增设备页面", hidden = true)
    @GetMapping("/add")
    public String add() {
        return prefix + "/add";
    }


    @ApiOperation(value = "添加设备", notes = "添加新的设备")
    @PostMapping("add")
    @RequiresPermissions("brainwave:device:add")
    @ResponseBody
    public AjaxResult add(EegDevice eegDevice) {
        boolean save = eegDeviceService.save(eegDevice);
        if (save) {
            return success();
        } else {
            return error();
        }
    }

    @ApiOperation(value = "删除设备", notes = "根据id删除设备（批量）")
    @PostMapping("remove")
    @RequiresPermissions("brainwave:device:remove")
    @ResponseBody
    public AjaxResult remove(String ids) {
        List<String> idList = Convert.toListStrArray(ids);
        boolean save = eegDeviceService.removeByIds(idList);
        if (save) {
            return success();
        } else {
            return error();
        }
    }


    @ApiOperation(value = "检查设备名字是否存在", notes = "传入: deviceName; 返回: 1-存在; 0-不存在")
    @PostMapping("checkNameUnique")
    @ResponseBody
    public Integer checkNameUnique(String deviceName) {
        QueryWrapper<EegDevice> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("device_name", deviceName);
        List<EegDevice> list = eegDeviceService.list(queryWrapper);
        if (list.size() > 0) {
            return 1;
        } else {
            return 0;
        }
    }

    @ApiOperation(value = "跳转设备修改页面", notes = "跳转到设备修改页面", hidden = true)
    @GetMapping("/edit/{id}")
    public String edit(@PathVariable("id") String id, ModelMap mmap) {
        mmap.put("eegDevice", eegDeviceService.getById(id));
        return prefix + "/edit";
    }


    @ApiOperation(value = "修改设备", notes = "修改保存设备")
    @PostMapping("/edit")
    @RequiresPermissions("brainwave:device:edit")
    @ResponseBody
    public AjaxResult editSave(EegDevice eegDevice) {
        eegDevice.setUpdateTime(LocalDateTime.now());
        boolean b = eegDeviceService.updateById(eegDevice);
        return b ? success() : error();
    }
}

