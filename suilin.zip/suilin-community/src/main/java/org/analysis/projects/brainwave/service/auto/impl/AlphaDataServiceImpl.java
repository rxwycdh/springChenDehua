package org.analysis.projects.brainwave.service.auto.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.analysis.projects.brainwave.mapper.auto.AlphaDataMapper;
import org.analysis.projects.brainwave.model.auto.AlphaData;
import org.analysis.projects.brainwave.service.auto.AlphaDataService;
import org.springframework.stereotype.Service;

/**
 * <p>
 * alpha脑波数据表 服务实现类
 * </p>
 *
 * @author Feliz
 * @since 2019-06-06
 */
@Service
public class AlphaDataServiceImpl extends ServiceImpl<AlphaDataMapper, AlphaData> implements AlphaDataService {

}
