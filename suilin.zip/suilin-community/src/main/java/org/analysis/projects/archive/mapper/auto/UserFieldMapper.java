package org.analysis.projects.archive.mapper.auto;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.analysis.projects.archive.model.auto.UserField;
import org.apache.ibatis.annotations.CacheNamespace;

/**
 * <p>
 * 档案用户字段值 Mapper 接口
 * </p>
 *
 * @author Feliz
 * @since 2019-09-10
 */
@CacheNamespace(flushInterval = 3600000, size = 4096)
public interface UserFieldMapper extends BaseMapper<UserField> {

}
