package org.analysis.projects.suilin.common.util;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.util.StrUtil;

import java.util.List;
import java.util.stream.Collectors;

/**
 * @author ChenDehua  597701764@qq.com
 * @date 2020/8/19 9:50
 */
public class SplitUtil {

    /**
     * 将采用逗号分隔的字符串转为列表
     * @param splitStr 拼接的字符串例如 "2,3,4,5,6"
     * @return 列表 例如[2,3,4,5,6]
     */
    public static List<Integer> slice(String splitStr) {

        List<String> split = StrUtil.split(splitStr, ',');
        return split.stream().map(Integer::parseInt).collect(Collectors.toList());
    }

    /**
     * 将列表用逗号分隔变为字符串
     * @param list 列表
     * @return 拼接后的字符串
     */
    public static String splitJoint(List<Integer> list) {
        return CollUtil.join(list, ",");
    }
}
