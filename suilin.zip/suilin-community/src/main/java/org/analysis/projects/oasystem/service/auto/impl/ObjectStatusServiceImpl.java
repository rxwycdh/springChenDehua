package org.analysis.projects.oasystem.service.auto.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.analysis.projects.oasystem.mapper.auto.ObjectStatusMapper;
import org.analysis.projects.oasystem.model.auto.ObjectStatus;
import org.analysis.projects.oasystem.service.auto.ObjectStatusService;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 状态信息 服务实现类
 * </p>
 *
 * @author Feliz
 * @since 2019-06-14
 */
@Service
public class ObjectStatusServiceImpl extends ServiceImpl<ObjectStatusMapper, ObjectStatus> implements ObjectStatusService {

}
