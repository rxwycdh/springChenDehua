package org.analysis.projects.suilin.model.auto;

import java.math.BigDecimal;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import java.time.LocalDateTime;
import com.baomidou.mybatisplus.annotation.TableLogic;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.springframework.format.annotation.DateTimeFormat;

/**
 * <p>
 * 小区信息
 * </p>
 *
 * @author Feliz
 * @since 2020-08-18
 */
@TableName("suilin_community")
@ApiModel(value="Community对象", description="小区信息")
public class Community implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @TableField("suilin_community_id")
    private Integer suilinCommunityId;

    @ApiModelProperty(value = "小区名称")
    @TableField("name")
    private String name;

    @ApiModelProperty(value = "小区头像file-id")
    @TableField("avatar_file_id")
    private Integer avatarFileId;

    @ApiModelProperty(value = "小区简介")
    @TableField("introduction")
    private String introduction;

    @ApiModelProperty(value = "户数")
    @TableField("household")
    private Integer household;

    @ApiModelProperty(value = "人口数")
    @TableField("population")
    private Integer population;

    @ApiModelProperty(value = "占地面积")
    @TableField("floor_area")
    private BigDecimal floorArea;

    @ApiModelProperty(value = "建筑面积")
    @TableField("buil_area")
    private BigDecimal builArea;

    @ApiModelProperty(value = "成立日期")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @TableField("establishment_data")
    private LocalDateTime establishmentData;

    @ApiModelProperty(value = "开发商")
    @TableField("developer")
    private String developer;

    @ApiModelProperty(value = "物业公司")
    @TableField("property_company")
    private String propertyCompany;

    @ApiModelProperty(value = "地址")
    @TableField("address")
    private String address;

    @ApiModelProperty(value = "小区余额，单位分")
    @TableField("community_balance")
    private Integer communityBalance;

    @ApiModelProperty(value = "版本号")
    @TableField("version")
    private Integer version;

    @ApiModelProperty(value = "逻辑删除；0：未删除；1：已删除")
    @TableField("deleted")
    @TableLogic
    private Integer deleted;

    @ApiModelProperty(value = "注册时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @TableField("create_time")
    private LocalDateTime createTime;

    @ApiModelProperty(value = "修改时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @TableField("update_time")
    private LocalDateTime updateTime;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getSuilinCommunityId() {
        return suilinCommunityId;
    }

    public void setSuilinCommunityId(Integer suilinCommunityId) {
        this.suilinCommunityId = suilinCommunityId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getAvatarFileId() {
        return avatarFileId;
    }

    public void setAvatarFileId(Integer avatarFileId) {
        this.avatarFileId = avatarFileId;
    }

    public String getIntroduction() {
        return introduction;
    }

    public void setIntroduction(String introduction) {
        this.introduction = introduction;
    }

    public Integer getHousehold() {
        return household;
    }

    public void setHousehold(Integer household) {
        this.household = household;
    }

    public Integer getPopulation() {
        return population;
    }

    public void setPopulation(Integer population) {
        this.population = population;
    }

    public BigDecimal getFloorArea() {
        return floorArea;
    }

    public void setFloorArea(BigDecimal floorArea) {
        this.floorArea = floorArea;
    }

    public BigDecimal getBuilArea() {
        return builArea;
    }

    public void setBuilArea(BigDecimal builArea) {
        this.builArea = builArea;
    }

    public LocalDateTime getEstablishmentData() {
        return establishmentData;
    }

    public void setEstablishmentData(LocalDateTime establishmentData) {
        this.establishmentData = establishmentData;
    }

    public String getDeveloper() {
        return developer;
    }

    public void setDeveloper(String developer) {
        this.developer = developer;
    }

    public String getPropertyCompany() {
        return propertyCompany;
    }

    public void setPropertyCompany(String propertyCompany) {
        this.propertyCompany = propertyCompany;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public Integer getCommunityBalance() {
        return communityBalance;
    }

    public void setCommunityBalance(Integer communityBalance) {
        this.communityBalance = communityBalance;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public Integer getDeleted() {
        return deleted;
    }

    public void setDeleted(Integer deleted) {
        this.deleted = deleted;
    }

    public LocalDateTime getCreateTime() {
        return createTime;
    }

    public void setCreateTime(LocalDateTime createTime) {
        this.createTime = createTime;
    }

    public LocalDateTime getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(LocalDateTime updateTime) {
        this.updateTime = updateTime;
    }

    @Override
    public String toString() {
        return "Community{" +
        "id=" + id +
        ", suilinCommunityId=" + suilinCommunityId +
        ", name=" + name +
        ", avatarFileId=" + avatarFileId +
        ", introduction=" + introduction +
        ", household=" + household +
        ", population=" + population +
        ", floorArea=" + floorArea +
        ", builArea=" + builArea +
        ", establishmentData=" + establishmentData +
        ", developer=" + developer +
        ", propertyCompany=" + propertyCompany +
        ", address=" + address +
        ", communityBalance=" + communityBalance +
        ", version=" + version +
        ", deleted=" + deleted +
        ", createTime=" + createTime +
        ", updateTime=" + updateTime +
        "}";
    }
}
