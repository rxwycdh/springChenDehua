package org.analysis.projects.suilin.service.auto.impl;

import org.analysis.projects.suilin.model.auto.Owner;
import org.analysis.projects.suilin.mapper.auto.OwnerMapper;
import org.analysis.projects.suilin.service.auto.OwnerService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 业主信息 服务实现类
 * </p>
 *
 * @author Feliz
 * @since 2020-08-04
 */
@Service
public class OwnerServiceImpl extends ServiceImpl<OwnerMapper, Owner> implements OwnerService {

}
