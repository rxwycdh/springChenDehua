package org.analysis.projects.suilin.mapper.auto;

import org.analysis.projects.suilin.model.auto.PostCommentReply;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 评论回复表 Mapper 接口
 * </p>
 *
 * @author Feliz
 * @since 2020-08-19
 */
public interface PostCommentReplyMapper extends BaseMapper<PostCommentReply> {

}
