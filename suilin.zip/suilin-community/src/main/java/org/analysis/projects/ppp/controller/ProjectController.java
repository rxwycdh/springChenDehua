package org.analysis.projects.ppp.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.analysis.projects.ppp.logic.ProjectTagLogic;
import org.analysis.projects.ppp.model.auto.Project;
import org.analysis.projects.ppp.model.auto.ProjectType;
import org.analysis.projects.ppp.model.custom.ProjectVO;
import org.analysis.projects.ppp.service.auto.ProjectDynamicService;
import org.analysis.projects.ppp.service.auto.ProjectService;
import org.analysis.projects.ppp.service.auto.ProjectTypeService;
import org.analysis.projects.ppp.service.auto.ServerUserService;
import org.analysis.system.common.base.BaseController;
import org.analysis.system.common.domain.AjaxResult;
import org.analysis.system.common.domain.TableSplitResult;
import org.analysis.system.common.domain.Tablepar;
import org.analysis.system.common.log.Log;
import org.analysis.system.common.support.Convert;
import org.analysis.system.model.auto.TsysUser;
import org.analysis.system.model.custom.TitleVo;
import org.analysis.system.shiro.util.ShiroUtils;
import org.analysis.system.util.StringUtils;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;


/**
 * <p>
 * 项目信息 前端控制器
 * </p>
 *
 * @author Feliz
 * @since 2020-04-03 15:08:51
 */
@Controller
@Api(tags = {"项目信息"})
@RequestMapping("/ppp/ProjectController")
public class ProjectController extends BaseController{

    private static Logger logger = LoggerFactory.getLogger(ProjectController.class);

    //跳转页面参数
    private String prefix = "projects/ppp/project";

	@Autowired
	private ProjectService projectService;
	@Autowired
    private ProjectTypeService projectTypeService;
	@Autowired
    private ServerUserService serverUserService;
	@Autowired
    private ProjectTagLogic projectTagLogic;
	@Autowired
    private ProjectDynamicService projectDynamicService;

	//跳转项目信息页面
    @GetMapping("/view")
    @RequiresPermissions("ppp:project:view")
    public String view(Model model) {
        String str="项目信息";
        setTitle(model, new TitleVo(str+"列表", str+"管理", false, "欢迎进入"+str+"页面", false, false));
        return prefix + "/list";
    }

    @Log(title = "项目信息列表查询", action = "111")
    @ApiOperation(value = "获取项目信息列表", notes = "获取项目信息列表")
    @PostMapping("/list")
    @RequiresPermissions("ppp:project:list")
    @ResponseBody
    public TableSplitResult<ProjectVO> list(Tablepar tablepar, String searchText) {

        QueryWrapper<Project> queryWrapper = new QueryWrapper<>();
        if (StringUtils.isNotEmpty(searchText)) {
            queryWrapper.and(wrapper -> wrapper
                    .like("title", searchText).or()
                    .like("publish_unit", searchText).or()
                    .like("location", searchText).or()
            );
        }

        queryWrapper.orderByAsc("state","create_time");
        PageHelper.startPage(tablepar.getPageNum(), tablepar.getPageSize());
        List<Project> projects = projectService.list(queryWrapper);
        PageInfo<Project> pageInfo = new PageInfo<Project>(projects);

        List<ProjectVO> list = new ArrayList<>();
        for (Project p : projects) {
            ProjectVO projectVO = new ProjectVO();

            try {
                BeanUtils.copyProperties(projectVO, p);
            } catch (Exception e) {
                logger.error(e.getMessage());
            }

            ProjectType projectType = projectTypeService.getById(p.getTypeId());
            projectVO.setTypeName(projectType!=null ? projectType.getName() : "");

            if (p.getState() == 1) {
                TsysUser tsysUser = sysUserService.selectByPrimaryKey(p.getAuditorId());
                projectVO.setAuditorName(tsysUser!=null ? tsysUser.getUsername() : "");
            }

            String tagsName = projectTagLogic.queryProjectTags(p.getId());
            projectVO.setTagsName(tagsName);

            list.add(projectVO);
        }

        return new TableSplitResult<>(pageInfo.getPageNum(), pageInfo.getTotal(), list);
    }

    @ApiOperation(value = "获取全部项目信息信息", notes = "获取全部项目信息信息")
    @PostMapping("/getAllProject")
    @ResponseBody
    public AjaxResult<TableSplitResult<Project>> getAllProject() {
        try {
            List<Project> list = projectService.list();
            return AjaxResult.successDataList(list);
        } catch (Exception e) {
            logger.error(e.toString());
            return AjaxResult.error(e.getMessage());
        }
    }

    //跳转项目信息新增页面
    @GetMapping("/add")
    public String add() {
        return prefix + "/add";
    }

    @Log(title = "项目信息新增", action = "111")
    @ApiOperation(value = "添加项目信息", notes = "添加项目信息")
    @PostMapping("add")
    @RequiresPermissions("ppp:project:add")
    @Transactional
    @ResponseBody
    public AjaxResult add(Project project, String tagsName) {

        try {
            project.setState(0);
            project.setCreateTime(LocalDateTime.now());

            boolean save = projectService.save(project);
            //添加标签
            projectTagLogic.addProjectTags(project.getId(), tagsName);

            return save ? success() : error();
        } catch (Exception e) {
            logger.error(ExceptionUtils.getFullStackTrace(e));
            return error();
        }
    }

    @Log(title = "项目信息删除", action = "111")
    @ApiOperation(value = "删除项目信息", notes = "根据id删除项目信息（可批量）")
    @PostMapping("/remove")
    @RequiresPermissions("ppp:project:remove")
    @Transactional
    @ResponseBody
    public AjaxResult remove(String ids) {
        try {
            List<Integer> idList= Convert.toListIntArray(ids);

            //删除标签
            for (Integer id : idList) {
                projectTagLogic.removeArticleTags(id);
            }
            boolean delete = projectService.removeByIds(idList);
            return delete ? success() : error();
        } catch (Exception e) {
            logger.error(ExceptionUtils.getFullStackTrace(e));
            return error();
        }
    }


    //跳转项目信息修改页面
    @GetMapping("/edit/{id}")
    public String edit(@PathVariable("id") Integer id, ModelMap mmap) {

        Project p = projectService.getById(id);
        ProjectVO projectVO = new ProjectVO();
        try {
            BeanUtils.copyProperties(projectVO, p);
        } catch (Exception e) {
            logger.error(e.getMessage());
        }
        String tagsName = projectTagLogic.queryProjectTags(p.getId());
        projectVO.setTagsName(String.join(",", tagsName));

        mmap.put("projectVO", projectVO);

        return prefix + "/edit";
    }

    @Log(title = "项目信息修改", action = "111")
    @ApiOperation(value = "修改项目信息", notes = "修改项目信息")
    @PostMapping("/edit")
    @RequiresPermissions("ppp:project:edit")
    @Transactional
    @ResponseBody
    public AjaxResult editSave(Project project,  String tagsName) {

        try {
            //删除旧标签重新添加新标签
            projectTagLogic.removeArticleTags(project.getId());
            projectTagLogic.addProjectTags(project.getId(), tagsName);

            boolean edit = projectService.updateById(project);
            return edit ? success() : error();
        } catch (Exception e) {
            logger.error(ExceptionUtils.getFullStackTrace(e));
            return error();
        }
    }

    //跳转项目详细信息页面
    @GetMapping("/detail/{id}")
    public String detail(@PathVariable("id") Integer id, ModelMap mmap) {

        Project p = projectService.getById(id);
        ProjectVO projectVO = new ProjectVO();

        try {
            BeanUtils.copyProperties(projectVO, p);
        } catch (Exception e) {
            logger.error(e.getMessage());
        }

        ProjectType projectType = projectTypeService.getById(p.getTypeId());
        projectVO.setTypeName(projectType!=null ? projectType.getName() : "");

        String tagsName = projectTagLogic.queryProjectTags(p.getId());
        projectVO.setTagsName(String.join(",", tagsName));

        mmap.put("projectVO", projectVO);
        return prefix + "/detail";
    }


    //跳转审核项目页面
    @GetMapping("/audit/{id}")
    public String audit(@PathVariable("id") Integer id, ModelMap mmap) {
        Project p = projectService.getById(id);
        ProjectVO projectVO = new ProjectVO();

        try {
            BeanUtils.copyProperties(projectVO, p);
        } catch (Exception e) {
            logger.error(e.getMessage());
        }

        ProjectType projectType = projectTypeService.getById(p.getTypeId());
        projectVO.setTypeName(projectType!=null ? projectType.getName() : "");

        String tagsName = projectTagLogic.queryProjectTags(p.getId());
        projectVO.setTagsName(String.join(",", tagsName));

        mmap.put("projectVO", projectVO);
        return prefix + "/audit";
    }

    @Log(title = "审核项目", action = "111")
    @ApiOperation(value = "审核项目", notes = "审核项目")
    @PostMapping("/audit")
    @RequiresPermissions("ppp:project:edit")
    @ResponseBody
    public AjaxResult audit(ProjectVO projectVO, Integer audit) {
        Project project = projectService.getById(projectVO.getId());
        if (audit == 1) {
            project.setState(1);
        }else {
            project.setState(2);
        }

        project.setAuditorId(ShiroUtils.getUserId());
        project.setAuditOpinion(projectVO.getAuditOpinion());
        project.setUpdateTime(LocalDateTime.now());

        boolean b = projectService.updateById(project);
        return b ? success() : error();
    }

    @Log(title = "上架项目", action = "111")
    @ApiOperation(value = "上架项目", notes = "上架项目")
    @GetMapping("/upProject/{id}")
    @RequiresPermissions("ppp:project:edit")
    @ResponseBody
    public AjaxResult upProject(@PathVariable("id") Integer id) {
        Project project = projectService.getById(id);
        project.setState(1);
        project.setUpdateTime(LocalDateTime.now());

        boolean b = projectService.updateById(project);
        return b ? success() : error();
    }

    @Log(title = "下架项目", action = "111")
    @ApiOperation(value = "下架项目", notes = "下架项目")
    @GetMapping("/offProject/{id}")
    @RequiresPermissions("ppp:project:edit")
    @ResponseBody
    public AjaxResult offProject(@PathVariable("id") Integer id) {
        Project project = projectService.getById(id);
        project.setState(3);
        project.setAuditOpinion("项目因违反相关规定已下架,如有问题请联系我们,多谢理解。");
        project.setUpdateTime(LocalDateTime.now());

        boolean b = projectService.updateById(project);
        return b ? success() : error();
    }

//    @Log(title = "取消项目", action = "111")
//    @ApiOperation(value = "取消项目", notes = "取消项目")
//    @GetMapping("/cancel/{id}")
//    @RequiresPermissions("ppp:project:edit")
//    @Transactional
//    @ResponseBody
//    public AjaxResult cancel(@PathVariable("id") Integer id) {
//        try {
//            Project project = projectService.getById(id);
//            project.setState(4);
//            project.setUpdateTime(LocalDateTime.now());
//
//            //更新动态
//            QueryWrapper<ProjectDynamic> queryWrapper = new QueryWrapper<>();
//            queryWrapper.eq("project_id", id);
//            List<ProjectDynamic> projectDynamics = projectDynamicService.list(queryWrapper);
//            for (ProjectDynamic pd : projectDynamics) {
//                pd.setState(3);
//                projectDynamicService.updateById(pd);
//            }
//
//            boolean b = projectService.updateById(project);
//            return b ? success() : error();
//        } catch (Exception e) {
//            logger.error(ExceptionUtils.getFullStackTrace(e));
//            return error();
//        }
//    }

}
