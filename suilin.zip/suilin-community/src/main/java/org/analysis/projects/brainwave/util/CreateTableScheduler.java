package org.analysis.projects.brainwave.util;

import org.analysis.projects.brainwave.mapper.custom.OperateTableDao;
import org.analysis.system.service.SysKvSettingService;
import org.analysis.system.util.LocalDateTimeUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;

/**
 * 创建数据表定时器，每小时创建一个表（提前5分钟创建）
 */
@Component
public class CreateTableScheduler {
    private static Logger logger = LoggerFactory.getLogger(CreateTableScheduler.class);

    private static final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMddHH");
    private static final String openingCreateBWTbale = "openingCreateBWTbale";

    @Autowired
    private OperateTableDao operateTableDao;
    @Autowired
    private SysKvSettingService sysKvSettingService;

    //每小时提前5分钟执行
    @Scheduled(cron = "0 50 * ? * *")
    public void testTasks() {
        if ("1".equals(sysKvSettingService.getValueByDicKey(openingCreateBWTbale))) {
            String time = LocalDateTimeUtils.formatTime(LocalDateTimeUtils.plus(LocalDateTime.now(), 1, ChronoUnit.HOURS),
                    "yyyyMMddHH");
            logger.info("定时任务--正在创建表：" + "brainwave_raw_data_"+ time);
            operateTableDao.createTodolist("brainwave_raw_data_"+ time);
        }
    }

}
