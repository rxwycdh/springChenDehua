package org.analysis.projects.oasystem.mapper.auto;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.analysis.projects.oasystem.model.auto.Dept;
import org.apache.ibatis.annotations.CacheNamespace;

/**
 * <p>
 * 部门信息 Mapper 接口
 * </p>
 *
 * @author Feliz
 * @since 2019-06-14
 */
@DS("db_oasystem")
@CacheNamespace(flushInterval = 3600000, size = 4096)
public interface DeptMapper extends BaseMapper<Dept> {

}
