package org.analysis.projects.ppp.model.custom;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * <p>
 * 项目信息
 * </p>
 *
 * @author Feliz
 * @since 2020-04-03
 */
@ApiModel(value="Project对象", description="项目信息")
public class ServerProjectIF implements Serializable {

    private static final long serialVersionUID = 1L;

    private Integer id;

    @ApiModelProperty(value = "项目标题")
    private String title;

    @ApiModelProperty(value = "项目状态；0：待审核；1：已通过；2：未通过；3：下架中；4：已取消")
    private Integer state;

    @ApiModelProperty(value = "项目类型")
    private String typeName;

    @ApiModelProperty(value = "发布单位")
    private String publishUnit;

    @ApiModelProperty(value = "项目地址")
    private String location;

    @ApiModelProperty(value = "审核意见")
    private String auditOpinion;

    @ApiModelProperty(value = "发布时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime createTime;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Integer getState() {
        return state;
    }

    public void setState(Integer state) {
        this.state = state;
    }

    public String getPublishUnit() {
        return publishUnit;
    }

    public void setPublishUnit(String publishUnit) {
        this.publishUnit = publishUnit;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getTypeName() {
        return typeName;
    }

    public void setTypeName(String typeName) {
        this.typeName = typeName;
    }

    public String getAuditOpinion() {
        return auditOpinion;
    }

    public void setAuditOpinion(String auditOpinion) {
        this.auditOpinion = auditOpinion;
    }

    public LocalDateTime getCreateTime() {
        return createTime;
    }

    public void setCreateTime(LocalDateTime createTime) {
        this.createTime = createTime;
    }

    @Override
    public String toString() {
        return "ServerProjectIF{" +
                "id=" + id +
                ", title='" + title + '\'' +
                ", state=" + state +
                ", typeName='" + typeName + '\'' +
                ", publishUnit='" + publishUnit + '\'' +
                ", location='" + location + '\'' +
                ", auditOpinion='" + auditOpinion + '\'' +
                ", createTime=" + createTime +
                '}';
    }
}
