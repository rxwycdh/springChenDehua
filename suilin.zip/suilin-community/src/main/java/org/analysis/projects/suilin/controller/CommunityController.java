package org.analysis.projects.suilin.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.analysis.projects.suilin.model.auto.Community;
import org.analysis.projects.suilin.service.auto.CommunityService;
import org.analysis.system.common.domain.AjaxResult;
import org.analysis.system.common.domain.TableSplitResult;
import org.analysis.system.common.domain.Tablepar;
import org.analysis.system.common.support.Convert;
import org.analysis.system.model.custom.TitleVo;
import org.analysis.system.util.StringUtils;
import org.analysis.system.common.log.Log;
import org.analysis.system.util.ExcelUtils;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.analysis.system.common.base.BaseController;

import java.time.LocalDateTime;
import javax.servlet.http.HttpServletResponse;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.*;


/**
 * <p>
 * 小区信息 前端控制器
 * </p>
 *
 * @author Feliz
 * @since 2020-07-28 16:53:34
 */
@Controller
@Api(tags = {"小区信息"})
@RequestMapping("/suilin/CommunityController")
public class CommunityController extends BaseController{

    private static Logger logger = LoggerFactory.getLogger(CommunityController.class);

    //跳转页面参数
    private String prefix = "projects/suilin/community";

	@Autowired
	private CommunityService communityService;

	//跳转小区信息页面
    @GetMapping("/view")
    @RequiresPermissions("suilin:community:view")
    public String view(Model model) {
        String str="小区信息";
        setTitle(model, new TitleVo(str+"列表", str+"管理", false, "欢迎进入"+str+"页面", false, false));
        return prefix + "/list";
    }

    @Log(title = "小区信息列表查询", action = "111")
    @ApiOperation(value = "获取小区信息列表", notes = "获取小区信息列表")
    @PostMapping("/list")
    @RequiresPermissions("suilin:community:list")
    @ResponseBody
    public TableSplitResult<Community> list(Tablepar tablepar, String searchText) {

        QueryWrapper<Community> queryWrapper = new QueryWrapper<>();
        if (StringUtils.isNotEmpty(searchText)) {
            queryWrapper.and(wrapper -> wrapper
                    .like("id", searchText).or()
                    .like("suilin_community_id", searchText).or()
                    .like("name", searchText).or()
                    .like("avatar_file_id", searchText).or()
                    .like("introduction", searchText).or()
                    .like("household", searchText).or()
                    .like("population", searchText).or()
                    .like("floor_area", searchText).or()
                    .like("buil_area", searchText).or()
                    .like("establishment_data", searchText).or()
                    .like("developer", searchText).or()
                    .like("property_company", searchText).or()
                    .like("address", searchText).or()
                    .like("community_balance", searchText).or()
                    .like("version", searchText).or()
            );
        }

        PageHelper.startPage(tablepar.getPageNum(), tablepar.getPageSize());
        List<Community> list = communityService.list(queryWrapper);
        PageInfo<Community> pageInfo = new PageInfo<Community>(list);

        return new TableSplitResult<>(pageInfo.getPageNum(), pageInfo.getTotal(), pageInfo.getList());
    }

    @ApiOperation(value = "获取全部小区信息信息", notes = "获取全部小区信息信息")
    @PostMapping("/getAllCommunity")
    @ResponseBody
    public AjaxResult<TableSplitResult<Community>> getAllCommunity() {
        try {
            List<Community> list = communityService.list();
            return AjaxResult.successDataList(list);
        } catch (Exception e) {
            logger.error(e.toString());
            return AjaxResult.error(e.getMessage());
        }
    }

    //跳转小区信息新增页面
    @GetMapping("/add")
    public String add() {
        return prefix + "/add";
    }

    @Log(title = "小区信息新增", action = "111")
    @ApiOperation(value = "添加小区信息", notes = "添加小区信息")
    @PostMapping("add")
    @RequiresPermissions("suilin:community:add")
    @ResponseBody
    public AjaxResult add(Community community) {
        community.setCreateTime(LocalDateTime.now());
        boolean save = communityService.save(community);
        return save ? success() : error();
    }

    @Log(title = "小区信息删除", action = "111")
    @ApiOperation(value = "删除小区信息", notes = "根据id删除小区信息（可批量）")
    @PostMapping("/remove")
    @RequiresPermissions("suilin:community:remove")
    @ResponseBody
    public AjaxResult remove(String ids) {
        List<Integer> idList= Convert.toListIntArray(ids);
        boolean delete = communityService.removeByIds(idList);
        return delete ? success() : error();
    }

    @ApiOperation(value = "检查小区信息是否存在", notes = "返回: 1-存在; 0-不存在")
    @PostMapping("/checkUnique")
    @ResponseBody
    public Integer checkUnique(Community community) {
        QueryWrapper<Community> queryWrapper = new QueryWrapper<>();
        //TODO 注意是否正确，默认检测name字段
        //queryWrapper.eq("name", community.getName());
        List<Community> list = communityService.list(queryWrapper);
        if (list.size() > 0) {
            return 1;
        } else {
            return 0;
        }
    }

    //跳转小区信息修改页面
    @GetMapping("/edit/{id}")
    public String edit(@PathVariable("id") Integer id, ModelMap modelMap,Model model) {
        String str="小区信息";
        setTitle(model, new TitleVo(str+"", str+"管理", false, "欢迎进入"+str+"页面", false, false));
        modelMap.put("community", communityService.getById(id));
        return prefix + "/edit";
    }

    @Log(title = "小区信息修改", action = "111")
    @ApiOperation(value = "修改小区信息", notes = "修改小区信息")
    @PostMapping("/edit")
    @RequiresPermissions("suilin:community:edit")
    @ResponseBody
    public AjaxResult editSave(Community community) {
        community.setUpdateTime(LocalDateTime.now());
        boolean edit = communityService.updateById(community);
        return edit ? success() : error();
    }


    //跳转小区信息批量新增页面
    @GetMapping("/batchAdd")
    public String batchAdd() {
        return prefix + "/batchAdd";
    }

    @Log(title = "小区信息批量导入", action = "111")
    @ApiOperation(value = "批量导入小区信息", notes = "批量导入小区信息")
    @RequiresPermissions("suilin:community:add")
    @Transactional(propagation = Propagation.REQUIRED)
    @PostMapping("/batchAdd")
    @ResponseBody
    public AjaxResult batchAdd(@RequestParam(value = "file", required = false) MultipartFile file) {
        try {
            String suffer = file.getOriginalFilename().substring(file.getOriginalFilename().indexOf(".") + 1);
            if ("xls".equals(suffer) || "xlsx".equals(suffer)) {
                InputStream in = file.getInputStream();
                Map<String, String> fields = new LinkedHashMap<String, String>();

                fields.put("", "suilinCommunityId");
                fields.put("小区名称", "name");
                fields.put("小区头像file-id", "avatarFileId");
                fields.put("小区简介", "introduction");
                fields.put("户数", "household");
                fields.put("人口数", "population");
                fields.put("占地面积", "floorArea");
                fields.put("建筑面积", "builArea");
                fields.put("成立日期", "establishmentData");
                fields.put("开发商", "developer");
                fields.put("物业公司", "propertyCompany");
                fields.put("地址", "address");
                fields.put("小区余额，单位分", "communityBalance");
                fields.put("版本号", "version");

                List<Community> list = new ArrayList<Community>();
                list = ExcelUtils.ExecltoList(in, Community.class, fields);

                int sum = list.size();//总需导入数
                int successNum = 0;//成功导入数
                int failNum = 0;//失败导入数
                for (Community o : list) {

                    if (checkUnique(o) == 0) {
                        add(o);
                        successNum++;
                    }else {
                        failNum++;
                    }
                }

                return success("总需导入数：" + sum + "</br>成功导入数：" + successNum +" </br>失败导入数：" + failNum);
            }
            return error("上传文件格式应为xls或xlsx");

        } catch (Exception e) {
            logger.error(ExceptionUtils.getFullStackTrace(e));
            return error("上传文件模板有误，请对比导入模板！");
        }
    }

    @Log(title = "小区信息导入模板获取", action = "111")
    @GetMapping("/getExcelModel")
    @ResponseBody
    public void getUserCardExcelModel(HttpServletResponse response) throws Exception {
        OutputStream out = null;
        //通过response对象获取outputStream流
        response.setContentType("application/octect-stream"); // 下载文件能正常显示中文
        response.setHeader("Content-Disposition", "attachment;filename=" + new String(("小区信息的导入模板.xls").getBytes("gb2312"), "ISO8859-1"));
        out = response.getOutputStream();

        Map<String, String> fields = new LinkedHashMap<String, String>();

        fields.put("suilinCommunityId", "");
        fields.put("name", "小区名称");
        fields.put("avatarFileId", "小区头像file-id");
        fields.put("introduction", "小区简介");
        fields.put("household", "户数");
        fields.put("population", "人口数");
        fields.put("floorArea", "占地面积");
        fields.put("builArea", "建筑面积");
        fields.put("establishmentData", "成立日期");
        fields.put("developer", "开发商");
        fields.put("propertyCompany", "物业公司");
        fields.put("address", "地址");
        fields.put("communityBalance", "小区余额，单位分");
        fields.put("version", "版本号");

        ExcelUtils.ListtoExecl(null, out, fields);
        out.flush();
        out.close();
    }

	
}
