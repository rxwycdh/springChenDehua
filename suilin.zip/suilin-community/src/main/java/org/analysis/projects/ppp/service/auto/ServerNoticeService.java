package org.analysis.projects.ppp.service.auto;

import org.analysis.projects.ppp.model.auto.ServerNotice;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 服务版通知信息 服务类
 * </p>
 *
 * @author Feliz
 * @since 2020-04-01
 */
public interface ServerNoticeService extends IService<ServerNotice> {

}
