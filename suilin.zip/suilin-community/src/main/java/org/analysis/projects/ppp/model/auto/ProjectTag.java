package org.analysis.projects.ppp.model.auto;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * <p>
 * 项目标签中间
 * </p>
 *
 * @author Feliz
 * @since 2020-04-03
 */
@TableName("ppp_project_tag")
@ApiModel(value="ProjectTag对象", description="项目标签中间")
public class ProjectTag implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "项目id")
    @TableField("project_id")
    private Integer projectId;

    @ApiModelProperty(value = "标签id")
    @TableField("tag_id")
    private Integer tagId;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getProjectId() {
        return projectId;
    }

    public void setProjectId(Integer projectId) {
        this.projectId = projectId;
    }

    public Integer getTagId() {
        return tagId;
    }

    public void setTagId(Integer tagId) {
        this.tagId = tagId;
    }

    @Override
    public String toString() {
        return "ProjectTag{" +
        "id=" + id +
        ", projectId=" + projectId +
        ", tagId=" + tagId +
        "}";
    }
}
