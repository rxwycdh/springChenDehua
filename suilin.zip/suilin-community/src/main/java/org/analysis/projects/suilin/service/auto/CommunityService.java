package org.analysis.projects.suilin.service.auto;

import org.analysis.projects.suilin.model.auto.Community;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 小区信息 服务类
 * </p>
 *
 * @author Feliz
 * @since 2020-07-28
 */
public interface CommunityService extends IService<Community> {

}
