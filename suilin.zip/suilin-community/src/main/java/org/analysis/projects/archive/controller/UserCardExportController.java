package org.analysis.projects.archive.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.analysis.projects.archive.model.auto.Card;
import org.analysis.projects.archive.model.auto.Field;
import org.analysis.projects.archive.model.custom.FieldValue;
import org.analysis.projects.archive.model.custom.UserFieldVO;
import org.analysis.projects.archive.service.auto.CardService;
import org.analysis.projects.archive.service.auto.FieldService;
import org.analysis.projects.archive.service.auto.UserCardService;
import org.analysis.system.common.base.BaseController;
import org.analysis.system.common.log.Log;
import org.analysis.system.common.support.Convert;
import org.analysis.system.model.auto.TsysUser;
import org.analysis.system.model.custom.TitleVo;
import org.analysis.system.util.ExcelUtils;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @ProjectName: springbootomg
 * @Package: org.analysis.projects.archive.controller
 * @ClassName: UserCardExportController
 * @Author: Sarah0429
 * @Description: ${description}
 * @Date: 2019/11/18 14:24
 * @Version: 1.0
 */
@Controller
@Api(tags = {"信息数据导出"})
@RequestMapping("/archive/UserCardExportController")
public class UserCardExportController extends BaseController {

    @Autowired
    private FieldService fieldService;
    @Autowired
    private UserCardController userCardController;
    @Autowired
    private CardService cardService;
    @Autowired
    private UserCardService userCardService;

    //跳转页面参数
    private String prefix = "projects/archive/userCardExport" ;

    /**
     * 跳转到导出页面
     */
    @ApiOperation(value = "跳转信息数据导出页面", notes = "跳转信息数据导出页面", hidden = true)
    @GetMapping("/view")
    @RequiresPermissions("archive:userCardExport:view")
    public String view(Model model) {
        String str = "信息数据导出" ;
        setTitle(model, new TitleVo(str, "信息数据导出管理", false, "欢迎进入" + str + "页面", false, false));
        List<Map<String, Object>> exportList = exportList();
        model.addAttribute("exportList", exportList);
        return prefix + "/export" ;
    }

    @ApiOperation(value = "获取信息数据字段列表", notes = "获取信息数据字段列表")
    @GetMapping("/list")
    @RequiresPermissions("archive:userCardExport:list")
    @ResponseBody
    public List<Map<String, Object>> exportList() {
        ArrayList arrayList = new ArrayList<Map<String, Object>>();
        List<Card> list = cardService.list();
        for (Card c : list) {
            Map<String, Object> map = new HashMap<>();
            List<Field> fields = fieldService.listByIds(c.getCardFieldIds());
            map.put("card", c);
            map.put("fields", fields);
            arrayList.add(map);
        }
        return arrayList;
    }


    @Log(title = "导出信息数据字段信息", action = "111")
    @ApiOperation(value = "导出信息数据字段信息", notes = "导出信息数据字段信息")
    @GetMapping("/export")
    @RequiresPermissions("archive:userCardExport:export")
    @ResponseBody
    public void export(String cardFieldIds, HttpServletResponse response) throws Exception {
        List<UserFieldVO> list = new ArrayList<>();
        List<Integer> cardFieldIdList = Convert.toListIntArray(cardFieldIds);
        List<TsysUser> archiveUsers = userCardController.listArchiveUsers().getData().getRows();

        for (TsysUser user : archiveUsers) {
            //用户-字段&值
            UserFieldVO userFieldVO = new UserFieldVO();
            userFieldVO.setUser(user);
            //字段-值集合
            Map<String, Object> map = userCardController.getFieldValueList(cardFieldIdList, user.getId());

            List<FieldValue> fieldValueList = (List<FieldValue>) map.get("fieldValueList");

            //判断字段值是否全为空（即默认值）
            boolean b = (boolean) map.get("ifAllNull");
            if (b) {
                continue;
            }

            //替换图片&附件值
            for (FieldValue fieldValue : fieldValueList) {
                if (fieldValue.getField().getFieldType().equals("附件")) {
                    fieldValue.setFieldValue("附件不支持Excel导出");
                } else if (fieldValue.getField().getFieldType().equals("图片")) {
                    fieldValue.setFieldValue("图片不支持Excel导出");
                }
                continue;
            }
            userFieldVO.setFieldValueList(fieldValueList);
            list.add(userFieldVO);
        }

        ExcelUtils.listToExcelByIds(list, "信息数据导出.xls", 6200, response);
    }

}
