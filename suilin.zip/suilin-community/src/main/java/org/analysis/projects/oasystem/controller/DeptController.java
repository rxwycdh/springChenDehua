package org.analysis.projects.oasystem.controller;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.analysis.projects.oasystem.model.auto.Dept;
import org.analysis.projects.oasystem.service.auto.DeptService;
import org.analysis.system.common.base.BaseController;
import org.analysis.system.common.domain.AjaxResult;
import org.analysis.system.common.domain.TableSplitResult;
import org.analysis.system.common.domain.Tablepar;
import org.analysis.system.common.support.Convert;
import org.analysis.system.model.custom.TitleVo;
import org.analysis.system.util.StringUtils;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * <p>
 * 部门信息 前端控制器
 * </p>
 *
 * @author Feliz
 * @since 2019-06-14
 */
@Api(tags = {"部门信息"})
@Controller
@RequestMapping("/oasystem/dept")
public class DeptController extends BaseController {

    private static Logger logger = LoggerFactory.getLogger(DeptController.class);

    @Autowired
    private DeptService deptService;

    //跳转页面参数
    private String prefix = "projects/oasystem/dept";


    @ApiOperation(value = "获取全部部门信息", notes = "获取全部部门信息")
    @PostMapping("getalldept")
    @ResponseBody
    public AjaxResult<TableSplitResult<Dept>> getAllDept() {
        try {
            List<Dept> list = deptService.list();
            return AjaxResult.successDataList(list);
        } catch (Exception e) {
            logger.error(e.toString());
            return AjaxResult.error(e.getMessage());
        }
    }

    @ApiOperation(value = "跳转部门管理页面", notes = "跳转到部门管理页面", hidden = true)
    @GetMapping("view")
    @RequiresPermissions("oasystem:staff:view")
    public String view(Model model) {
        setTitle(model, new TitleVo("部门列表", "部门管理", false, "欢迎进入部门管理页面", false, false));
        return prefix + "/list";
    }

    @ApiOperation(value = "获取部门列表", notes = "获取部门列表")
    @PostMapping("list")
    @RequiresPermissions("oasystem:staff:list")
    @ResponseBody
    public TableSplitResult<Dept> list(Tablepar tablepar, String searchText) {

        QueryWrapper<Dept> queryWrapper = new QueryWrapper<>();
        if (StringUtils.isNotEmpty(searchText)) {
            queryWrapper.like("dept_name", searchText).or().like("dept_fax", searchText).or().like("dept_tel", searchText)
                    .or().like("dept_email", searchText).or().like("address", searchText).or().like("description", searchText)
                    .or().like("manager", searchText);
        }

        PageHelper.startPage(tablepar.getPageNum(), tablepar.getPageSize());
        List<Dept> list = deptService.list(queryWrapper);
        PageInfo<Dept> pageInfo = new PageInfo<>(list);

        return new TableSplitResult<>(pageInfo.getPageNum(), pageInfo.getTotal(), pageInfo.getList());
    }


    @ApiOperation(value = "跳转新增部门页面", notes = "跳转新增部门页面", hidden = true)
    @GetMapping("/add")
    public String add() {
        return prefix + "/add";
    }

    @ApiOperation(value = "添加部门", notes = "添加新的部门")
    @PostMapping("add")
    @RequiresPermissions("oasystem:staff:add")
    @ResponseBody
    public AjaxResult add(Dept dept) {
        boolean save = deptService.save(dept);
        if (save) {
            return success();
        } else {
            return error();
        }
    }

    @ApiOperation(value = "删除部门", notes = "根据id删除部门（批量）")
    @PostMapping("remove")
    @RequiresPermissions("oasystem:staff:remove")
    @ResponseBody
    public AjaxResult remove(String ids) {
        List<String> idList= Convert.toListStrArray(ids);
        boolean save = deptService.removeByIds(idList);
        if (save) {
            return success();
        } else {
            return error();
        }
    }


    @ApiOperation(value = "检查部门名字是否存在", notes = "传入: name; 返回: 1-存在; 0-不存在")
    @PostMapping("checkNameUnique")
    @ResponseBody
    public Integer checkNameUnique(String deptName) {
        QueryWrapper<Dept> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("dept_name", deptName);
        List<Dept> list = deptService.list(queryWrapper);
        if (list.size() > 0) {
            return 1;
        } else {
            return 0;
        }
    }

    @ApiOperation(value = "跳转部门修改页面", notes = "跳转到部门修改页面", hidden = true)
    @GetMapping("/edit/{id}")
    public String edit(@PathVariable("id") String id, ModelMap mmap) {
        mmap.put("dept", deptService.getById(id));
        return prefix + "/edit";
    }

    @ApiOperation(value = "修改部门", notes = "修改保存部门")
    @PostMapping("/edit")
    @RequiresPermissions("oasystem:staff:edit")
    @ResponseBody
    public AjaxResult editSave(Dept dept) {
        boolean b = deptService.updateById(dept);
        return b ? success() : error();
    }
}

