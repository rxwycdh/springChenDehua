package org.analysis.projects.ppp.minapp.server;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.analysis.projects.ppp.logic.ProjectTagLogic;
import org.analysis.projects.ppp.model.auto.Project;
import org.analysis.projects.ppp.model.auto.ProjectDynamic;
import org.analysis.projects.ppp.model.auto.ProjectType;
import org.analysis.projects.ppp.model.custom.ProjectDetailsIF;
import org.analysis.projects.ppp.model.custom.ServerProjectIF;
import org.analysis.projects.ppp.service.auto.ProjectDynamicService;
import org.analysis.projects.ppp.service.auto.ProjectService;
import org.analysis.projects.ppp.service.auto.ProjectTypeService;
import org.analysis.system.common.base.BaseController;
import org.analysis.system.common.domain.AjaxResult;
import org.analysis.system.common.domain.TableSplitResult;
import org.analysis.system.common.domain.Tablepar;
import org.analysis.system.common.support.Convert;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;


@RestController
@Api(tags = {"微信小程序服务版-项目信息接口"})
@RequestMapping("/wx/pppserver/minapp/project")
public class WxMaServerProjectController extends BaseController {

    private static Logger logger = LoggerFactory.getLogger(WxMaServerProjectController.class);

    @Autowired
    private ProjectService projectService;
    @Autowired
    private ProjectTypeService projectTypeService;
    @Autowired
    private ProjectTagLogic projectTagLogic;
    @Autowired
    private ProjectDynamicService projectDynamicService;


    @ApiOperation(value = "获取项目列表", notes = "获取项目列表")
    @PostMapping("/list")
    public TableSplitResult<ServerProjectIF> list(Tablepar tablepar,
                                                  @ApiParam(name = "id", value = "用户id") Integer id,
                                                  @ApiParam(name = "state", value = "项目状态;0:待审核;1:已通过;2:未通过;3:下架中;4:已终止") Integer state) {

        try {
            QueryWrapper<Project> queryWrapper = new QueryWrapper<>();

            if (state != null) {
                queryWrapper.eq("state", state);
            }
            queryWrapper.eq("leader_id", id);
            queryWrapper.orderByDesc("create_time is null, create_time");

            PageHelper.startPage(tablepar.getPageNum(), tablepar.getPageSize());
            List<Project> projects = projectService.list(queryWrapper);
            PageInfo<Project> pageInfo = new PageInfo<>(projects);

            List<ServerProjectIF> list = new ArrayList<>();
            for (Project p : projects) {
                ServerProjectIF serverProjectIF = new ServerProjectIF();

                BeanUtils.copyProperties(serverProjectIF, p);

                ProjectType projectType = projectTypeService.getById(p.getTypeId());
                serverProjectIF.setTypeName(projectType!=null ? projectType.getName() : "");

                list.add(serverProjectIF);
            }

            return new TableSplitResult<>(pageInfo.getPageNum(), pageInfo.getTotal(), list);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            return null;
        }
    }

    @ApiOperation(value = "获取项目详情", notes = "获取项目详情")
    @GetMapping("/getOne")
    public AjaxResult<ProjectDetailsIF> getOne(@ApiParam(name = "id", value = "项目id") Integer id) {

        try {
            ProjectDetailsIF projectDetailsIF = new ProjectDetailsIF();
            Project p = projectService.getById(id);
            BeanUtils.copyProperties(projectDetailsIF, p);

            String tagsName = projectTagLogic.queryProjectTags(p.getId());
            projectDetailsIF.setTags(Convert.toListStrArray(tagsName));

            ProjectType projectType = projectTypeService.getById(p.getTypeId());
            projectDetailsIF.setTypeName(projectType!=null ? projectType.getName() : "");

            return AjaxResult.successData(projectDetailsIF);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            return AjaxResult.error();
        }
    }

    @ApiOperation(value = "发布项目", notes = "发布项目")
    @Transactional
    @PostMapping("/add")
    public AjaxResult add(Project project,
                          @ApiParam(name = "tags", value = "项目标签,逗号隔开") String tags) {

        try {
            project.setState(0);
            project.setCreateTime(LocalDateTime.now());

            boolean save = projectService.save(project);
            //添加标签
            projectTagLogic.addProjectTags(project.getId(), tags);

            return save ? success() : error();
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            return error();
        }
    }

    @ApiOperation(value = "删除项目", notes = "根据id删除项目")
    @GetMapping("/remove")
    @Transactional
    public AjaxResult remove(@ApiParam(name = "id", value = "项目id") Integer id) {
        try {
            //删除标签
            projectTagLogic.removeArticleTags(id);

            boolean delete = projectService.removeById(id);
            return delete ? success() : error();
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            return error();
        }
    }

    @ApiOperation(value = "取消项目", notes = "取消项目")
    @GetMapping("/cancel")
    @Transactional
    public AjaxResult cancel(@ApiParam(name = "userId", value = "用户id") Integer userId,
                             @ApiParam(name = "projectId", value = "项目id") Integer projectId) {
        try {
            Project project = projectService.getById(projectId);
            if (!userId.equals(project.getLeaderId())) {
                logger.error("请求错误：请求用户无权限。");
                return error();
            }
            project.setState(4);
            project.setUpdateTime(LocalDateTime.now());

            //更新动态
            QueryWrapper<ProjectDynamic> queryWrapper = new QueryWrapper<>();
            queryWrapper.eq("reply_id", userId);
            queryWrapper.eq("project_id", projectId);
            List<ProjectDynamic> projectDynamics = projectDynamicService.list(queryWrapper);
            for (ProjectDynamic pd : projectDynamics) {
                pd.setState(3);
                pd.setReplyTime(LocalDateTime.now());
                projectDynamicService.updateById(pd);
            }

            boolean b = projectService.updateById(project);
            return b ? success() : error();
        } catch (Exception e) {
            logger.error(ExceptionUtils.getFullStackTrace(e));
            return error();
        }
    }

}
