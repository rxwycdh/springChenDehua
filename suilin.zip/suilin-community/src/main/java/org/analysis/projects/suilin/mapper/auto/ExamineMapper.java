package org.analysis.projects.suilin.mapper.auto;

import org.analysis.projects.suilin.model.auto.Examine;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.CacheNamespace;

/**
 * <p>
 * 审核信息 Mapper 接口
 * </p>
 *
 * @author Feliz
 * @since 2020-07-28
 */
@CacheNamespace(flushInterval = 3600000, size = 4096)
public interface ExamineMapper extends BaseMapper<Examine> {

}
