package org.analysis.projects.archive.service.auto;

import org.analysis.projects.archive.model.auto.Card;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 档案卡片 服务类
 * </p>
 *
 * @author Feliz
 * @since 2019-09-10
 */
public interface CardService extends IService<Card> {

}
