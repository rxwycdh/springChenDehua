package org.analysis.projects.oasystem.model.auto;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;

/**
 * <p>
 * 职员-系统用户连接表
 * </p>
 *
 * @author Feliz
 * @since 2019-06-18
 */
@TableName("oasystem_staff_user")
@ApiModel(value="StaffUser对象", description="职员-系统用户连接表")
public class StaffUser implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "职员id")
    @TableField("staff_id")
    private Integer staffId;

    @ApiModelProperty(value = "系统用户id")
    @TableField("user_id")
    private Integer userId;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getStaffId() {
        return staffId;
    }

    public void setStaffId(Integer staffId) {
        this.staffId = staffId;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    @Override
    public String toString() {
        return "StaffUser{" +
        "id=" + id +
        ", staffId=" + staffId +
        ", userId=" + userId +
        "}";
    }
}
