package org.analysis.projects.brainwave.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.LinkedHashMap;

public class ReadParseTGAM {
    private static Logger logger = LoggerFactory.getLogger("brainwave");

    public final int PARSER_CODE_POOR_SIGNAL = 2;
    public final int PARSER_CODE_HEARTRATE = 3;
    public final int PARSER_CODE_CONFIGURATION = 4;
    public final int PARSER_CODE_MEDITATION = 5;
    public final int PARSER_CODE_RAW = 128;
    public final int PARSER_CODE_DEBUG_ONE = 132;
    public final int PARSER_CODE_DEBUG_TWO = 133;
    public final int PARSER_CODE_EEG_POWER = 131;
    public final int PST_PACKET_CHECKSUM_FAILED = -2;
    public final int PST_NOT_YET_COMPLETE_PACKET = 0;
    public final int PST_PACKET_PARSED_SUCCESS = 1;
    public final int MESSAGE_READ_RAW_DATA_PACKET = 17;
    public final int MESSAGE_READ_DIGEST_DATA_PACKET = 18;
    private final int RAW_DATA_BYTE_LENGTH = 2;
    private final int EEG_DEBUG_ONE_BYTE_LENGTH = 5;
    private final int EEG_DEBUG_TWO_BYTE_LENGTH = 3;
    private final int PARSER_SYNC_BYTE = 170;
    private final int PARSER_EXCODE_BYTE = 85;
    private final int MULTI_BYTE_CODE_THRESHOLD = 127;
    private final int PARSER_STATE_SYNC = 1;
    private final int PARSER_STATE_SYNC_CHECK = 2;
    private final int PARSER_STATE_PAYLOAD_LENGTH = 3;
    private final int PARSER_STATE_PAYLOAD = 4;
    private final int PARSER_STATE_CHKSUM = 5;
    private int parserStatus;
    private int payloadLength;
    private int payloadBytesReceived;
    private int payloadSum;
    private int checksum;
    private byte[] payload = new byte[256];

    public ReadParseTGAM() {
        this.parserStatus = PARSER_STATE_SYNC;
    }

    public int parseByte(byte buffer) {
        int returnValue = 0;
        switch (this.parserStatus) {
            case 1:
                if ((buffer & 0xFF) != PARSER_SYNC_BYTE) break;
                this.parserStatus = PARSER_STATE_SYNC_CHECK;
                break;
            case 2:
                if ((buffer & 0xFF) == PARSER_SYNC_BYTE)
                    this.parserStatus = PARSER_STATE_PAYLOAD_LENGTH;
                else {
                    this.parserStatus = PARSER_STATE_SYNC;
                }
                break;
            case 3:
                this.payloadLength = (buffer & 0xFF);
                this.payloadBytesReceived = 0;
                this.payloadSum = 0;
                this.parserStatus = PARSER_STATE_PAYLOAD;
                break;
            case 4:
                this.payload[(this.payloadBytesReceived++)] = buffer;
                this.payloadSum += (buffer & 0xFF);
                if (this.payloadBytesReceived < this.payloadLength) break;
                this.parserStatus = PARSER_STATE_CHKSUM;
                break;
            case 5:
                this.checksum = (buffer & 0xFF);
                this.parserStatus = PARSER_STATE_SYNC;
                if (this.checksum != ((this.payloadSum ^ 0xFFFFFFFF) & 0xFF)) {
                    returnValue = -2;
//                    System.out.println("CheckSum ERROR!!");
                } else {
                    returnValue = 1;
                    parsePacketPayload();
                }
                break;
        }
        return returnValue;
    }

    private void parsePacketPayload() {
        int i = 0;
        int extendedCodeLevel = 0;
        int code = 0;
        int valueBytesLength = 0;
        int signal = 0;
        int config = 0;
        int heartrate = 0;
        int rawWaveData = 0;
        String eegDate = "";

        while (i < this.payloadLength) {
            extendedCodeLevel++;
            while (this.payload[i] == PARSER_EXCODE_BYTE) {
                i++;
            }
            code = this.payload[(i++)] & 0xFF;
            if (code > MULTI_BYTE_CODE_THRESHOLD) {
                valueBytesLength = this.payload[(i++)] & 0xFF;
            } else {
                valueBytesLength = 1;
            }
            if (code == PARSER_CODE_RAW) {
                if ((valueBytesLength == RAW_DATA_BYTE_LENGTH)) {
                    byte highOrderByte = this.payload[i];
                    byte lowOrderByte = this.payload[(i + 1)];
//                    System.out.print("---xxHigh:" + (highOrderByte& 0xFF));
//                    System.out.println("---xxLow:" + (lowOrderByte& 0xFF));
                    rawWaveData = getRawWaveValue(highOrderByte, lowOrderByte);
                    if (rawWaveData > 32768) rawWaveData -= 65536;
                    //raw数据
//                    System.out.println("Raw:" + rawWaveData);
                }
                i += valueBytesLength;
            } else {
                switch (code) {
                    case PARSER_CODE_POOR_SIGNAL:
                        signal = this.payload[i] & 0xFF;
                        i += valueBytesLength;

//                        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//设置日期格式
//                        String time = df.format(new Date());
//                        int EEGi = ++ReadEEGMain.EEGIndex;
//                        System.out.println(time + "：第"+ EEGi +"条数据");
//                        System.out.println("time:" + time);// new Date()为获取当前系统时间
//                        System.out.println("PQ:" + signal);
                        eegDate += signal;

                        break;
                    case PARSER_CODE_EEG_POWER:
//                        i += valueBytesLength;
                        int length = this.payload[i] & 0xFF;
//                        System.out.println("len"+length);
                        for (int j=0; j < length; j++) {
                            eegDate += (" " + (payload[i] & 0xFF));
                            i++;
                        }

                        LinkedHashMap<String, Integer> eegPower = new LinkedHashMap<String, Integer>();
                        eegPower.put("Delta1:", 0);
                        eegPower.put("Delta2:", 0);
                        eegPower.put("Delta3:", 0);
                        eegPower.put("Theta1:", 0);
                        eegPower.put("Theta2:", 0);
                        eegPower.put("Theta3:", 0);
                        eegPower.put("LowAlpha1:", 0);
                        eegPower.put("LowAlpha2:", 0);
                        eegPower.put("LowAlpha3:", 0);
                        eegPower.put("HighAlpha1:", 0);
                        eegPower.put("HighAlpha2:", 0);
                        eegPower.put("HighAlpha3:", 0);
                        eegPower.put("LowBeta1:", 0);
                        eegPower.put("LowBeta2:", 0);
                        eegPower.put("LowBeta3:", 0);
                        eegPower.put("HighBeta1:", 0);
                        eegPower.put("HighBeta2:", 0);
                        eegPower.put("HighBeta3:", 0);
                        eegPower.put("LowGamma1:", 0);
                        eegPower.put("LowGamma2:", 0);
                        eegPower.put("LowGamma3:", 0);
                        eegPower.put("MiddleGamma1:", 0);
                        eegPower.put("MiddleGamma2:", 0);
                        eegPower.put("MiddleGamma3:", 0);
//                        System.out.println("==============解析大包==============");
//                        for (Map.Entry<String, Integer> ep : eegPower.entrySet()) {
//                            ep.setValue(payload[i] & 0xFF);
//                            i++;
//                        }
//                        for (Map.Entry<String, Integer> ep : eegPower.entrySet()) {
//                            System.out.println(ep.getKey() + " " + ep.getValue());
//                        }

                        //解析EEGPOWER数值
                        /*int mapIndex = 1;
                        int eegIndex = 0;
                        int Delta, Theta, LowAlpha, HighAlpha, LowBeta, HighBeta, LowGamma, MiddleGamma;
                        for (Map.Entry<String, Integer> ep : eegPower.entrySet()) {
                            int high = 0, mid = 0, low = 0;
                            if (mapIndex % 3 == 1) {
                                low = ep.getValue();
                            } else if (mapIndex % 3 == 2) {
                                mid = ep.getValue();
                            } else if (mapIndex % 3 == 0) {
                                high = ep.getValue();
                                eegIndex++;
                                switch (eegIndex) {
                                    case 1:
                                        Delta = getEEGPower(high, mid, low);
                                        System.out.print("Delta:" + Delta);
                                        break;
                                    case 2:
                                        Theta = getEEGPower(high, mid, low);
                                        System.out.print(" Theta:" + Theta);
                                        break;
                                    case 3:
                                        LowAlpha = getEEGPower(high, mid, low);
                                        System.out.print(" LowAlpha:" + LowAlpha);
                                        break;
                                    case 4:
                                        HighAlpha = getEEGPower(high, mid, low);
                                        System.out.print(" HighAlpha:" + HighAlpha);
                                        break;
                                    case 5:
                                        LowBeta = getEEGPower(high, mid, low);
                                        System.out.print(" LowBeta:" + LowBeta);
                                        break;
                                    case 6:
                                        HighBeta = getEEGPower(high, mid, low);
                                        System.out.print(" HighBeta:" + HighBeta);
                                        break;
                                    case 7:
                                        LowGamma = getEEGPower(high, mid, low);
                                        System.out.print(" LowGamma:" + LowGamma);
                                        break;
                                    case 8:
                                        MiddleGamma = getEEGPower(high, mid, low);
                                        System.out.print(" MiddleGamma:" + MiddleGamma);
                                        System.out.println();
                                        break;
                                }
                            }
                            mapIndex++;
                        }*/
                        break;
                    case PARSER_CODE_CONFIGURATION:
                        //Signal 等于以下值，代表耳机没有戴好
                        if (signal == 29 || signal == 54 || signal == 55 || signal == 56 || signal == 80 ||
                                signal == 81 || signal == 82 || signal == 107 || signal == 200) {

                            eegDate += (" " + (payload[i] & 0xFF));
//                            config = this.payload[i] & 0xFF;
//                            System.out.println("??NoShouldAtt:" + config);

                            i += valueBytesLength;
                            break;
                        } else {
                            eegDate += (" " + (payload[i] & 0xFF));
//                            config = this.payload[i] & 0xFF;
//                            System.out.println("??Attention:" + config);
                        }
                        i += valueBytesLength;
                        break;
                    case PARSER_CODE_MEDITATION:
                        //Signal 等于以下值，代表耳机没有戴好
                        if (signal == 29 || signal == 54 || signal == 55 || signal == 56 || signal == 80 ||
                                signal == 81 || signal == 82 || signal == 107 || signal == 200) {

                            eegDate += (" " + (payload[i] & 0xFF));
//                            config = this.payload[i] & 0xFF;
//                            System.out.println("??NoShouldMed:" + config);
//                            System.out.println();
                            i += valueBytesLength;
                            break;
                        } else {

                            eegDate += (" " + (payload[i] & 0xFF));
//                            config = this.payload[i] & 0xFF;
//                            System.out.println("??Meditation:" + config);
//                            System.out.println();
                        }

                        System.out.println(eegDate);
                        logger.info(String.valueOf(eegDate));
                        i += valueBytesLength;
                        break;
                    case PARSER_CODE_HEARTRATE:
                        heartrate = this.payload[i] & 0xFF;
                        i += valueBytesLength;
                        break;
                    case PARSER_CODE_DEBUG_ONE:
                        if (valueBytesLength == EEG_DEBUG_ONE_BYTE_LENGTH) {
                            i += valueBytesLength;
                        }
                        break;
                    case PARSER_CODE_DEBUG_TWO:
                        if (valueBytesLength == EEG_DEBUG_TWO_BYTE_LENGTH) {
                            i += valueBytesLength;
                        }
                        break;
                }
            }
        }
        this.parserStatus = PARSER_STATE_SYNC;
    }

    private int getEEGPower(int high, int mid, int low) {

        int eegPower = (high << 16) | (mid << 8) | low;

        return eegPower;
    }

    private int getRawWaveValue(byte highOrderByte, byte lowOrderByte) {
        /* Sign?extend the signed high byte to the width of a signed int */
        int hi = (int) highOrderByte;
        /* Extend low to the width of an int, but keep exact bits instead of sign?extending */
        int lo = ((int) lowOrderByte) & 0xFF;
        /* Calculate raw value by appending the exact low bits to the sign?extended high bits */
        int value = (hi << 8) | lo;
        return (value);
    }

}
