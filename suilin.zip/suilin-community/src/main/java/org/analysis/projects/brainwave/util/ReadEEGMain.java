package org.analysis.projects.brainwave.util;

import gnu.io.SerialPort;
import gnu.io.SerialPortEvent;
import gnu.io.SerialPortEventListener;
import org.analysis.system.common.exception.serialException.*;
import org.analysis.system.util.SerialUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ReadEEGMain {

    private static Logger logger = LoggerFactory.getLogger("brainwave");

    public static int EEGIndex = 0;
    private SerialPort serialPort = null;    //保存串口对象
    //设置串口
//    private ArrayList<String> ports = SerialTool.findPort();
    private String commName = "COM6";
    //设置波特率
    private String bpsStr = "57600";


    /**
     * 主方法
     *
     * @param args //
     */
    public static void main(String[] args) {
        new ReadEEGMain().startCollection();
    }

    public void startCollection() {
        try {
            new ReadEEGMain().openPort();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //打开串口
    public void openPort() throws Exception {

        //检查串口名称是否获取正确
        if (commName == null || commName.equals("")) {
            throw new Exception("错误：没有搜索到有效串口！");
        } else {
            //检查波特率是否获取正确
            if (bpsStr == null || bpsStr.equals("")) {
                throw new Exception("错误：波特率获取错误！");
            } else {
                //串口名、波特率均获取正确时
                int bps = Integer.parseInt(bpsStr);
                try {
                    //获取指定端口名及波特率的串口对象
                    serialPort = SerialUtils.openPort(commName, bps);
                    //在该串口对象上添加监听器
                    SerialUtils.addListener(serialPort, new SerialListener());
                    //监听成功进行提示
                    System.out.println("=================================");
                    System.out.println("==========正在采集脑波数据==========");
                    System.out.println("=================================");
                } catch (SerialPortParameterFailure | NotASerialPort | NoSuchPort | PortInUse | TooManyListeners e1) {
                    //发生错误时使用一个Dialog提示具体的错误信息
                    throw new Exception("错误：" + e1);
                }
            }
        }
    }

    /**
     * 以内部类形式创建一个串口监听类
     *
     * @author zhong
     */
    private class SerialListener implements SerialPortEventListener {

        /**
         * 处理监控到的串口事件
         */
        public void serialEvent(SerialPortEvent serialPortEvent) {

            switch (serialPortEvent.getEventType()) {

                case SerialPortEvent.BI: // 10 通讯中断
                    try {
                        throw new Exception("错误：与串口设备通讯中断!");
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    break;

                case SerialPortEvent.OE: // 7 溢位（溢出）错误

                case SerialPortEvent.FE: // 9 帧错误

                case SerialPortEvent.PE: // 8 奇偶校验错误

                case SerialPortEvent.CD: // 6 载波检测

                case SerialPortEvent.CTS: // 3 清除待发送数据

                case SerialPortEvent.DSR: // 4 待发送数据准备好了

                case SerialPortEvent.RI: // 5 振铃指示

                case SerialPortEvent.OUTPUT_BUFFER_EMPTY: // 2 输出缓冲区已清空
                    break;

                case SerialPortEvent.DATA_AVAILABLE: // 1 串口存在可用数据

                    //System.out.println("found data");
                    byte[] data = null;

                    try {
                        if (serialPort == null) {
                            try {
                                throw new Exception("错误：串口对象为空！监听失败！");
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        } else {
                            data = SerialUtils.readFromPort(serialPort);    //读取数据，存入字节数组

                            //自定义解析过程
                            if (data == null || data.length < 1) {    //检查数据是否读取正确
                                try {
                                    throw new Exception("错误：读取数据过程中未获取到有效数据！请检查设备或程序！");
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                                System.exit(0);
                            } else {
//                                ReadParseTGAM readParseTGAM = new ReadParseTGAM();
//                                for (int i = 0; i < data.length; i++) {
//                                    //解析数据
//                                    readParseTGAM.parseByte(data[i]);
//                                }

                                String eegData = "";
                                for (byte b : data) {
                                    eegData = eegData + " " + bytes2HexString(b);
                                }
//                                System.out.println(eegData);
                                logger.info(String.valueOf(eegData));

                            }

                        }
                    } catch (ReadDataFromSerialPortFailure | SerialPortInputStreamCloseFailure e) {
                        e.printStackTrace();
                        System.exit(0);    //发生读取错误时显示错误信息后退出系统
                    }

                    break;

            }

        }

    }

    /**
     * byte 转 16进制数
     *
     * @param b
     * @return
     */
    public static String bytes2HexString(byte b) {
        String ret = "";
        String hex = Integer.toHexString(b & 0xFF).toUpperCase();
        if (hex.length() == 1) {
            hex = '0' + hex;
        }
        ret += hex;

        return ret;
    }
}
