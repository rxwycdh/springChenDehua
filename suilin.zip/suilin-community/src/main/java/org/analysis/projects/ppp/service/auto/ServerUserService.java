package org.analysis.projects.ppp.service.auto;

import org.analysis.projects.ppp.model.auto.ServerUser;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 服务版用户信息 服务类
 * </p>
 *
 * @author Feliz
 * @since 2020-04-01
 */
public interface ServerUserService extends IService<ServerUser> {

}
