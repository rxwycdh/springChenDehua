package org.analysis.projects.brainwave.model.auto;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * <p>
 * 原始脑波数据表
 * </p>
 *
 * @author Feliz
 * @since 2019-05-30
 */
@TableName("brainwave_raw_data")
@ApiModel(value="RawData对象", description="原始脑波数据表")
public class RawData implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "id", required = true, example = "0", position = 1)
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "穿戴人", example = "0")
    @TableField("user_id")
    private Integer userId;

    @ApiModelProperty(value = "设备id", example = "0")
    @TableField("device_id")
    private Integer deviceId;

    @ApiModelProperty(value = "场景id", example = "0")
    @TableField("scene_id")
    private Integer sceneId;

    @ApiModelProperty(value = "原始数据")
    @TableField("raw_data")
    private String rawData;

    @ApiModelProperty(value = "时间戳")
    @TableField("time")
    private LocalDateTime time;

    @ApiModelProperty(value = "是否已解析；1:已解析；0：未解析", example = "0")
    @TableField("analysed")
    private Integer analysed;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public Integer getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(Integer deviceId) {
        this.deviceId = deviceId;
    }

    public String getRawData() {
        return rawData;
    }

    public void setRawData(String rawData) {
        this.rawData = rawData;
    }

    public LocalDateTime getTime() {
        return time;
    }

    public void setTime(LocalDateTime time) {
        this.time = time;
    }

    public Integer getAnalysed() {
        return analysed;
    }

    public void setAnalysed(Integer analysed) {
        this.analysed = analysed;
    }

    public Integer getSceneId() {
        return sceneId;
    }

    public void setSceneId(Integer sceneId) {
        this.sceneId = sceneId;
    }

    @Override
    public String toString() {
        return "RawData{" +
                "id=" + id +
                ", userId=" + userId +
                ", deviceId=" + deviceId +
                ", sceneId=" + sceneId +
                ", rawData='" + rawData + '\'' +
                ", time=" + time +
                ", analysed=" + analysed +
                '}';
    }
}
