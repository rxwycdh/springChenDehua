package org.analysis.projects.suilin.service.auto.impl;

import org.analysis.projects.suilin.model.auto.Notice;
import org.analysis.projects.suilin.mapper.auto.NoticeMapper;
import org.analysis.projects.suilin.service.auto.NoticeService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 公告信息 服务实现类
 * </p>
 *
 * @author Feliz
 * @since 2020-07-28
 */
@Service
public class NoticeServiceImpl extends ServiceImpl<NoticeMapper, Notice> implements NoticeService {

}
