package org.analysis.projects.archive.service.auto;

import org.analysis.projects.archive.model.auto.UserField;
import com.baomidou.mybatisplus.extension.service.IService;
import org.analysis.system.common.domain.AjaxResult;
import org.springframework.web.multipart.MultipartFile;

import java.util.Map;

/**
 * <p>
 * 信息用户字段值 服务类
 * </p>
 *
 * @author Feliz
 * @since 2019-09-10
 */
public interface UserFieldService extends IService<UserField> {


}
