package org.analysis.projects.archive;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * 信息用户字段值项目启动器
 */
@MapperScan(value = "org.analysis.projects.archive.mapper")
@SpringBootApplication
public class ArchiveSystemApplication {

    public static void main(String[] args) {
        SpringApplication.run(ArchiveSystemApplication.class, args);
        System.out.println("=================================");
        System.out.println("==========信息项目启动成功==========");
        System.out.println("=================================");
    }
}
