package org.analysis.projects.brainwave.model.auto;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * <p>
 * beta脑波数据表
 * </p>
 *
 * @author Feliz
 * @since 2019-06-06
 */
@TableName("brainwave_beta_data")
@ApiModel(value="BetaData对象", description="beta脑波数据表")
public class BetaData implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "id", required = true, example = "0", position = 1)
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "穿戴人", example = "0")
    @TableField("user_id")
    private Integer userId;

    @ApiModelProperty(value = "设备id", example = "0")
    @TableField("device_id")
    private Integer deviceId;

    @ApiModelProperty(value = "场景id", example = "0")
    @TableField("scene_id")
    private Integer sceneId;

    @ApiModelProperty(value = "时间戳")
    @TableField("time")
    private LocalDateTime time;

    @ApiModelProperty(value = "信号值", example = "200")
    @TableField("pq")
    private Integer pq;

    @TableField("low_beta1")
    private Integer lowBeta1;

    @TableField("low_beta2")
    private Integer lowBeta2;

    @TableField("low_beta3")
    private Integer lowBeta3;

    @TableField("high_beta1")
    private Integer highBeta1;

    @TableField("high_beta2")
    private Integer highBeta2;

    @TableField("high_beta3")
    private Integer highBeta3;

    @ApiModelProperty(value = "创建时间")
    @TableField("create_time")
    private LocalDateTime createTime;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public Integer getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(Integer deviceId) {
        this.deviceId = deviceId;
    }

    public Integer getSceneId() {
        return sceneId;
    }

    public void setSceneId(Integer sceneId) {
        this.sceneId = sceneId;
    }

    public LocalDateTime getTime() {
        return time;
    }

    public void setTime(LocalDateTime time) {
        this.time = time;
    }

    public Integer getPq() {
        return pq;
    }

    public void setPq(Integer pq) {
        this.pq = pq;
    }

    public Integer getLowBeta1() {
        return lowBeta1;
    }

    public void setLowBeta1(Integer lowBeta1) {
        this.lowBeta1 = lowBeta1;
    }

    public Integer getLowBeta2() {
        return lowBeta2;
    }

    public void setLowBeta2(Integer lowBeta2) {
        this.lowBeta2 = lowBeta2;
    }

    public Integer getLowBeta3() {
        return lowBeta3;
    }

    public void setLowBeta3(Integer lowBeta3) {
        this.lowBeta3 = lowBeta3;
    }

    public Integer getHighBeta1() {
        return highBeta1;
    }

    public void setHighBeta1(Integer highBeta1) {
        this.highBeta1 = highBeta1;
    }

    public Integer getHighBeta2() {
        return highBeta2;
    }

    public void setHighBeta2(Integer highBeta2) {
        this.highBeta2 = highBeta2;
    }

    public Integer getHighBeta3() {
        return highBeta3;
    }

    public void setHighBeta3(Integer highBeta3) {
        this.highBeta3 = highBeta3;
    }

    public LocalDateTime getCreateTime() {
        return createTime;
    }

    public void setCreateTime(LocalDateTime createTime) {
        this.createTime = createTime;
    }

    @Override
    public String toString() {
        return "BetaData{" +
        "id=" + id +
        ", userId=" + userId +
        ", deviceId=" + deviceId +
        ", sceneId=" + sceneId +
        ", time=" + time +
        ", pq=" + pq +
        ", lowBeta1=" + lowBeta1 +
        ", lowBeta2=" + lowBeta2 +
        ", lowBeta3=" + lowBeta3 +
        ", highBeta1=" + highBeta1 +
        ", highBeta2=" + highBeta2 +
        ", highBeta3=" + highBeta3 +
        ", createTime=" + createTime +
        "}";
    }
}
