package org.analysis.projects.ppp.service.auto.impl;

import org.analysis.projects.ppp.model.auto.Feedback;
import org.analysis.projects.ppp.mapper.auto.FeedbackMapper;
import org.analysis.projects.ppp.service.auto.FeedbackService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 反馈信息 服务实现类
 * </p>
 *
 * @author Feliz
 * @since 2020-04-01
 */
@Service
public class FeedbackServiceImpl extends ServiceImpl<FeedbackMapper, Feedback> implements FeedbackService {

}
