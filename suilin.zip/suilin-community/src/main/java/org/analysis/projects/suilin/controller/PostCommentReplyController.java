package org.analysis.projects.suilin.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.analysis.projects.suilin.model.auto.PostCommentReply;
import org.analysis.projects.suilin.service.auto.PostCommentReplyService;
import org.analysis.system.common.domain.AjaxResult;
import org.analysis.system.common.domain.TableSplitResult;
import org.analysis.system.common.domain.Tablepar;
import org.analysis.system.common.support.Convert;
import org.analysis.system.model.custom.TitleVo;
import org.analysis.system.util.StringUtils;
import org.analysis.system.common.log.Log;
import org.analysis.system.util.ExcelUtils;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.analysis.system.common.base.BaseController;

import java.time.LocalDateTime;
import javax.servlet.http.HttpServletResponse;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.*;


/**
 * <p>
 * 评论回复表 前端控制器
 * </p>
 *
 * @author Feliz
 * @since 2020-08-19 11:05:33
 */
@Controller
@Api(tags = {"评论回复表"})
@RequestMapping("/suilin/PostCommentReplyController")
public class PostCommentReplyController extends BaseController{

    private static Logger logger = LoggerFactory.getLogger(PostCommentReplyController.class);

    //跳转页面参数
    private String prefix = "projects/suilin/postCommentReply";

	@Autowired
	private PostCommentReplyService postCommentReplyService;

	//跳转评论回复表页面
    @GetMapping("/view")
    @RequiresPermissions("suilin:postCommentReply:view")
    public String view(Model model) {
        String str="评论回复表";
        setTitle(model, new TitleVo(str+"列表", str+"管理", false, "欢迎进入"+str+"页面", false, false));
        return prefix + "/list";
    }

    @Log(title = "评论回复表列表查询", action = "111")
    @ApiOperation(value = "获取评论回复表列表", notes = "获取评论回复表列表")
    @PostMapping("/list")
    @RequiresPermissions("suilin:postCommentReply:list")
    @ResponseBody
    public TableSplitResult<PostCommentReply> list(Tablepar tablepar, String searchText) {

        QueryWrapper<PostCommentReply> queryWrapper = new QueryWrapper<>();
        if (StringUtils.isNotEmpty(searchText)) {
            queryWrapper.and(wrapper -> wrapper
                    .like("id", searchText).or()
                    .like("suilin_user_id", searchText).or()
                    .like("suilin_comment_id", searchText).or()
                    .like("reply", searchText).or()
                    .like("like_user", searchText).or()
                    .like("like_count", searchText).or()
            );
        }

        PageHelper.startPage(tablepar.getPageNum(), tablepar.getPageSize());
        List<PostCommentReply> list = postCommentReplyService.list(queryWrapper);
        PageInfo<PostCommentReply> pageInfo = new PageInfo<PostCommentReply>(list);

        return new TableSplitResult<>(pageInfo.getPageNum(), pageInfo.getTotal(), pageInfo.getList());
    }

    @ApiOperation(value = "获取全部评论回复表信息", notes = "获取全部评论回复表信息")
    @PostMapping("/getAllPostCommentReply")
    @ResponseBody
    public AjaxResult<TableSplitResult<PostCommentReply>> getAllPostCommentReply() {
        try {
            List<PostCommentReply> list = postCommentReplyService.list();
            return AjaxResult.successDataList(list);
        } catch (Exception e) {
            logger.error(e.toString());
            return AjaxResult.error(e.getMessage());
        }
    }

    //跳转评论回复表新增页面
    @GetMapping("/add")
    public String add() {
        return prefix + "/add";
    }

    @Log(title = "评论回复表新增", action = "111")
    @ApiOperation(value = "添加评论回复表", notes = "添加评论回复表")
    @PostMapping("add")
    @RequiresPermissions("suilin:postCommentReply:add")
    @ResponseBody
    public AjaxResult add(PostCommentReply postCommentReply) {
        postCommentReply.setCreateTime(LocalDateTime.now());
        boolean save = postCommentReplyService.save(postCommentReply);
        return save ? success() : error();
    }

    @Log(title = "评论回复表删除", action = "111")
    @ApiOperation(value = "删除评论回复表", notes = "根据id删除评论回复表（可批量）")
    @PostMapping("/remove")
    @RequiresPermissions("suilin:postCommentReply:remove")
    @ResponseBody
    public AjaxResult remove(String ids) {
        List<Integer> idList= Convert.toListIntArray(ids);
        boolean delete = postCommentReplyService.removeByIds(idList);
        return delete ? success() : error();
    }

    @ApiOperation(value = "检查评论回复表是否存在", notes = "返回: 1-存在; 0-不存在")
    @PostMapping("/checkUnique")
    @ResponseBody
    public Integer checkUnique(PostCommentReply postCommentReply) {
        QueryWrapper<PostCommentReply> queryWrapper = new QueryWrapper<>();
        //TODO 注意是否正确，默认检测name字段
        //queryWrapper.eq("name", postCommentReply.getName());
        List<PostCommentReply> list = postCommentReplyService.list(queryWrapper);
        if (list.size() > 0) {
            return 1;
        } else {
            return 0;
        }
    }

    //跳转评论回复表修改页面
    @GetMapping("/edit/{id}")
    public String edit(@PathVariable("id") Integer id, ModelMap modelMap) {
        modelMap.put("postCommentReply", postCommentReplyService.getById(id));
        return prefix + "/edit";
    }

    @Log(title = "评论回复表修改", action = "111")
    @ApiOperation(value = "修改评论回复表", notes = "修改评论回复表")
    @PostMapping("/edit")
    @RequiresPermissions("suilin:postCommentReply:edit")
    @ResponseBody
    public AjaxResult editSave(PostCommentReply postCommentReply) {
        postCommentReply.setUpdateTime(LocalDateTime.now());
        boolean edit = postCommentReplyService.updateById(postCommentReply);
        return edit ? success() : error();
    }


    //跳转评论回复表批量新增页面
    @GetMapping("/batchAdd")
    public String batchAdd() {
        return prefix + "/batchAdd";
    }

    @Log(title = "评论回复表批量导入", action = "111")
    @ApiOperation(value = "批量导入评论回复表", notes = "批量导入评论回复表")
    @RequiresPermissions("suilin:postCommentReply:add")
    @Transactional(propagation = Propagation.REQUIRED)
    @PostMapping("/batchAdd")
    @ResponseBody
    public AjaxResult batchAdd(@RequestParam(value = "file", required = false) MultipartFile file) {
        try {
            String suffer = file.getOriginalFilename().substring(file.getOriginalFilename().indexOf(".") + 1);
            if ("xls".equals(suffer) || "xlsx".equals(suffer)) {
                InputStream in = file.getInputStream();
                Map<String, String> fields = new LinkedHashMap<String, String>();

                fields.put("用户号", "suilinUserId");
                fields.put("回复编号", "suilinCommentId");
                fields.put("回复内容", "reply");
                fields.put("点赞用户号，按照逗号隔开", "likeUser");
                fields.put("点赞数", "likeCount");

                List<PostCommentReply> list = new ArrayList<PostCommentReply>();
                list = ExcelUtils.ExecltoList(in, PostCommentReply.class, fields);

                int sum = list.size();//总需导入数
                int successNum = 0;//成功导入数
                int failNum = 0;//失败导入数
                for (PostCommentReply o : list) {

                    if (checkUnique(o) == 0) {
                        add(o);
                        successNum++;
                    }else {
                        failNum++;
                    }
                }

                return success("总需导入数：" + sum + "</br>成功导入数：" + successNum +" </br>失败导入数：" + failNum);
            }
            return error("上传文件格式应为xls或xlsx");

        } catch (Exception e) {
            logger.error(ExceptionUtils.getFullStackTrace(e));
            return error("上传文件模板有误，请对比导入模板！");
        }
    }

    @Log(title = "评论回复表导入模板获取", action = "111")
    @GetMapping("/getExcelModel")
    @ResponseBody
    public void getUserCardExcelModel(HttpServletResponse response) throws Exception {
        OutputStream out = null;
        //通过response对象获取outputStream流
        response.setContentType("application/octect-stream"); // 下载文件能正常显示中文
        response.setHeader("Content-Disposition", "attachment;filename=" + new String(("评论回复表的导入模板.xls").getBytes("gb2312"), "ISO8859-1"));
        out = response.getOutputStream();

        Map<String, String> fields = new LinkedHashMap<String, String>();

        fields.put("suilinUserId", "用户号");
        fields.put("suilinCommentId", "回复编号");
        fields.put("reply", "回复内容");
        fields.put("likeUser", "点赞用户号，按照逗号隔开");
        fields.put("likeCount", "点赞数");

        ExcelUtils.ListtoExecl(null, out, fields);
        out.flush();
        out.close();
    }

	
}
