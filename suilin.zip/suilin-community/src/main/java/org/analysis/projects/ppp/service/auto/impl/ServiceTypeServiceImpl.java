package org.analysis.projects.ppp.service.auto.impl;

import org.analysis.projects.ppp.model.auto.ServiceType;
import org.analysis.projects.ppp.mapper.auto.ServiceTypeMapper;
import org.analysis.projects.ppp.service.auto.ServiceTypeService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 服务分类 服务实现类
 * </p>
 *
 * @author Feliz
 * @since 2020-04-23
 */
@Service
public class ServiceTypeServiceImpl extends ServiceImpl<ServiceTypeMapper, ServiceType> implements ServiceTypeService {

}
