package org.analysis.projects.brainwave.service.auto.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.analysis.projects.brainwave.mapper.auto.OtherDataMapper;
import org.analysis.projects.brainwave.model.auto.OtherData;
import org.analysis.projects.brainwave.service.auto.OtherDataService;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 其他脑波数据表 服务实现类
 * </p>
 *
 * @author Feliz
 * @since 2019-06-06
 */
@Service
public class OtherDataServiceImpl extends ServiceImpl<OtherDataMapper, OtherData> implements OtherDataService {

}
