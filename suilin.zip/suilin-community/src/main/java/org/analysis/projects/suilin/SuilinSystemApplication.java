package org.analysis.projects.suilin;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;



@MapperScan(value = "org.analysis.projects.suilin.mapper")
@SpringBootApplication
public class SuilinSystemApplication {

    public static void main(String[] args) {

        SpringApplication.run(SuilinSystemApplication.class,args);
        System.out.println("=================================");
        System.out.println("===========项目启动成功===========");
        System.out.println("=================================");
    }
}
