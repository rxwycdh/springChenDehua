package org.analysis.projects.ppp.mapper.auto;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.analysis.projects.ppp.model.auto.Article;
import org.apache.ibatis.annotations.CacheNamespace;

/**
 * <p>
 * 文章信息表 Mapper 接口
 * </p>
 *
 * @author Feliz
 * @since 2020-03-29
 */
@CacheNamespace(flushInterval = 3600000, size = 4096)
public interface ArticleMapper extends BaseMapper<Article> {

}
