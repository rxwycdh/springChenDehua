package org.analysis.projects.suilin.service.custom.impl;

import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import lombok.AllArgsConstructor;
import org.analysis.projects.suilin.common.enums.PostStatisticsEnum;
import org.analysis.projects.suilin.common.enums.StatusEnum;
import org.analysis.projects.suilin.common.util.SplitUtil;
import org.analysis.projects.suilin.miniapp.model.PostCommentDTO;
import org.analysis.projects.suilin.miniapp.model.PostCommentReplyDTO;
import org.analysis.projects.suilin.miniapp.model.PostInfoDTO;
import org.analysis.projects.suilin.miniapp.param.PostCommentParam;
import org.analysis.projects.suilin.miniapp.param.PostCommentReplyParam;
import org.analysis.projects.suilin.model.auto.PostComment;
import org.analysis.projects.suilin.model.auto.PostCommentReply;
import org.analysis.projects.suilin.model.auto.PostInfo;
import org.analysis.projects.suilin.service.auto.PostCommentReplyService;
import org.analysis.projects.suilin.service.auto.PostCommentService;
import org.analysis.projects.suilin.service.auto.PostInfoService;
import org.analysis.projects.suilin.service.custom.PostCustomService;
import org.analysis.system.common.domain.TableSplitResult;
import org.analysis.system.common.domain.Tablepar;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * @author ChenDehua  597701764@qq.com
 * @date 2020/8/19 10:05
 */
@Service
@AllArgsConstructor
public class PostCustomServiceImpl implements PostCustomService {
    /**
     * 帖子排序1：最新（按照时间倒序）
     */
    private static final Integer LASTEST = 1;
    /**
     * 帖子排序2：最热（按照权重倒序）
     */
    private static final Integer HOT = 2;
    /**
     * 1：升序
     */
    private static final Integer ASC = 1;
    /**
     * 2：倒序
     */
    private static final Integer DESC = 2;

    private PostInfoService postInfoService;

    private PostCommentService postCommentService;

    private PostCommentReplyService postCommentReplyService;

    /**
     * 点赞/取消点赞帖子
     *
     * @param userId     用户编号
     * @param postInfoId 帖子编号
     * @return 是否成功
     */
    @Override
    public boolean updatePostLike(Integer userId, Integer postInfoId) {

        PostInfo info = postInfoService.getById(postInfoId);
        String likeUser = info.getLikeUser();
        List<Integer> likeUserIds = SplitUtil.slice(likeUser);

        if(likeUserIds.contains(userId)) {
            // 已点赞
            likeUserIds.remove(userId);
            info.setLikeUser(SplitUtil.splitJoint(likeUserIds));

            return postInfoService.updateById(info)
                    && updatePostInfoCount(postInfoId, PostStatisticsEnum.LIKE.type, -1);
        }else {
            // 未点赞
            likeUserIds.add(userId);
            info.setLikeUser(SplitUtil.splitJoint(likeUserIds));
            return postInfoService.updateById(info)
                    && updatePostInfoCount(postInfoId, PostStatisticsEnum.LIKE.type, 1);
        }
    }

    /**
     * 获取文章
     *
     * @param postInfoId
     * @param userId
     * @return
     */
    @Override
    public PostInfoDTO getPostInfo(Integer postInfoId, Integer userId) {
        PostInfoDTO postInfoDTO = new PostInfoDTO();

        PostInfo info = postInfoService.getById(postInfoId);
        BeanUtils.copyProperties(info, postInfoDTO);

        List<Integer> likeUserIds = SplitUtil.slice(info.getLikeUser());

        if(ObjectUtil.isEmpty(userId) || !likeUserIds.contains(userId)) {
            postInfoDTO.setIsLike(false);
        }else {
            postInfoDTO.setIsLike(true);
        }

        return postInfoDTO;
    }

    /**
     * 检查帖子是否不存在
     *
     * @param postInfoId 帖子编号
     * @return 是否不存在
     */
    @Override
    public boolean isNotExistPostInfo(Integer postInfoId) {
        return postInfoService.count(Wrappers.<PostInfo>lambdaQuery().eq(PostInfo::getId, postInfoId)) == 0;
    }

    /**
     * 更新文章统计数字
     *
     * @param postInfoId 文章id
     * @param type       类型1：阅读量2：点赞数3：评论数
     * @param count      数值
     * @return 是否成功
     */
    @Override
    public boolean updatePostInfoCount(Integer postInfoId, Integer type, Integer count) {

        PostInfo postInfo = postInfoService.getById(postInfoId);

        if(ObjectUtil.isNotEmpty(postInfo)) {
            if(PostStatisticsEnum.READ.type.equals(type)) {
                postInfo.setReadCount(Math.max(postInfo.getReadCount() + count, 0));
            }else if(PostStatisticsEnum.LIKE.type.equals(type)) {
                postInfo.setLikeCount(Math.max(postInfo.getLikeCount() + count, 0));
            }else if(PostStatisticsEnum.COMMENT.type.equals(type)) {
                postInfo.setCommentCount(Math.max(postInfo.getCommentCount() + count, 0));
            }
        }

        postInfo.setUpdateTime(LocalDateTime.now());
        return postInfoService.updateById(postInfo);
    }

    /**
     * 插入用户到分享用户的字段中
     *
     * @param postInfoId 帖子id
     * @param userId     用户id
     * @return 是否成功
     */
    @Override
    public boolean insertShareUser(Integer postInfoId, Integer userId) {

        PostInfo postInfo = postInfoService.getById(postInfoId);

        List<Integer> shareUserIds = SplitUtil.slice(postInfo.getShareUser());
        shareUserIds.add(userId);
        postInfo.setShareUser(SplitUtil.splitJoint(shareUserIds));
        postInfo.setUpdateTime(LocalDateTime.now());
        return postInfoService.updateById(postInfo);
    }

    @Override
    public TableSplitResult<PostInfoDTO> listPostInfo(Integer userId, Tablepar tablepar,
                                                      Integer sortType, String searchText) {

        LambdaQueryWrapper<PostInfo> lambdaQuery = Wrappers.lambdaQuery();
        if(StrUtil.isNotEmpty(searchText)) {
            lambdaQuery.like(PostInfo::getTitle, searchText).or()
                    .like(PostInfo::getContent, searchText);
        }

        if(LASTEST.equals(sortType)) {
            lambdaQuery.orderByDesc(PostInfo::getCreateTime);
        }else if(HOT.equals(sortType)){
            lambdaQuery.orderByDesc(PostInfo::getSort, PostInfo::getCreateTime);
        }

        PageHelper.startPage(tablepar.getPageNum(), tablepar.getPageSize());

        List<PostInfo> list = postInfoService.list(lambdaQuery);
        PageInfo<PostInfo> pageInfo = new PageInfo<>(list);

        List<PostInfoDTO> resultList = new ArrayList<>();
        if(ObjectUtil.isEmpty(userId)) {

            for (PostInfo info : list) {
                PostInfoDTO dto = new PostInfoDTO();
                BeanUtils.copyProperties(info, dto);
                dto.setIsLike(false);
                resultList.add(dto);
            }

        }else {

            for (PostInfo info : list) {
                PostInfoDTO dto = new PostInfoDTO();
                BeanUtils.copyProperties(info, dto);
                dto.setIsLike(SplitUtil.slice(info.getLikeUser()).contains(userId));
                resultList.add(dto);
            }
        }

        return new TableSplitResult<>(pageInfo.getPageNum(), pageInfo.getTotal(), resultList);
    }

    /**
     * 帖子是否不允许评论
     *
     * @param postInfoId 帖子id
     * @return 帖子是否不允许评论
     */
    @Override
    public boolean isNotAllowComment(Integer postInfoId) {

        PostInfo info = postInfoService.getById(postInfoId);
        if(ObjectUtil.isEmpty(info)) {
            return true;
        }

        return StatusEnum.CLOSE.type.equals(info.getCommentClosed());
    }

    /**
     * 插入帖子评论
     *
     * @param param 评论参数
     * @return 是否成功
     */
    @Override
    public boolean insertPostComment(PostCommentParam param) {

        PostComment postComment = new PostComment();
        BeanUtils.copyProperties(param, postComment);
        postComment.setLikeCount(0);
        postComment.setReplyCount(0);
        postComment.setUpdateTime(LocalDateTime.now());
        postComment.setCreateTime(LocalDateTime.now());

        return updatePostInfoCount(param.getPostInfoId(), PostStatisticsEnum.COMMENT.type, 1)
                && postCommentService.save(postComment);
    }

    /**
     * 是否不存在帖子评论
     *
     * @param commentId 评论id
     * @return 是否不存在
     */
    @Override
    public boolean isNotExistComment(Integer commentId) {

        return postCommentService.count(Wrappers.<PostComment>lambdaQuery().eq(PostComment::getId, commentId)) == 0;
    }

    /**
     * 点赞/取消点赞评论
     *
     * @param userId    用户编号
     * @param commentId 评论id
     * @return 是否成功
     */
    @Override
    public boolean updatePostCommentLike(Integer userId, Integer commentId) {

        PostComment info = postCommentService.getById(commentId);
        String likeUser = info.getLikeUser();
        List<Integer> likeUserIds = SplitUtil.slice(likeUser);

        if(likeUserIds.contains(userId)) {
            // 已点赞
            likeUserIds.remove(userId);
            info.setLikeUser(SplitUtil.splitJoint(likeUserIds));

            return postCommentService.updateById(info)
                    && updatePostCommentCount(commentId, PostStatisticsEnum.LIKE.type, -1);
        }else {
            // 未点赞
            likeUserIds.add(userId);
            info.setLikeUser(SplitUtil.splitJoint(likeUserIds));
            return postCommentService.updateById(info)
                    && updatePostCommentCount(commentId, PostStatisticsEnum.LIKE.type, 1);
        }
    }

    /**
     * 更新帖子评论统计数字
     *
     * @param commentId 帖子id
     * @param type       类型 2：点赞数3：评论数
     * @param count      数值
     * @return 是否成功
     */
    @Override
    public boolean updatePostCommentCount(Integer commentId, Integer type, Integer count) {

        PostComment postComment = postCommentService.getById(commentId);
        if(ObjectUtil.isNotEmpty(postComment)) {
            if(PostStatisticsEnum.LIKE.type.equals(type)) {
                postComment.setLikeCount(Math.max(postComment.getLikeCount() + count, 0));
            }else if(PostStatisticsEnum.COMMENT.type.equals(type)) {
                postComment.setReplyCount(Math.max(postComment.getReplyCount() + count, 0));
            }
        }

        postComment.setUpdateTime(LocalDateTime.now());
        return postCommentService.updateById(postComment);
    }

    @Override
    public TableSplitResult<PostCommentDTO> listPostComment(Integer userId, Integer postInfoId, Tablepar tablepar, Integer sort) {

        LambdaQueryWrapper<PostComment> lambdaQuery = Wrappers.lambdaQuery();
        lambdaQuery.eq(PostComment::getPostInfoId, postInfoId);
        if(ASC.equals(sort)) {
            lambdaQuery.orderByAsc(PostComment::getCreateTime);
        }else if(DESC.equals(sort)) {
            lambdaQuery.orderByDesc(PostComment::getCreateTime);
        }

        PageHelper.startPage(tablepar.getPageNum(), tablepar.getPageSize());

        List<PostComment> list = postCommentService.list(lambdaQuery);
        PageInfo<PostComment> pageInfo = new PageInfo<>(list);
        List<PostCommentDTO> resultList = new ArrayList<>();

        if(ObjectUtil.isEmpty(userId)) {

            for (PostComment info : list) {
                PostCommentDTO dto = new PostCommentDTO();
                BeanUtils.copyProperties(info, dto);
                dto.setIsLike(false);
                resultList.add(dto);
            }

        }else {

            for (PostComment info : list) {
                PostCommentDTO dto = new PostCommentDTO();
                BeanUtils.copyProperties(info, dto);
                dto.setIsLike(SplitUtil.slice(info.getLikeUser()).contains(userId));
                resultList.add(dto);
            }
        }

        return new TableSplitResult<>(pageInfo.getPageNum(), pageInfo.getTotal(), resultList);
    }

    /**
     * 点赞/取消帖子评论回复
     *
     * @param commentReplyId
     * @param userId
     * @return
     */
    @Override
    public boolean updatePostCommentReplyLike(Integer commentReplyId, Integer userId) {

        PostCommentReply info = postCommentReplyService.getById(commentReplyId);
        String likeUser = info.getLikeUser();
        List<Integer> likeUserIds = SplitUtil.slice(likeUser);

        if(likeUserIds.contains(userId)) {
            // 已点赞
            likeUserIds.remove(userId);
            info.setLikeUser(SplitUtil.splitJoint(likeUserIds));

            return  postCommentReplyService.updateById(info) &&
                    updatePostCommentReplyLikeCount(commentReplyId, -1);
        }else {
            // 未点赞
            likeUserIds.add(userId);
            info.setLikeUser(SplitUtil.splitJoint(likeUserIds));
            return postCommentReplyService.updateById(info)
                    && updatePostCommentReplyLikeCount(commentReplyId, 1);
        }

    }

    /**
     * 更新帖子评论回复点赞数
     *
     * @param commentReplyId 回复id
     * @param count      数值
     * @return 是否成功
     */
    @Override
    public boolean updatePostCommentReplyLikeCount(Integer commentReplyId, Integer count) {

        PostCommentReply postComment = postCommentReplyService.getById(commentReplyId);
        if(ObjectUtil.isNotEmpty(postComment)) {
            int i = postComment.getLikeCount();
            int likeCount = Math.max(postComment.getLikeCount() + count, 0);
            postComment.setLikeCount(likeCount);
            postComment.setUpdateTime(LocalDateTime.now());
        }

        return postCommentReplyService.updateById(postComment);
    }

    /**
     * 是否不存在帖子评论回复
     *
     * @param commentReplyId 评论回复id
     * @return 是否不存在
     */
    @Override
    public boolean isNotExistCommentReply(Integer commentReplyId) {
        return postCommentReplyService
                .count(Wrappers.<PostCommentReply>lambdaQuery().eq(PostCommentReply::getId, commentReplyId)) == 0;
    }

    /**
     * @param userId
     * @param commentId
     * @param tablepar
     * @return
     */
    @Override
    public TableSplitResult<PostCommentReplyDTO> listPostCommentReply(Integer userId,
                                                                      Integer commentId, Tablepar tablepar) {

        LambdaQueryWrapper<PostCommentReply> lambdaQuery = Wrappers.lambdaQuery();
        lambdaQuery.eq(PostCommentReply::getSuilinCommentId, commentId);
        lambdaQuery.orderByDesc(PostCommentReply::getCreateTime);

        PageHelper.startPage(tablepar.getPageNum(), tablepar.getPageSize());

        List<PostCommentReply> list = postCommentReplyService.list(lambdaQuery);
        PageInfo<PostCommentReply> pageInfo = new PageInfo<>(list);
        List<PostCommentReplyDTO> resultList = new ArrayList<>();

        if(ObjectUtil.isEmpty(userId)) {

            for (PostCommentReply info : list) {
                PostCommentReplyDTO dto = new PostCommentReplyDTO();
                BeanUtils.copyProperties(info, dto);
                dto.setIsLike(false);
                resultList.add(dto);
            }

        }else {

            for (PostCommentReply info : list) {
                PostCommentReplyDTO dto = new PostCommentReplyDTO();
                BeanUtils.copyProperties(info, dto);
                dto.setIsLike(SplitUtil.slice(info.getLikeUser()).contains(userId));
                resultList.add(dto);
            }
        }

        return new TableSplitResult<>(pageInfo.getPageNum(), pageInfo.getTotal(), resultList);
    }

    /**
     * 删除评论 同时帖子评论数-1
     * @param commentId 评论id
     * @return 是否成功
     */
    @Override
    public boolean deleteComment(Integer commentId) {

        PostComment postComment = postCommentService.getById(commentId);
        if(ObjectUtil.isNotEmpty(postComment)) {
            updatePostInfoCount(postComment.getPostInfoId(), PostStatisticsEnum.COMMENT.type, -1);
        }

        return postCommentService.removeById(commentId);
    }

    @Override
    public boolean deleteCommentReply(Integer replyId) {
        PostCommentReply commentReply = postCommentReplyService.getById(replyId);

        if(ObjectUtil.isNotEmpty(commentReply)) {
            updatePostCommentCount(commentReply.getId(), PostStatisticsEnum.COMMENT.type, -1);
        }

        return postCommentReplyService.removeById(replyId);
    }

    @Override
    public boolean insertCommentReply(PostCommentReplyParam param) {
        PostCommentReply reply = new PostCommentReply();
        BeanUtils.copyProperties(param, reply);
        reply.setLikeCount(0);
        reply.setCreateTime(LocalDateTime.now());
        reply.setUpdateTime(LocalDateTime.now());


        Integer commentId = param.getSuilinCommentId();
        PostComment byId = postCommentService.getById(commentId);
        if(ObjectUtil.isNotEmpty(byId)) {
            updatePostInfoCount(byId.getPostInfoId(), PostStatisticsEnum.COMMENT.type, 1);
        }

        return postCommentReplyService.save(reply)
                && updatePostCommentCount(param.getSuilinCommentId(), PostStatisticsEnum.COMMENT.type, 1);
    }

    @Override
    public boolean commentIsBelongPost(Integer postInfoId, Integer commentId) {

        PostComment comment = postCommentService.getById(commentId);

        return !ObjectUtil.isEmpty(comment) && comment.getPostInfoId().equals(postInfoId);
    }
}
