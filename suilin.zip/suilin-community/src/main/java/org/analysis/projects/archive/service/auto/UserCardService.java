package org.analysis.projects.archive.service.auto;

import org.analysis.projects.archive.model.auto.UserCard;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 用户档案连接表 服务类
 * </p>
 *
 * @author Feliz
 * @since 2020-05-14
 */
public interface UserCardService extends IService<UserCard> {

}
