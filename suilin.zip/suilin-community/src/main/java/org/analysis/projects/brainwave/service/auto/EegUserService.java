package org.analysis.projects.brainwave.service.auto;

import com.baomidou.mybatisplus.extension.service.IService;
import org.analysis.projects.brainwave.model.auto.EegUser;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author Feliz
 * @since 2019-05-30
 */
public interface EegUserService extends IService<EegUser> {

}
