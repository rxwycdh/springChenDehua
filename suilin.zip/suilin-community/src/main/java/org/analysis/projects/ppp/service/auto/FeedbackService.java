package org.analysis.projects.ppp.service.auto;

import org.analysis.projects.ppp.model.auto.Feedback;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 反馈信息 服务类
 * </p>
 *
 * @author Feliz
 * @since 2020-04-01
 */
public interface FeedbackService extends IService<Feedback> {

}
