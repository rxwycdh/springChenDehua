package org.analysis.projects.archive.model.custom;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.analysis.projects.archive.model.auto.Field;

import java.io.Serializable;

/**
 * <p>
 * 档案字段-值
 * </p>
 *
 * @author Feliz
 * @since 2019-09-21
 */
@ApiModel(value="FieldValue", description="信息字段-值")
public class FieldValue implements Serializable {

    @ApiModelProperty(value = "archive_user_field-id")
    private Integer id;

    @ApiModelProperty(value = "字段id")
    private Field field;

    @ApiModelProperty(value = "字段值")
    private String fieldValue;

    public FieldValue() {
    }

    public FieldValue(Field field, String fieldValue) {
        this.field = field;
        this.fieldValue = fieldValue;
    }

    public FieldValue(Integer id, Field field, String fieldValue) {
        this.id = id;
        this.field = field;
        this.fieldValue = fieldValue;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Field getField() {
        return field;
    }

    public void setField(Field field) {
        this.field = field;
    }

    public String getFieldValue() {
        return fieldValue;
    }

    public void setFieldValue(String fieldValue) {
        this.fieldValue = fieldValue;
    }

    @Override
    public String toString() {
        return "FieldValue{" +
                "id=" + id +
                ", field=" + field +
                ", fieldValue='" + fieldValue + '\'' +
                '}';
    }
}
