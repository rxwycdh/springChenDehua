package org.analysis.projects.ppp.service.auto.impl;

import org.analysis.projects.ppp.model.auto.ProjectTag;
import org.analysis.projects.ppp.mapper.auto.ProjectTagMapper;
import org.analysis.projects.ppp.service.auto.ProjectTagService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 项目标签中间 服务实现类
 * </p>
 *
 * @author Feliz
 * @since 2020-04-03
 */
@Service
public class ProjectTagServiceImpl extends ServiceImpl<ProjectTagMapper, ProjectTag> implements ProjectTagService {

}
