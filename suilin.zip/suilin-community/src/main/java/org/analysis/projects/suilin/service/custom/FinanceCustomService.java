package org.analysis.projects.suilin.service.custom;

import org.analysis.projects.suilin.model.auto.Finance;
import org.analysis.projects.suilin.model.custom.FinanceStatisticsVO;
import org.analysis.projects.suilin.model.custom.FinanceSummaryVO;

import java.util.Date;
import java.util.List;

/**
 * @author ChenDehua  597701764@qq.com
 * @date 2020/8/12 20:28
 */
public interface FinanceCustomService {

    /**
     * 获取小区财政统计
     * @param start 开始日期
     * @param end   结束日期
     * @return 财政统计显示参数
     */
    FinanceStatisticsVO getFinanceStatistics(Date start, Date end);

    /**
     * 获取小区财务概要
     * @return 财务概要
     */
    FinanceSummaryVO getFinanceSummary();

    /**
     * 获取小区财务列表
     * @param start 开始日期
     * @param end   结束日期
     * @return    财务列表
     */
    List<Finance> listFinance(Date start, Date end);
}
