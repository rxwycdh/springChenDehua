package org.analysis.projects.suilin.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.analysis.projects.suilin.model.auto.PostInfo;
import org.analysis.projects.suilin.service.auto.PostInfoService;
import org.analysis.system.common.domain.AjaxResult;
import org.analysis.system.common.domain.TableSplitResult;
import org.analysis.system.common.domain.Tablepar;
import org.analysis.system.common.support.Convert;
import org.analysis.system.model.custom.TitleVo;
import org.analysis.system.util.StringUtils;
import org.analysis.system.common.log.Log;
import org.analysis.system.util.ExcelUtils;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.analysis.system.common.base.BaseController;

import java.time.LocalDateTime;
import javax.servlet.http.HttpServletResponse;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.*;


/**
 * <p>
 * 帖子表 前端控制器
 * </p>
 *
 * @author Feliz
 * @since 2020-08-19 11:04:13
 */
@Controller
@Api(tags = {"帖子表"})
@RequestMapping("/suilin/PostInfoController")
public class PostInfoController extends BaseController{

    private static Logger logger = LoggerFactory.getLogger(PostInfoController.class);

    //跳转页面参数
    private String prefix = "projects/suilin/postInfo";

	@Autowired
	private PostInfoService postInfoService;

	//跳转帖子表页面
    @GetMapping("/view")
    @RequiresPermissions("suilin:postInfo:view")
    public String view(Model model) {
        String str="帖子表";
        setTitle(model, new TitleVo(str+"列表", str+"管理", false, "欢迎进入"+str+"页面", false, false));
        return prefix + "/list";
    }

    @Log(title = "帖子表列表查询", action = "111")
    @ApiOperation(value = "获取帖子表列表", notes = "获取帖子表列表")
    @PostMapping("/list")
    @RequiresPermissions("suilin:postInfo:list")
    @ResponseBody
    public TableSplitResult<PostInfo> list(Tablepar tablepar, String searchText) {

        QueryWrapper<PostInfo> queryWrapper = new QueryWrapper<>();
        if (StringUtils.isNotEmpty(searchText)) {
            queryWrapper.and(wrapper -> wrapper
                    .like("id", searchText).or()
                    .like("suilin_community_id", searchText).or()
                    .like("suilin_user_id", searchText).or()
                    .like("read_count", searchText).or()
                    .like("like_count", searchText).or()
                    .like("comment_count", searchText).or()
                    .like("share_user", searchText).or()
                    .like("like_user", searchText).or()
                    .like("title", searchText).or()
                    .like("content", searchText).or()
                    .like("comment_closed", searchText).or()
                    .like("sort", searchText).or()
            );
        }

        PageHelper.startPage(tablepar.getPageNum(), tablepar.getPageSize());
        List<PostInfo> list = postInfoService.list(queryWrapper);
        PageInfo<PostInfo> pageInfo = new PageInfo<PostInfo>(list);

        return new TableSplitResult<>(pageInfo.getPageNum(), pageInfo.getTotal(), pageInfo.getList());
    }

    @ApiOperation(value = "获取全部帖子表信息", notes = "获取全部帖子表信息")
    @PostMapping("/getAllPostInfo")
    @ResponseBody
    public AjaxResult<TableSplitResult<PostInfo>> getAllPostInfo() {
        try {
            List<PostInfo> list = postInfoService.list();
            return AjaxResult.successDataList(list);
        } catch (Exception e) {
            logger.error(e.toString());
            return AjaxResult.error(e.getMessage());
        }
    }

    //跳转帖子表新增页面
    @GetMapping("/add")
    public String add() {
        return prefix + "/add";
    }

    @Log(title = "帖子表新增", action = "111")
    @ApiOperation(value = "添加帖子表", notes = "添加帖子表")
    @PostMapping("add")
    @RequiresPermissions("suilin:postInfo:add")
    @ResponseBody
    public AjaxResult add(PostInfo postInfo) {
        postInfo.setCreateTime(LocalDateTime.now());
        boolean save = postInfoService.save(postInfo);
        return save ? success() : error();
    }

    @Log(title = "帖子表删除", action = "111")
    @ApiOperation(value = "删除帖子表", notes = "根据id删除帖子表（可批量）")
    @PostMapping("/remove")
    @RequiresPermissions("suilin:postInfo:remove")
    @ResponseBody
    public AjaxResult remove(String ids) {
        List<Integer> idList= Convert.toListIntArray(ids);
        boolean delete = postInfoService.removeByIds(idList);
        return delete ? success() : error();
    }

    @ApiOperation(value = "检查帖子表是否存在", notes = "返回: 1-存在; 0-不存在")
    @PostMapping("/checkUnique")
    @ResponseBody
    public Integer checkUnique(PostInfo postInfo) {
        QueryWrapper<PostInfo> queryWrapper = new QueryWrapper<>();
        //TODO 注意是否正确，默认检测name字段
        //queryWrapper.eq("name", postInfo.getName());
        List<PostInfo> list = postInfoService.list(queryWrapper);
        if (list.size() > 0) {
            return 1;
        } else {
            return 0;
        }
    }

    //跳转帖子表修改页面
    @GetMapping("/edit/{id}")
    public String edit(@PathVariable("id") Integer id, ModelMap modelMap) {
        modelMap.put("postInfo", postInfoService.getById(id));
        return prefix + "/edit";
    }

    @Log(title = "帖子表修改", action = "111")
    @ApiOperation(value = "修改帖子表", notes = "修改帖子表")
    @PostMapping("/edit")
    @RequiresPermissions("suilin:postInfo:edit")
    @ResponseBody
    public AjaxResult editSave(PostInfo postInfo) {
        postInfo.setUpdateTime(LocalDateTime.now());
        boolean edit = postInfoService.updateById(postInfo);
        return edit ? success() : error();
    }


    //跳转帖子表批量新增页面
    @GetMapping("/batchAdd")
    public String batchAdd() {
        return prefix + "/batchAdd";
    }

    @Log(title = "帖子表批量导入", action = "111")
    @ApiOperation(value = "批量导入帖子表", notes = "批量导入帖子表")
    @RequiresPermissions("suilin:postInfo:add")
    @Transactional(propagation = Propagation.REQUIRED)
    @PostMapping("/batchAdd")
    @ResponseBody
    public AjaxResult batchAdd(@RequestParam(value = "file", required = false) MultipartFile file) {
        try {
            String suffer = file.getOriginalFilename().substring(file.getOriginalFilename().indexOf(".") + 1);
            if ("xls".equals(suffer) || "xlsx".equals(suffer)) {
                InputStream in = file.getInputStream();
                Map<String, String> fields = new LinkedHashMap<String, String>();

                fields.put("小区编号", "suilinCommunityId");
                fields.put("用户号", "suilinUserId");
                fields.put("阅读量", "readCount");
                fields.put("点赞数", "likeCount");
                fields.put("评论数", "commentCount");
                fields.put("分享用户号，按照逗号隔开", "shareUser");
                fields.put("点赞用户号，按照逗号隔开", "likeUser");
                fields.put("标题", "title");
                fields.put("内容", "content");
                fields.put("关闭评论：1，开启评论：0", "commentClosed");
                fields.put("排序，权重,显示从大到小", "sort");

                List<PostInfo> list = new ArrayList<PostInfo>();
                list = ExcelUtils.ExecltoList(in, PostInfo.class, fields);

                int sum = list.size();//总需导入数
                int successNum = 0;//成功导入数
                int failNum = 0;//失败导入数
                for (PostInfo o : list) {

                    if (checkUnique(o) == 0) {
                        add(o);
                        successNum++;
                    }else {
                        failNum++;
                    }
                }

                return success("总需导入数：" + sum + "</br>成功导入数：" + successNum +" </br>失败导入数：" + failNum);
            }
            return error("上传文件格式应为xls或xlsx");

        } catch (Exception e) {
            logger.error(ExceptionUtils.getFullStackTrace(e));
            return error("上传文件模板有误，请对比导入模板！");
        }
    }

    @Log(title = "帖子表导入模板获取", action = "111")
    @GetMapping("/getExcelModel")
    @ResponseBody
    public void getUserCardExcelModel(HttpServletResponse response) throws Exception {
        OutputStream out = null;
        //通过response对象获取outputStream流
        response.setContentType("application/octect-stream"); // 下载文件能正常显示中文
        response.setHeader("Content-Disposition", "attachment;filename=" + new String(("帖子表的导入模板.xls").getBytes("gb2312"), "ISO8859-1"));
        out = response.getOutputStream();

        Map<String, String> fields = new LinkedHashMap<String, String>();

        fields.put("suilinCommunityId", "小区编号");
        fields.put("suilinUserId", "用户号");
        fields.put("readCount", "阅读量");
        fields.put("likeCount", "点赞数");
        fields.put("commentCount", "评论数");
        fields.put("shareUser", "分享用户号，按照逗号隔开");
        fields.put("likeUser", "点赞用户号，按照逗号隔开");
        fields.put("title", "标题");
        fields.put("content", "内容");
        fields.put("commentClosed", "关闭评论：1，开启评论：0");
        fields.put("sort", "排序，权重,显示从大到小");

        ExcelUtils.ListtoExecl(null, out, fields);
        out.flush();
        out.close();
    }

	
}
