package org.analysis.projects.jfy.model.auto;

import com.baomidou.mybatisplus.annotation.*;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * <p>
 * 业主决策物业信息表
 * </p>
 *
 * @author Feliz
 * @since 2019-07-03
 */
@TableName("jfy_property_information")
@ApiModel(value="PropertyInformation对象", description="业主决策物业信息表")
public class PropertyInformation implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    @ApiModelProperty(hidden = true)
    private Integer id;

    @ApiModelProperty(value = "业主姓名")
    @TableField("proprietor_name")
    private String proprietorName;

    @ApiModelProperty(value = "房产证地址")
    @TableField("house_address")
    private String houseAddress;

    @ApiModelProperty(value = "车位地址")
    @TableField("park_address")
    private String parkAddress;

    @ApiModelProperty(value = "房屋面积")
    @TableField("house_area")
    private BigDecimal houseArea;

    @ApiModelProperty(value = "车位面积")
    @TableField("park_area")
    private BigDecimal parkArea;

    @ApiModelProperty(value = "手机号")
    @TableField("phone")
    private String phone;

    @ApiModelProperty(value = "逻辑删除；1：删除；0：正常", hidden = true)
    @JsonIgnore
    @TableField("deleted")
    @TableLogic
    private Integer deleted;

    @ApiModelProperty(value = "创建时间", hidden = true)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @TableField("create_time")
    private LocalDateTime createTime;

    @ApiModelProperty(value = "修改时间", hidden = true)
    @JsonIgnore
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @TableField("update_time")
    private LocalDateTime updateTime;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getProprietorName() {
        return proprietorName;
    }

    public void setProprietorName(String proprietorName) {
        this.proprietorName = proprietorName;
    }

    public String getHouseAddress() {
        return houseAddress;
    }

    public void setHouseAddress(String houseAddress) {
        this.houseAddress = houseAddress;
    }

    public String getParkAddress() {
        return parkAddress;
    }

    public void setParkAddress(String parkAddress) {
        this.parkAddress = parkAddress;
    }

    public BigDecimal getHouseArea() {
        return houseArea;
    }

    public void setHouseArea(BigDecimal houseArea) {
        this.houseArea = houseArea;
    }

    public BigDecimal getParkArea() {
        return parkArea;
    }

    public void setParkArea(BigDecimal parkArea) {
        this.parkArea = parkArea;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public Integer getDeleted() {
        return deleted;
    }

    public void setDeleted(Integer deleted) {
        this.deleted = deleted;
    }

    public LocalDateTime getCreateTime() {
        return createTime;
    }

    public void setCreateTime(LocalDateTime createTime) {
        this.createTime = createTime;
    }

    public LocalDateTime getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(LocalDateTime updateTime) {
        this.updateTime = updateTime;
    }

    @Override
    public String toString() {
        return "PropertyInformation{" +
        "id=" + id +
        ", proprietorName=" + proprietorName +
        ", houseAddress=" + houseAddress +
        ", parkAddress=" + parkAddress +
        ", houseArea=" + houseArea +
        ", parkArea=" + parkArea +
        ", phone=" + phone +
        ", deleted=" + deleted +
        ", createTime=" + createTime +
        ", updateTime=" + updateTime +
        "}";
    }
}
