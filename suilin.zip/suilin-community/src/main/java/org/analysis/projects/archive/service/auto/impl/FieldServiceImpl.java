package org.analysis.projects.archive.service.auto.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.analysis.projects.archive.mapper.auto.FieldMapper;
import org.analysis.projects.archive.model.auto.Field;
import org.analysis.projects.archive.service.auto.FieldService;
import org.analysis.system.common.support.Convert;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * <p>
 * 档案字段 服务实现类
 * </p>
 *
 * @author Feliz
 * @since 2019-09-10
 */
@Service
public class FieldServiceImpl extends ServiceImpl<FieldMapper, Field> implements FieldService {

    @Override
    public List<Field> listByIds(String ids) {
        List<Field> list = new ArrayList<>();
        if (ids == null) {
            ids = "";
        }
        List<String> idList= Convert.toListStrArray(ids);

        for (String id: idList) {
            Field field = this.getById(id);
            if (field != null) {
                list.add(field);
            }
        }

        return list;
    }
}
