package org.analysis.projects.ppp.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.analysis.projects.ppp.logic.ArticleTagLogic;
import org.analysis.projects.ppp.model.auto.Article;
import org.analysis.projects.ppp.model.custom.ArticleVO;
import org.analysis.projects.ppp.service.auto.ArticleService;
import org.analysis.system.common.base.BaseController;
import org.analysis.system.common.domain.AjaxResult;
import org.analysis.system.common.domain.TableSplitResult;
import org.analysis.system.common.domain.Tablepar;
import org.analysis.system.common.log.Log;
import org.analysis.system.common.support.Convert;
import org.analysis.system.model.auto.TsysFile;
import org.analysis.system.model.auto.TsysUser;
import org.analysis.system.model.custom.TitleVo;
import org.analysis.system.shiro.util.ShiroUtils;
import org.analysis.system.util.StringUtils;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;


/**
 * <p>
 * 文章信息表 前端控制器
 * </p>
 *
 * @author Feliz
 * @since 2020-03-29 22:25:02
 */
@Controller
@Api(tags = {"文章信息表"})
@RequestMapping("/ppp/ArticleController")
public class ArticleController extends BaseController {

    private static Logger logger = LoggerFactory.getLogger(ArticleController.class);

    //跳转页面参数
    private String prefix = "projects/ppp/article";

    @Autowired
    private ArticleService articleService;
    @Autowired
    private ArticleTagLogic articleTagLogic;

    //跳转文章信息表页面
    @GetMapping("/view")
    @RequiresPermissions("ppp:article:view")
    public String view(Model model) {
        String str = "文章信息表";
        setTitle(model, new TitleVo(str + "列表", str + "管理", false, "欢迎进入" + str + "页面", false, false));
        return prefix + "/list";
    }

    @Log(title = "文章信息表列表查询", action = "111")
    @ApiOperation(value = "获取文章信息表列表", notes = "获取文章信息表列表")
    @PostMapping("/list")
    @RequiresPermissions("ppp:article:list")
    @ResponseBody
    public TableSplitResult<ArticleVO> list(Tablepar tablepar, String searchText) {

        QueryWrapper<Article> queryWrapper = new QueryWrapper<>();
        if (StringUtils.isNotEmpty(searchText)) {
            queryWrapper.and(wrapper -> wrapper
                    .like("title", searchText).or()
                    .like("author", searchText).or()
            );
        }

        queryWrapper.orderByDesc("state!=0,state", "create_time is null,create_time");
        PageHelper.startPage(tablepar.getPageNum(), tablepar.getPageSize());
        List<Article> articleList = articleService.list(queryWrapper);
        PageInfo<Article> pageInfo = new PageInfo<Article>(articleList);

        List<ArticleVO> list = new ArrayList<>();
        for (Article article : articleList) {
            ArticleVO articleVO = new ArticleVO();
            try {
                BeanUtils.copyProperties(articleVO, article);
            } catch (Exception e) {
                logger.error(e.getMessage());
            }

            if (article.getPublisherId() != null) {
                TsysUser tsysUser = sysUserService.selectByPrimaryKey(article.getPublisherId());
                articleVO.setPublisherName(tsysUser.getUsername());
            }

            String tagsName = articleTagLogic.queryArticleTags(article.getId());
            articleVO.setTagsName(String.join(",", tagsName));

            list.add(articleVO);
        }

        return new TableSplitResult<>(pageInfo.getPageNum(), pageInfo.getTotal(), list);
    }

    @ApiOperation(value = "获取全部文章信息表信息", notes = "获取全部文章信息表信息")
    @PostMapping("/getAllArticle")
    @ResponseBody
    public AjaxResult<TableSplitResult<Article>> getAllArticle() {
        try {
            List<Article> list = articleService.list();
            return AjaxResult.successDataList(list);
        } catch (Exception e) {
            logger.error(e.toString());
            return AjaxResult.error(e.getMessage());
        }
    }

    //跳转文章信息表新增页面
    @GetMapping("/add")
    public String add(Integer quote, Model model) {
        if (quote == null || quote == 0) {
            model.addAttribute("quote", 0);
        }else if (quote == 1){
            model.addAttribute("quote", 1);
        }else {
            model.addAttribute("quote", 0);
        }

        return prefix + "/add";
    }

    @Log(title = "文章信息表新增", action = "111")
    @ApiOperation(value = "添加文章信息表", notes = "添加文章信息表")
    @PostMapping("add")
    @RequiresPermissions("ppp:article:add")
    @Transactional
    @ResponseBody
    public AjaxResult add(Article article, String tagsName, Integer dataId) {

        try {
            //添加文件
            if (dataId != null) {
                TsysFile record = new TsysFile();
                record.setFileName("rotationChart-" + article.getTitle());
                int fileId = sysFileService.insertSelective(record, dataId);
                article.setCoverId(fileId);
            }

            //更新发布时间
            if (article.getState() == 1) {
                article.setCreateTime(LocalDateTime.now());
                article.setPublisherId(ShiroUtils.getUserId());
            }
            boolean save = articleService.save(article);

            //添加标签
            articleTagLogic.addArticleTags(article.getId(), tagsName);
            if (save) {
                return success();
            } else {
                return error();
            }
        } catch (Exception e) {
            logger.error(ExceptionUtils.getFullStackTrace(e));
            return error();
        }
    }

    @Log(title = "文章信息表删除", action = "111")
    @ApiOperation(value = "删除文章信息表", notes = "根据id删除文章信息表（可批量）")
    @PostMapping("/remove")
    @RequiresPermissions("ppp:article:remove")
    @Transactional
    @ResponseBody
    public AjaxResult remove(String ids) {

        try {
            List<Integer> idList = Convert.toListIntArray(ids);

            //删除标签数据
            for (Integer id : idList) {
                articleTagLogic.removeArticleTags(id);
            }

            boolean delete = articleService.removeByIds(idList);
            if (delete) {
                return success();
            } else {
                return error();
            }
        } catch (Exception e) {
            logger.error(ExceptionUtils.getFullStackTrace(e));
            return error();
        }
    }


    //跳转文章信息表修改页面
    @GetMapping("/edit/{id}")
    public String edit(@PathVariable("id") Integer id, ModelMap mmap) {

        Article article = articleService.getById(id);
        ArticleVO articleVO = new ArticleVO();
        try {
            BeanUtils.copyProperties(articleVO, article);
        } catch (Exception e) {
            logger.error(e.getMessage());
        }

        String tagsName = articleTagLogic.queryArticleTags(article.getId());
        articleVO.setTagsName(String.join(",", tagsName));

        mmap.put("articleVO", articleVO);

        return prefix + "/edit";
    }

    @Log(title = "文章信息表修改", action = "111")
    @ApiOperation(value = "修改文章信息表", notes = "修改文章信息表")
    @PostMapping("/edit")
    @RequiresPermissions("ppp:article:edit")
    @Transactional
    @ResponseBody
    public AjaxResult editSave(Article article, String tagsName, Integer dataId) {

        try {
            //修改文件
            TsysFile record = sysFileService.selectByPrimaryKey(article.getCoverId());
            if (record != null) {
                record.setFileName("rotationChart-" + article.getTitle());
                sysFileService.updateByPrimaryKey(record, dataId);
            }else {
                TsysFile newRecord = new TsysFile();
                newRecord.setFileName("rotationChart-" + article.getTitle());
                int fileId = sysFileService.insertSelective(newRecord, dataId);
                article.setCoverId(fileId);
            }

            //删除旧标签重新添加新标签
            articleTagLogic.removeArticleTags(article.getId());
            articleTagLogic.addArticleTags(article.getId(), tagsName);

            article.setUpdateTime(LocalDateTime.now());
            boolean b = articleService.updateById(article);
            return b ? success() : error();
        } catch (Exception e) {
            logger.error(ExceptionUtils.getFullStackTrace(e));
            return error();
        }
    }

    @Log(title = "发布文章", action = "111")
    @ApiOperation(value = "发布文章", notes = "发布文章")
    @GetMapping("/publish/{id}")
    @RequiresPermissions("ppp:article:edit")
    @ResponseBody
    public AjaxResult publish(@PathVariable("id") Integer id) {

        Article article = articleService.getById(id);
        article.setState(1);
        article.setPublisherId(ShiroUtils.getUserId());
        if(article.getCreateTime() == null) {
            article.setCreateTime(LocalDateTime.now());
        }

        boolean b = articleService.updateById(article);
        return b ? success() : error();
    }

    @Log(title = "下架文章", action = "111")
    @ApiOperation(value = "下架文章", notes = "下架文章")
    @GetMapping("/off/{id}")
    @RequiresPermissions("ppp:article:edit")
    @ResponseBody
    public AjaxResult off(@PathVariable("id") Integer id) {

        Article article = articleService.getById(id);
        article.setState(2);
        article.setUpdateTime(LocalDateTime.now());

        boolean b = articleService.updateById(article);
        return b ? success() : error();
    }

    //跳转项目详细信息页面
    @GetMapping("/detail/{id}")
    public String detail(@PathVariable("id") Integer id, ModelMap mmap) {

        Article article = articleService.getById(id);
        ArticleVO articleVO = new ArticleVO();
        try {
            BeanUtils.copyProperties(articleVO, article);
        } catch (Exception e) {
            logger.error(e.getMessage());
        }

        String tagsName = articleTagLogic.queryArticleTags(article.getId());
        articleVO.setTagsName(String.join(",", tagsName));

        mmap.put("articleVO", articleVO);

        return prefix + "/detail";
    }


}
