package org.analysis.projects.suilin.service.auto;

import org.analysis.projects.suilin.model.auto.PostComment;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 帖子评论表 服务类
 * </p>
 *
 * @author Feliz
 * @since 2020-08-19
 */
public interface PostCommentService extends IService<PostComment> {

}
