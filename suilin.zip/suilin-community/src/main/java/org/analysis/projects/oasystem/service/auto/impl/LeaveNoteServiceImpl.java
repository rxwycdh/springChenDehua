package org.analysis.projects.oasystem.service.auto.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.analysis.projects.oasystem.mapper.auto.LeaveNoteMapper;
import org.analysis.projects.oasystem.model.auto.LeaveNote;
import org.analysis.projects.oasystem.service.auto.LeaveNoteService;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 请假说明 服务实现类
 * </p>
 *
 * @author Feliz
 * @since 2019-06-22
 */
@Service
public class LeaveNoteServiceImpl extends ServiceImpl<LeaveNoteMapper, LeaveNote> implements LeaveNoteService {

}
