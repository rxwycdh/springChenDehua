package org.analysis.projects.oasystem.service.auto.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.analysis.projects.oasystem.mapper.auto.ProcessLeaveMapper;
import org.analysis.projects.oasystem.model.auto.ProcessLeave;
import org.analysis.projects.oasystem.service.auto.ProcessLeaveService;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 请假申请 服务实现类
 * </p>
 *
 * @author Feliz
 * @since 2019-06-22
 */
@Service
public class ProcessLeaveServiceImpl extends ServiceImpl<ProcessLeaveMapper, ProcessLeave> implements ProcessLeaveService {

}
