package org.analysis.projects.oasystem.model.auto;

import com.baomidou.mybatisplus.annotation.*;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * <p>
 * 
 * </p>
 *
 * @author Feliz
 * @since 2019-06-21
 */
@TableName("oasystem_claim_detail")
@ApiModel(value="ClaimDetail对象", description="")
public class ClaimDetail implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "费用日期")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @TableField("expense_date")
    private LocalDateTime expenseDate;

    @ApiModelProperty(value = "费用科目")
    @TableField("expense_subject")
    private String expenseSubject;

    @ApiModelProperty(value = "费用说明")
    @TableField("expense_explanation")
    private String expenseExplanation;

    @ApiModelProperty(value = "票据张数")
    @TableField("bill_num")
    private Integer billNum;

    @ApiModelProperty(value = "报销金额")
    @TableField("claim_amount")
    private BigDecimal claimAmount;

    @ApiModelProperty(value = "描述")
    @TableField("description")
    private String description;

    @ApiModelProperty(value = "逻辑删除；1：删除；0：正常")
    @TableField("deleted")
    @TableLogic
    private Integer deleted;

    @ApiModelProperty(value = "创建时间")
    @TableField("create_time")
    private LocalDateTime createTime;

    @ApiModelProperty(value = "修改时间")
    @TableField("update_time")
    private LocalDateTime updateTime;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public LocalDateTime getExpenseDate() {
        return expenseDate;
    }

    public void setExpenseDate(LocalDateTime expenseDate) {
        this.expenseDate = expenseDate;
    }

    public String getExpenseSubject() {
        return expenseSubject;
    }

    public void setExpenseSubject(String expenseSubject) {
        this.expenseSubject = expenseSubject;
    }

    public String getExpenseExplanation() {
        return expenseExplanation;
    }

    public void setExpenseExplanation(String expenseExplanation) {
        this.expenseExplanation = expenseExplanation;
    }

    public Integer getbillNum() {
        return billNum;
    }

    public void setbillNum(Integer  billNum) {
        this.billNum = billNum;
    }

    public BigDecimal getClaimAmount() {
        return claimAmount;
    }

    public void setClaimAmount(BigDecimal claimAmount) {
        this.claimAmount = claimAmount;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getDeleted() {
        return deleted;
    }

    public void setDeleted(Integer deleted) {
        this.deleted = deleted;
    }

    public LocalDateTime getCreateTime() {
        return createTime;
    }

    public void setCreateTime(LocalDateTime createTime) {
        this.createTime = createTime;
    }

    public LocalDateTime getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(LocalDateTime updateTime) {
        this.updateTime = updateTime;
    }

    @Override
    public String toString() {
        return "ClaimDetail{" +
        "id=" + id +
        ", expenseDate=" + expenseDate +
        ", expenseSubject=" + expenseSubject +
        ", expenseExplanation=" + expenseExplanation +
        ", billNum=" + billNum +
        ", claimAmount=" + claimAmount +
        ", description=" + description +
        ", deleted=" + deleted +
        ", createTime=" + createTime +
        ", updateTime=" + updateTime +
        "}";
    }
}
