package org.analysis.projects.ppp.logic;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import org.analysis.projects.ppp.model.auto.ProjectTag;
import org.analysis.projects.ppp.model.auto.Tag;
import org.analysis.projects.ppp.service.auto.ProjectTagService;
import org.analysis.projects.ppp.service.auto.TagService;
import org.analysis.system.common.support.Convert;
import org.analysis.system.util.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Service
public class ProjectTagLogic {

    @Autowired
    private TagService tagService;
    @Autowired
    private ProjectTagService projectTagService;

    /**
     * 查询项目标签信息
     * @param projectId 项目id
     * @return
     */
    public String queryProjectTags(Integer projectId){

        QueryWrapper<ProjectTag> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("project_id", projectId);
        List<ProjectTag> list = projectTagService.list(queryWrapper);

        List<Tag> tagList = new ArrayList<>();
        for (ProjectTag pt : list) {
            tagList.add(tagService.getById(pt.getTagId()));
        }

        List<String> tagsName = new ArrayList<>();
        for (Tag tag : tagList) {
            tagsName.add(tag.getName());
        }

        return String.join(",", tagsName);
    }

    /**
     * 新增项目标签（通过新增中间表数据）
     * @param projectId 项目id
     * @param tagsName 标签名字符串，逗号隔开
     * @throws Exception
     */
    public void addProjectTags(Integer projectId, String tagsName) throws Exception{

        if (StringUtils.isEmpty(tagsName)) {
            return;
        }
        List<String> tagsNameList = Convert.toListStrArray(tagsName);

        for (String tagName : tagsNameList) {
            ProjectTag projectTag = new ProjectTag();
            projectTag.setProjectId(projectId);

            QueryWrapper<Tag> queryWrapper = new QueryWrapper<>();
            queryWrapper.eq("name", tagName);
            Tag tag = tagService.getOne(queryWrapper);

            //标签已存在则直接新增中间表数据，否则新增标签以及中间表数据
            if (tag != null) {
                projectTag.setTagId(tag.getId());
                boolean save = projectTagService.save(projectTag);
                if (!save) {
                    throw new Exception("新增项目标签中间表数据出错");
                }
            }else {
                tag = new Tag();
                tag.setName(tagName);
                tag.setCreateTime(LocalDateTime.now());
                boolean save = tagService.save(tag);
                if (!save) {
                    throw new Exception("新增标签数据出错");
                }

                projectTag.setTagId(tag.getId());
                boolean save2 = projectTagService.save(projectTag);
                if (!save2) {
                    throw new Exception("新增项目标签中间表数据出错");
                }
            }

        }
    }


    /**
     * 删除项目标签（通过删除中间表数据）
     * @param projectId 项目id
     * @throws Exception
     */
    public void removeArticleTags(Integer projectId) throws Exception{

        QueryWrapper<ProjectTag> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("project_id", projectId);
        boolean remove = projectTagService.remove(queryWrapper);

        if (!remove) {
            throw new Exception("删除项目标签中间表数据出错");
        }
    }
}
