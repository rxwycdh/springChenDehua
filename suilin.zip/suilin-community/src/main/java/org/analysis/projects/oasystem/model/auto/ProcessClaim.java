package org.analysis.projects.oasystem.model.auto;

import com.baomidou.mybatisplus.annotation.*;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * <p>
 * 费用报销
 * </p>
 *
 * @author Feliz
 * @since 2019-06-21
 */
@TableName("oasystem_process_claim")
@ApiModel(value="ProcessClaim对象", description="费用报销")
public class ProcessClaim implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "标题")
    @TableField("title")
    private String title;

    @ApiModelProperty(value = "提单人员")
    @TableField("staff")
    private String staff;

    @ApiModelProperty(value = "证明人	")
    @TableField("voucher")
    private String voucher;

    @ApiModelProperty(value = "紧急程度")
    @TableField("status_id")
    private Integer statusId;

    @ApiModelProperty(value = "相关客户")
    @TableField("related_customers")
    private String relatedCustomers;

    @ApiModelProperty(value = "报销方式")
    @TableField("claim_type")
    private String claimType;

    @ApiModelProperty(value = "审核人员")
    @TableField("auditor")
    private String auditor;

    @ApiModelProperty(value = "报销事由")
    @TableField("claim_reasons")
    private String claimReasons;

    @ApiModelProperty(value = "报销明细")
    @TableField("detail_ids")
    private String detailIds;

    @ApiModelProperty(value = "描述")
    @TableField("description")
    private String description;

    @ApiModelProperty(value = "逻辑删除；1：删除；0：正常")
    @TableField("deleted")
    @TableLogic
    private Integer deleted;

    @ApiModelProperty(value = "创建时间")
    @TableField("create_time")
    private LocalDateTime createTime;

    @ApiModelProperty(value = "修改时间")
    @TableField("update_time")
    private LocalDateTime updateTime;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getStaff() {
        return staff;
    }

    public void setStaff(String staff) {
        this.staff = staff;
    }

    public String getVoucher() {
        return voucher;
    }

    public void setVoucher(String voucher) {
        this.voucher = voucher;
    }

    public Integer getStatusId() {
        return statusId;
    }

    public void setStatusId(Integer statusId) {
        this.statusId = statusId;
    }

    public String getRelatedCustomers() {
        return relatedCustomers;
    }

    public void setRelatedCustomers(String relatedCustomers) {
        this.relatedCustomers = relatedCustomers;
    }

    public String getClaimType() {
        return claimType;
    }

    public void setClaimType(String claimType) {
        this.claimType = claimType;
    }

    public String getAuditor() {
        return auditor;
    }

    public void setAuditor(String auditor) {
        this.auditor = auditor;
    }

    public String getClaimReasons() {
        return claimReasons;
    }

    public void setClaimReasons(String claimReasons) {
        this.claimReasons = claimReasons;
    }

    public String getDetailIds() {
        return detailIds;
    }

    public void setDetailIds(String detailIds) {
        this.detailIds = detailIds;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getDeleted() {
        return deleted;
    }

    public void setDeleted(Integer deleted) {
        this.deleted = deleted;
    }

    public LocalDateTime getCreateTime() {
        return createTime;
    }

    public void setCreateTime(LocalDateTime createTime) {
        this.createTime = createTime;
    }

    public LocalDateTime getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(LocalDateTime updateTime) {
        this.updateTime = updateTime;
    }

    @Override
    public String toString() {
        return "ProcessClaim{" +
                "id=" + id +
                ", title='" + title + '\'' +
                ", staff='" + staff + '\'' +
                ", voucher='" + voucher + '\'' +
                ", statusId=" + statusId +
                ", relatedCustomers='" + relatedCustomers + '\'' +
                ", claimType='" + claimType + '\'' +
                ", auditor='" + auditor + '\'' +
                ", claimReasons='" + claimReasons + '\'' +
                ", detailIds='" + detailIds + '\'' +
                ", description='" + description + '\'' +
                ", deleted=" + deleted +
                ", createTime=" + createTime +
                ", updateTime=" + updateTime +
                '}';
    }
}
