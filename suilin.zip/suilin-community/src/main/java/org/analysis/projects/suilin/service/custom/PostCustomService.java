package org.analysis.projects.suilin.service.custom;

import org.analysis.projects.suilin.miniapp.model.PostCommentDTO;
import org.analysis.projects.suilin.miniapp.model.PostCommentReplyDTO;
import org.analysis.projects.suilin.miniapp.model.PostInfoDTO;
import org.analysis.projects.suilin.miniapp.param.PostCommentParam;
import org.analysis.projects.suilin.miniapp.param.PostCommentReplyParam;
import org.analysis.projects.suilin.model.auto.PostInfo;
import org.analysis.system.common.domain.TableSplitResult;
import org.analysis.system.common.domain.Tablepar;

/**
 * @author ChenDehua  597701764@qq.com
 * @date 2020/8/19 10:05
 */
public interface PostCustomService {

    /**
     * 点赞/取消点赞帖子
     * @param userId 用户编号
     * @param postInfoId 帖子编号
     * @return 是否成功
     */
    boolean updatePostLike(Integer userId, Integer postInfoId);

    /**
     * 获取文章
     * @param postInfoId 帖子id
     * @param userId 用户id
     * @return 文章
     */
    PostInfoDTO getPostInfo(Integer postInfoId, Integer userId);

    /**
     * 检查帖子是否不存在
     * @param postInfoId 帖子编号
     * @return 是否不存在
     */
    boolean isNotExistPostInfo(Integer postInfoId);

    /**
     * 更新帖子统计数字
     * @param postInfoId 帖子id
     * @param type 类型1：阅读量2：点赞数3：评论数
     * @param count 数值
     * @return 是否成功
     */
    boolean updatePostInfoCount(Integer postInfoId, Integer type, Integer count);

    /**
     * 插入用户到分享用户的字段中
     * @param postInfoId 帖子id
     * @param userId 用户id
     * @return 是否成功
     */
    boolean insertShareUser(Integer postInfoId, Integer userId);

    /**
     * 分页获取帖子
     * @param userId
     * @param tablepar 分页参数
     * @param sortType 排序1：最新（按照时间倒序）2：最热（按照权重倒序）
     * @param searchText 关键词
     * @return 列表
     */
    TableSplitResult<PostInfoDTO> listPostInfo(Integer userId, Tablepar tablepar, Integer sortType, String searchText);

    /**
     * 帖子是否不允许评论
     * @param postInfoId 帖子id
     * @return 帖子是否不允许评论
     */
    boolean isNotAllowComment(Integer postInfoId);

    /**
     * 插入帖子评论
     * @param param 评论参数
     * @return 是否成功
     */
    boolean insertPostComment(PostCommentParam param);

    /**
     * 是否不存在帖子评论
     * @param commentId 评论id
     * @return 是否不存在
     */
    boolean isNotExistComment(Integer commentId);

    /**
     * 点赞/取消点赞评论
     * @param userId 用户编号
     * @param commentId 评论id
     * @return 是否成功
     */
    boolean updatePostCommentLike(Integer userId, Integer commentId);

    /**
     * 更新帖子评论统计数字
     * @param commentId 帖子id
     * @param type 类型 2：点赞数3：评论数
     * @param count 数值
     * @return 是否成功
     */
    boolean updatePostCommentCount(Integer commentId, Integer type, Integer count);

    /**
     * 获取评论
     * @param userId 用户id
     * @param postInfoId 帖子id
     * @param tablepar 分页参数
     * @param sort 排序
     * @return 评论列表
     */
    TableSplitResult<PostCommentDTO> listPostComment(Integer userId, Integer postInfoId, Tablepar tablepar, Integer sort);

    /**
     * 点赞/取消帖子评论回复
     * @param commentReplyId 回复id
     * @param userId 用户id
     * @return 是否成功
     */
    boolean updatePostCommentReplyLike(Integer commentReplyId, Integer userId);

    /**
     * 更新帖子评论回复点赞数
     *
     * @param commentReplyId 回复id
     * @param count      数值
     * @return 是否成功
     */
    boolean updatePostCommentReplyLikeCount(Integer commentReplyId, Integer count);

    /**
     * 是否不存在帖子评论回复
     * @param commentReplyId 评论回复id
     * @return 是否不存在
     */
    boolean isNotExistCommentReply(Integer commentReplyId);

    /**
     * 获取评论回复
     * @param userId 用户id
     * @param commentId 评论id
     * @param tablepar 分页参数
     * @return 评论回复列表
     */
    TableSplitResult<PostCommentReplyDTO> listPostCommentReply(Integer userId, Integer commentId, Tablepar tablepar);

    /**
     * 删除评论 同时帖子评论数-1
     * @param commentId 评论id
     * @return 是否成功
     */
    boolean deleteComment(Integer commentId);

    /**
     * 删除评论回复 同时评论回复数-1
     * @param replyId
     * @return
     */
    boolean deleteCommentReply(Integer replyId);

    /**
     * 插入评论回复 同时评论回复数+1
     * @param param 评论回复参数
     * @return 是否成功
     */
    boolean insertCommentReply(PostCommentReplyParam param);

    /**
     * 判断评论是否属于此帖子
     * @param postInfoId  帖子id
     * @param commentId 评论id
     * @return 是否属于
     */
    boolean commentIsBelongPost(Integer postInfoId, Integer commentId);
}
