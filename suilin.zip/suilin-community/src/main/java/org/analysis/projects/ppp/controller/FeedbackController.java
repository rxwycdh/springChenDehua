package org.analysis.projects.ppp.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.analysis.projects.ppp.model.auto.Feedback;
import org.analysis.projects.ppp.model.custom.FeedbackVO;
import org.analysis.projects.ppp.service.auto.FeedbackService;
import org.analysis.system.common.base.BaseController;
import org.analysis.system.common.domain.AjaxResult;
import org.analysis.system.common.domain.TableSplitResult;
import org.analysis.system.common.domain.Tablepar;
import org.analysis.system.common.log.Log;
import org.analysis.system.common.support.Convert;
import org.analysis.system.model.auto.TsysUser;
import org.analysis.system.model.custom.TitleVo;
import org.analysis.system.shiro.util.ShiroUtils;
import org.analysis.system.util.StringUtils;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;


/**
 * <p>
 * 反馈信息 前端控制器
 * </p>
 *
 * @author Feliz
 * @since 2020-04-01 20:46:45
 */
@Controller
@Api(tags = {"反馈信息"})
@RequestMapping("/ppp/FeedbackController")
public class FeedbackController extends BaseController{

    private static Logger logger = LoggerFactory.getLogger(FeedbackController.class);

    //跳转页面参数
    private String prefix = "projects/ppp/feedback";

	@Autowired
	private FeedbackService feedbackService;

	//跳转反馈信息页面
    @GetMapping("/view")
    @RequiresPermissions("ppp:feedback:view")
    public String view(Model model) {
        String str="反馈信息";
        setTitle(model, new TitleVo(str+"列表", str+"管理", false, "欢迎进入"+str+"页面", false, false));
        return prefix + "/list";
    }

    @Log(title = "反馈信息列表查询", action = "111")
    @ApiOperation(value = "获取反馈信息列表", notes = "获取反馈信息列表")
    @PostMapping("/list")
    @RequiresPermissions("ppp:feedback:list")
    @ResponseBody
    public TableSplitResult<FeedbackVO> list(Tablepar tablepar, String searchText) {

        QueryWrapper<Feedback> queryWrapper = new QueryWrapper<>();
        if (StringUtils.isNotEmpty(searchText)) {
            queryWrapper.and(wrapper -> wrapper
                    .like("email", searchText).or()
                    .like("feedback", searchText).or()
                    .like("result", searchText).or()
            );
        }

        PageHelper.startPage(tablepar.getPageNum(), tablepar.getPageSize());
        List<Feedback> feedbacks = feedbackService.list(queryWrapper);
        PageInfo<Feedback> pageInfo = new PageInfo<Feedback>(feedbacks);

        List<FeedbackVO> list = new ArrayList<>();
        for (Feedback fb : feedbacks) {
            FeedbackVO feedbackVO = new FeedbackVO();

            try {
                BeanUtils.copyProperties(feedbackVO, fb);
            } catch (Exception e) {
                logger.error(e.getMessage());
            }

            if (fb.getHandlerId() != null) {
                TsysUser tsysUser = sysUserService.selectByPrimaryKey(fb.getHandlerId());
                feedbackVO.setHandlerName(tsysUser.getUsername());
            }

            list.add(feedbackVO);
        }

        return new TableSplitResult<>(pageInfo.getPageNum(), pageInfo.getTotal(), list);
    }

    @ApiOperation(value = "获取全部反馈信息信息", notes = "获取全部反馈信息信息")
    @PostMapping("/getAllFeedback")
    @ResponseBody
    public AjaxResult<TableSplitResult<Feedback>> getAllFeedback() {
        try {
            List<Feedback> list = feedbackService.list();
            return AjaxResult.successDataList(list);
        } catch (Exception e) {
            logger.error(e.toString());
            return AjaxResult.error(e.getMessage());
        }
    }

    //跳转反馈信息新增页面
    @GetMapping("/add")
    public String add() {
        return prefix + "/add";
    }

    @Log(title = "反馈信息新增", action = "111")
    @ApiOperation(value = "添加反馈信息", notes = "添加反馈信息")
    @PostMapping("add")
    @RequiresPermissions("ppp:feedback:add")
    @ResponseBody
    public AjaxResult add(Feedback feedback) {
        feedback.setCreateTime(LocalDateTime.now());
        boolean save = feedbackService.save(feedback);
        return save ? success() : error();
    }

    @Log(title = "反馈信息删除", action = "111")
    @ApiOperation(value = "删除反馈信息", notes = "根据id删除反馈信息（可批量）")
    @PostMapping("/remove")
    @RequiresPermissions("ppp:feedback:remove")
    @ResponseBody
    public AjaxResult remove(String ids) {
        List<Integer> idList= Convert.toListIntArray(ids);
        boolean delete = feedbackService.removeByIds(idList);
        return delete ? success() : error();
    }

    //跳转反馈信息处理页面
    @GetMapping("/edit/{id}")
    public String edit(@PathVariable("id") Integer id, ModelMap mmap) {
        mmap.put("feedback", feedbackService.getById(id));
        return prefix + "/edit";
    }

    @Log(title = "反馈信息处理", action = "111")
    @ApiOperation(value = "处理反馈信息", notes = "处理反馈信息")
    @PostMapping("/edit")
    @RequiresPermissions("ppp:feedback:edit")
    @ResponseBody
    public AjaxResult editSave(Feedback feedback) {
        feedback.setHandlerId(ShiroUtils.getUserId());
        feedback.setUpdateTime(LocalDateTime.now());
        boolean edit = feedbackService.updateById(feedback);
        return edit ? success() : error();
    }
	
}
