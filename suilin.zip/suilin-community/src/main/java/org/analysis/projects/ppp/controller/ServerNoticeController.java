package org.analysis.projects.ppp.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.analysis.projects.ppp.model.auto.ServerNotice;
import org.analysis.projects.ppp.model.auto.ServerUser;
import org.analysis.projects.ppp.model.custom.ServerNoticeVO;
import org.analysis.projects.ppp.service.auto.ServerNoticeService;
import org.analysis.projects.ppp.service.auto.ServerUserService;
import org.analysis.system.common.base.BaseController;
import org.analysis.system.common.domain.AjaxResult;
import org.analysis.system.common.domain.TableSplitResult;
import org.analysis.system.common.domain.Tablepar;
import org.analysis.system.common.log.Log;
import org.analysis.system.common.support.Convert;
import org.analysis.system.model.custom.TitleVo;
import org.analysis.system.util.StringUtils;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;


/**
 * <p>
 * 服务版通知信息 前端控制器
 * </p>
 *
 * @author Feliz
 * @since 2020-04-01 20:15:51
 */
@Controller
@Api(tags = {"服务版通知信息"})
@RequestMapping("/ppp/ServerNoticeController")
public class ServerNoticeController extends BaseController{

    private static Logger logger = LoggerFactory.getLogger(ServerNoticeController.class);

    //跳转页面参数
    private String prefix = "projects/ppp/serverNotice";

	@Autowired
	private ServerNoticeService serverNoticeService;
	@Autowired
    private ServerUserService serverUserService;

	//跳转服务版通知信息页面
    @GetMapping("/view")
    @RequiresPermissions("ppp:serverNotice:view")
    public String view(Model model) {
        String str="服务版通知信息";
        setTitle(model, new TitleVo(str+"列表", str+"管理", false, "欢迎进入"+str+"页面", false, false));
        return prefix + "/list";
    }

    @Log(title = "服务版通知信息列表查询", action = "111")
    @ApiOperation(value = "获取服务版通知信息列表", notes = "获取服务版通知信息列表")
    @PostMapping("/list")
    @RequiresPermissions("ppp:serverNotice:list")
    @ResponseBody
    public TableSplitResult<ServerNoticeVO> list(Tablepar tablepar, String searchText) {

        QueryWrapper<ServerNotice> queryWrapper = new QueryWrapper<>();
        if (StringUtils.isNotEmpty(searchText)) {
            queryWrapper.and(wrapper -> wrapper
                    .like("title", searchText).or()
            );
        }

        PageHelper.startPage(tablepar.getPageNum(), tablepar.getPageSize());
        List<ServerNotice> serverNotices = serverNoticeService.list(queryWrapper);
        PageInfo<ServerNotice> pageInfo = new PageInfo<ServerNotice>(serverNotices);

        List<ServerNoticeVO> list = new ArrayList<>();
        for (ServerNotice sn : serverNotices) {
            ServerNoticeVO serverNoticeVO = new ServerNoticeVO();
            try {
                BeanUtils.copyProperties(serverNoticeVO, sn);
            } catch (Exception e) {
                logger.error(e.getMessage());
            }

            List<Integer> targetUserId = Convert.toListIntArray(sn.getTargetUser());
            if (targetUserId.size() > 0) {
                List<ServerUser> serverUsers = (List<ServerUser>) serverUserService.listByIds(targetUserId);

                List<String> targetUserName = new ArrayList<>();
                for (ServerUser su: serverUsers) {
                    targetUserName.add(su.getName());
                }

                serverNoticeVO.setTargetUserName(String.join(",", targetUserName));
            }

            list.add(serverNoticeVO);
        }

        return new TableSplitResult<>(pageInfo.getPageNum(), pageInfo.getTotal(), list);
    }

    @ApiOperation(value = "获取全部服务版通知信息信息", notes = "获取全部服务版通知信息信息")
    @PostMapping("/getAllServerNotice")
    @ResponseBody
    public AjaxResult<TableSplitResult<ServerNotice>> getAllServerNotice() {
        try {
            List<ServerNotice> list = serverNoticeService.list();
            return AjaxResult.successDataList(list);
        } catch (Exception e) {
            logger.error(e.toString());
            return AjaxResult.error(e.getMessage());
        }
    }

    //跳转服务版通知信息新增页面
    @GetMapping("/add")
    public String add() {
        return prefix + "/add";
    }

    @Log(title = "服务版通知信息新增", action = "111")
    @ApiOperation(value = "添加服务版通知信息", notes = "添加服务版通知信息")
    @PostMapping("add")
    @RequiresPermissions("ppp:serverNotice:add")
    @ResponseBody
    public AjaxResult add(ServerNotice serverNotice) {
        serverNotice.setCreateTime(LocalDateTime.now());
        boolean save = serverNoticeService.save(serverNotice);
        return save ? success() : error();
    }

    @Log(title = "服务版通知信息删除", action = "111")
    @ApiOperation(value = "删除服务版通知信息", notes = "根据id删除服务版通知信息（可批量）")
    @PostMapping("/remove")
    @RequiresPermissions("ppp:serverNotice:remove")
    @ResponseBody
    public AjaxResult remove(String ids) {
        List<Integer> idList= Convert.toListIntArray(ids);
        boolean delete = serverNoticeService.removeByIds(idList);
        return delete ? success() : error();
    }

    //跳转服务版通知信息修改页面
    @GetMapping("/edit/{id}")
    public String edit(@PathVariable("id") Integer id, ModelMap mmap) {
        mmap.put("serverNotice", serverNoticeService.getById(id));
        return prefix + "/edit";
    }

    @Log(title = "服务版通知信息修改", action = "111")
    @ApiOperation(value = "修改服务版通知信息", notes = "修改服务版通知信息")
    @PostMapping("/edit")
    @RequiresPermissions("ppp:serverNotice:edit")
    @ResponseBody
    public AjaxResult editSave(ServerNotice serverNotice) {
        serverNotice.setUpdateTime(LocalDateTime.now());
        boolean edit = serverNoticeService.updateById(serverNotice);
        return edit ? success() : error();
    }

}
