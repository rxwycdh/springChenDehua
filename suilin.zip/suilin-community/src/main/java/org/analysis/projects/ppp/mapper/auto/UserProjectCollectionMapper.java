package org.analysis.projects.ppp.mapper.auto;

import org.analysis.projects.ppp.model.auto.UserProjectCollection;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 用户收藏信息 Mapper 接口
 * </p>
 *
 * @author Feliz
 * @since 2020-04-09
 */
public interface UserProjectCollectionMapper extends BaseMapper<UserProjectCollection> {

}
