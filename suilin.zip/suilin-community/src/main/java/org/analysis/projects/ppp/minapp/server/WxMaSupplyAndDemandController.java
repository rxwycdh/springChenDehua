package org.analysis.projects.ppp.minapp.server;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.analysis.projects.ppp.model.auto.ServerDemand;
import org.analysis.projects.ppp.model.auto.ServerSupply;
import org.analysis.projects.ppp.model.auto.ServiceType;
import org.analysis.projects.ppp.model.auto.ServiceTypeIF;
import org.analysis.projects.ppp.service.auto.ServerDemandService;
import org.analysis.projects.ppp.service.auto.ServerSupplyService;
import org.analysis.projects.ppp.service.auto.ServiceTypeService;
import org.analysis.system.common.base.BaseController;
import org.analysis.system.common.domain.AjaxResult;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@RestController
@Api(tags = {"微信小程序服务版-供需信息接口"})
@RequestMapping("/wx/pppserver/minapp/sad")
public class WxMaSupplyAndDemandController extends BaseController {

    private static Logger logger = LoggerFactory.getLogger(WxMaSupplyAndDemandController.class);

    @Autowired
    private ServiceTypeService serviceTypeService;
    @Autowired
    private ServerDemandService serverDemandService;
    @Autowired
    private ServerSupplyService serverSupplyService;

    @ApiOperation(value = "获取服务分类信息", notes = "获取服务分类信息")
    @GetMapping("/getServiceType")
    public AjaxResult<List<ServiceTypeIF>> getAllServiceType() {
        try {
            QueryWrapper<ServiceType> queryWrapper = new QueryWrapper<>();
            queryWrapper.orderByAsc("sort=0, sort");
            List<ServiceType> list = serviceTypeService.list(queryWrapper);

            List<ServiceTypeIF> list1 = new ArrayList<>();
            List<ServiceTypeIF> list2 = new ArrayList<>();
            List<ServiceTypeIF> list3 = new ArrayList<>();

            //先拆分
            for (ServiceType serviceType : list) {
                ServiceTypeIF serviceTypeIF = new ServiceTypeIF();
                BeanUtils.copyProperties(serviceTypeIF, serviceType);
                serviceTypeIF.setChildren(new ArrayList<>());
                if (serviceType.getType() == 0) {
                    list1.add(serviceTypeIF);
                }else if (serviceType.getType() == 1) {
                    list2.add(serviceTypeIF);
                }else if (serviceType.getType() == 2) {
                    list3.add(serviceTypeIF);
                }
            }

            //后把三级赋值到二级子元素,目前只取2级分类所以注释了
//            for (ServiceTypeIF serviceTypeIF: list2) {
//                for (ServiceTypeIF stif : list3) {
//                    if (serviceTypeIF.getId().equals(stif.getPid())) {
//                        serviceTypeIF.getChildren().add(stif);
//                    }
//                }
//            }

            //最后把二级赋值到一级子元素
            for (ServiceTypeIF serviceTypeIF : list1) {
                for (ServiceTypeIF stif : list2) {
                    if (serviceTypeIF.getId().equals(stif.getPid())) {
                        serviceTypeIF.getChildren().add(stif);
                    }
                }
            }

            return AjaxResult.successData(list1);
        } catch (Exception e) {
            logger.error(ExceptionUtils.getFullStackTrace(e));
            return AjaxResult.error();
        }
    }

    @ApiOperation(value = "提交需求信息", notes = "提交需求信息")
    @PostMapping("/addDemand")
    public AjaxResult addDemand(ServerDemand serverDemand) {
        serverDemand.setCreateTime(LocalDateTime.now());
        boolean save = serverDemandService.save(serverDemand);
        return save ? success() : error();
    }

    @ApiOperation(value = "提交服务商信息", notes = "提交服务商信息")
    @PostMapping("/addSupply")
    public AjaxResult addSupply(ServerSupply serverSupply) {
        serverSupply.setCreateTime(LocalDateTime.now());
        boolean save = serverSupplyService.save(serverSupply);
        return save ? success() : error();
    }


}
