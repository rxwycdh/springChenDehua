package org.analysis.projects.jfy.mapper.auto;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.analysis.projects.jfy.model.auto.PropertyInformation;
import org.apache.ibatis.annotations.CacheNamespace;

/**
 * <p>
 * 业主决策物业信息表 Mapper 接口
 * </p>
 *
 * @author Feliz
 * @since 2019-07-03
 */
@DS("db_jfy")
@CacheNamespace(flushInterval = 3600000, size = 4096)
public interface PropertyInformationMapper extends BaseMapper<PropertyInformation> {

}
