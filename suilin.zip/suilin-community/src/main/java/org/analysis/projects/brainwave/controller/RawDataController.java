package org.analysis.projects.brainwave.controller;


import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.analysis.projects.brainwave.service.custom.BrainWaveDataService;
import org.analysis.system.common.base.BaseController;
import org.analysis.system.common.domain.AjaxResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * <p>
 * 原始脑波数据表 前端控制器
 * </p>
 *
 * @author Feliz
 * @since 2019-05-17
 */
@Controller
@Api(tags={"脑波原始数据"})
@RequestMapping("/brainwave/raw-data")
public class RawDataController extends BaseController {

    private static Logger logger = LoggerFactory.getLogger(RawDataController.class);

    @Autowired
    private BrainWaveDataService brainWaveDataService;

    @ApiOperation(value = "分割原始数据", notes = "分割原始脑波数据")
    @PostMapping("split")
    @ResponseBody
    public AjaxResult spliRawData() {
        try {
            brainWaveDataService.splitBrainWave();
            return success("分割原始数据成功");
        } catch (Exception e) {
            logger.error(e.getMessage());
            return error(e.getMessage());
        }
    }

}

