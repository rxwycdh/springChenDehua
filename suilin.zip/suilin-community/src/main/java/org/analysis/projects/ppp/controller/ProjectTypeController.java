package org.analysis.projects.ppp.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.analysis.projects.ppp.model.auto.ProjectType;
import org.analysis.projects.ppp.service.auto.ProjectTypeService;
import org.analysis.system.common.base.BaseController;
import org.analysis.system.common.domain.AjaxResult;
import org.analysis.system.common.domain.TableSplitResult;
import org.analysis.system.common.domain.Tablepar;
import org.analysis.system.common.log.Log;
import org.analysis.system.common.support.Convert;
import org.analysis.system.model.custom.TitleVo;
import org.analysis.system.util.StringUtils;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;


/**
 * <p>
 * 项目类型信息 前端控制器
 * </p>
 *
 * @author Feliz
 * @since 2020-04-02 19:05:09
 */
@Controller
@Api(tags = {"项目类型信息"})
@RequestMapping("/ppp/ProjectTypeController")
public class ProjectTypeController extends BaseController{

    private static Logger logger = LoggerFactory.getLogger(ProjectTypeController.class);

    //跳转页面参数
    private String prefix = "projects/ppp/projectType";

	@Autowired
	private ProjectTypeService projectTypeService;

	//跳转项目类型信息页面
    @GetMapping("/view")
    @RequiresPermissions("ppp:projectType:view")
    public String view(Model model) {
        String str="项目类型信息";
        setTitle(model, new TitleVo(str+"列表", str+"管理", false, "欢迎进入"+str+"页面", false, false));
        return prefix + "/list";
    }

    @Log(title = "项目类型信息列表查询", action = "111")
    @ApiOperation(value = "获取项目类型信息列表", notes = "获取项目类型信息列表")
    @PostMapping("/list")
    @RequiresPermissions("ppp:projectType:list")
    @ResponseBody
    public TableSplitResult<ProjectType> list(Tablepar tablepar, String searchText) {

        QueryWrapper<ProjectType> queryWrapper = new QueryWrapper<>();
        if (StringUtils.isNotEmpty(searchText)) {
            queryWrapper.and(wrapper -> wrapper
                    .like("id", searchText).or()
                    .like("name", searchText).or()
            );
        }

        queryWrapper.orderByAsc("sort=0, sort");
        PageHelper.startPage(tablepar.getPageNum(), tablepar.getPageSize());
        List<ProjectType> list = projectTypeService.list(queryWrapper);
        PageInfo<ProjectType> pageInfo = new PageInfo<ProjectType>(list);

        return new TableSplitResult<>(pageInfo.getPageNum(), pageInfo.getTotal(), pageInfo.getList());
    }

    @ApiOperation(value = "获取全部项目类型信息信息", notes = "获取全部项目类型信息信息")
    @PostMapping("/getAllProjectType")
    @ResponseBody
    public AjaxResult<TableSplitResult<ProjectType>> getAllProjectType() {
        try {
            QueryWrapper<ProjectType> queryWrapper = new QueryWrapper<>();
            queryWrapper.orderByAsc("sort");
            List<ProjectType> list = projectTypeService.list(queryWrapper);
            return AjaxResult.successDataList(list);
        } catch (Exception e) {
            logger.error(e.toString());
            return AjaxResult.error(e.getMessage());
        }
    }

    //跳转项目类型信息新增页面
    @GetMapping("/add")
    public String add() {
        return prefix + "/add";
    }

    @Log(title = "项目类型信息新增", action = "111")
    @ApiOperation(value = "添加项目类型信息", notes = "添加项目类型信息")
    @PostMapping("add")
    @RequiresPermissions("ppp:projectType:add")
    @ResponseBody
    public AjaxResult add(ProjectType projectType) {
        projectType.setCreateTime(LocalDateTime.now());
        boolean save = projectTypeService.save(projectType);
        return save ? success() : error();
    }

    @Log(title = "项目类型信息删除", action = "111")
    @ApiOperation(value = "删除项目类型信息", notes = "根据id删除项目类型信息（可批量）")
    @PostMapping("/remove")
    @RequiresPermissions("ppp:projectType:remove")
    @ResponseBody
    public AjaxResult remove(String ids) {
        List<Integer> idList= Convert.toListIntArray(ids);
        boolean delete = projectTypeService.removeByIds(idList);
        return delete ? success() : error();
    }

    @ApiOperation(value = "检查项目类型信息是否存在", notes = "返回: 1-存在; 0-不存在")
    @PostMapping("/checkUnique")
    @ResponseBody
    public Integer checkUnique(ProjectType projectType) {
        QueryWrapper<ProjectType> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("name", projectType.getName());
        List<ProjectType> list = projectTypeService.list(queryWrapper);
        if (list.size() > 0) {
            return 1;
        } else {
            return 0;
        }
    }

    //跳转项目类型信息修改页面
    @GetMapping("/edit/{id}")
    public String edit(@PathVariable("id") Integer id, ModelMap mmap) {
        mmap.put("projectType", projectTypeService.getById(id));
        return prefix + "/edit";
    }

    @Log(title = "项目类型信息修改", action = "111")
    @ApiOperation(value = "修改项目类型信息", notes = "修改项目类型信息")
    @PostMapping("/edit")
    @RequiresPermissions("ppp:projectType:edit")
    @ResponseBody
    public AjaxResult editSave(ProjectType projectType) {
        projectType.setUpdateTime(LocalDateTime.now());
        boolean edit = projectTypeService.updateById(projectType);
        return edit ? success() : error();
    }
	
}
