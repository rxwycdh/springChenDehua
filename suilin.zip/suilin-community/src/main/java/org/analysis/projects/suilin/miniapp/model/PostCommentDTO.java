package org.analysis.projects.suilin.miniapp.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.analysis.projects.suilin.model.auto.PostComment;

/**
 * @author ChenDehua  597701764@qq.com
 * @date 2020/8/19 13:31
 */
@ApiModel("小程序评论参数")
@Getter
@Setter
@ToString
public class PostCommentDTO extends PostComment {

    @ApiModelProperty("用户是否已点赞")
    private Boolean isLike;
}
