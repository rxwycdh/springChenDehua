package org.analysis.projects.oasystem.service.auto;

import com.baomidou.mybatisplus.extension.service.IService;
import org.analysis.projects.oasystem.model.auto.ClaimDetail;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author Feliz
 * @since 2019-06-21
 */
public interface ClaimDetailService extends IService<ClaimDetail> {

}
