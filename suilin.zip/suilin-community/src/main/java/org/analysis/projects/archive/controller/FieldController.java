package org.analysis.projects.archive.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.analysis.projects.archive.model.auto.Field;
import org.analysis.projects.archive.model.auto.UserField;
import org.analysis.projects.archive.model.custom.FieldVO;
import org.analysis.projects.archive.service.auto.FieldService;
import org.analysis.projects.archive.service.auto.UserFieldService;
import org.analysis.system.common.base.BaseController;
import org.analysis.system.common.domain.AjaxResult;
import org.analysis.system.common.domain.TableSplitResult;
import org.analysis.system.common.domain.Tablepar;
import org.analysis.system.common.log.Log;
import org.analysis.system.common.support.Convert;
import org.analysis.system.model.custom.TitleVo;
import org.analysis.system.util.BeanUtils;
import org.analysis.system.util.StringUtils;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * <p>
 * 信息字段 前端控制器
 * </p>
 *
 * @author Feliz
 * @since 2019-09-10 16:55:35
 */
@Controller
@Api(tags = {"信息字段"})
@RequestMapping("/archive/FieldController")
public class FieldController extends BaseController {

    private static Logger logger = LoggerFactory.getLogger(FieldController.class);

    //跳转页面参数
    private String prefix = "projects/archive/field";

    @Autowired
    private FieldService fieldService;
    @Autowired
    private UserFieldService userFieldService;


    @ApiOperation(value = "获取全部字段信息", notes = "获取全部字段信息")
    @PostMapping("/getAllField")
    @ResponseBody
    public AjaxResult<TableSplitResult<Field>> getAllField() {
        try {
            List<Field> list = fieldService.list();
            return AjaxResult.successDataList(list);
        } catch (Exception e) {
            logger.error(e.toString());
            return AjaxResult.error(e.getMessage());
        }
    }

    @ApiOperation(value = "跳转信息字段页面", notes = "跳转信息字段页面", hidden = true)
    @GetMapping("/view")
    @RequiresPermissions("archive:field:view")
    public String view(Model model) {
        String str = "信息字段";
        setTitle(model, new TitleVo(str + "列表", str + "管理", false, "欢迎进入" + str + "页面", false, false));
        return prefix + "/list";
    }

    @Log(title = "信息字段列表查询", action = "111")
    @ApiOperation(value = "获取信息字段列表", notes = "获取信息字段列表")
    @PostMapping("/list")
    @RequiresPermissions("archive:field:list")
    @ResponseBody
    public TableSplitResult<FieldVO> list(Tablepar tablepar, String searchText) {

        QueryWrapper<Field> queryWrapper = new QueryWrapper<>();
        if (StringUtils.isNotEmpty(searchText)) {
            queryWrapper.and(wrapper -> wrapper
                    .like("id", searchText).or()
                    .like("field_key", searchText).or()
                    .like("field_name", searchText).or()
                    .like("field_type", searchText).or()
                    .like("option_setting", searchText).or()
                    .like("default_value", searchText).or()
                    .like("required", searchText).or()
            );
        }

        PageHelper.startPage(tablepar.getPageNum(), tablepar.getPageSize());
        List<Field> fieldList = fieldService.list(queryWrapper);
        PageInfo<Field> pageInfo = new PageInfo<>(fieldList);

        List<FieldVO> list = new ArrayList<>();
        for (Field f : fieldList) {
            FieldVO fieldVO = new FieldVO();
            BeanUtils.copyBeanProp(fieldVO, f);

            QueryWrapper<UserField> fieldQueryWrapper = new QueryWrapper<>();
            fieldQueryWrapper.eq("field_id", f.getId());
            List<UserField> userFields = userFieldService.list(fieldQueryWrapper);
            if (userFields.size() > 0) {
                fieldVO.setUsed(1);
            }else {
                fieldVO.setUsed(0);
            }
            list.add(fieldVO);
        }

        return new TableSplitResult<>(pageInfo.getPageNum(), pageInfo.getTotal(), list);
    }

    @ApiOperation(value = "根据id获取信息字段列表", notes = "根据id批量获取信息字段列表")
    @PostMapping("/listByIds")
    @ResponseBody
    public TableSplitResult<Field> listByIds(String ids) {

        List<Field> list = fieldService.listByIds(ids);

        PageInfo<Field> pageInfo = new PageInfo<Field>(list);

        return new TableSplitResult<>(pageInfo.getPageNum(), pageInfo.getTotal(), pageInfo.getList());
    }

    @ApiOperation(value = "跳转新增信息字段页面", notes = "跳转新增信息字段页面", hidden = true)
    @GetMapping("/add")
    public String add() {
        return prefix + "/add";
    }

    @Log(title = "信息字段新增", action = "111")
    @ApiOperation(value = "添加信息字段", notes = "添加信息字段")
    @PostMapping("add")
    @RequiresPermissions("archive:field:add")
    @ResponseBody
    public AjaxResult add(Field field) {
        field.setCreateTime(LocalDateTime.now());
        boolean save = fieldService.save(field);
        if (save) {
            return AjaxResult.successData(field.getId());
        } else {
            return error();
        }
    }

    @Log(title = "信息字段删除", action = "111")
    @ApiOperation(value = "删除信息字段", notes = "根据id删除信息字段（可批量）")
    @PostMapping("/remove")
    @RequiresPermissions("archive:field:remove")
    @ResponseBody
    public AjaxResult remove(String ids) {
        List<String> idList = Convert.toListStrArray(ids);
        boolean save = fieldService.removeByIds(idList);
        if (save) {
            return success();
        } else {
            return error();
        }
    }

    @ApiOperation(value = "检查信息字段名称是否存在", notes = "返回: 1-存在; 0-不存在")
    @PostMapping("/checkFieldNameUnique")
    @ResponseBody
    public Integer checkFieldNameUnique(Field field) {
        QueryWrapper<Field> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("field_name", field.getFieldName());
        List<Field> list = fieldService.list(queryWrapper);
        return (list.size() > 0) ? 1 : 0;
    }

    @ApiOperation(value = "检查信息字段标识是否存在", notes = "返回: 1-存在; 0-不存在")
    @PostMapping("/checkFieldKeyUnique")
    @ResponseBody
    public Integer checkFieldKeyUnique(Field field) {
        QueryWrapper<Field> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("field_key", field.getFieldKey());
        List<Field> list = fieldService.list(queryWrapper);
        return (list.size() > 0) ? 1 : 0;
    }

    @ApiOperation(value = "跳转信息字段修改页面", notes = "跳转信息字段修改页面", hidden = true)
    @GetMapping("/edit/{id}")
    public String edit(@PathVariable("id") String id, ModelMap mmap) {
        mmap.put("field", fieldService.getById(id));
        return prefix + "/edit";
    }

    @Log(title = "信息字段修改", action = "111")
    @ApiOperation(value = "修改信息字段", notes = "修改信息字段")
    @PostMapping("/edit")
    @RequiresPermissions("archive:field:edit")
    @ResponseBody
    public AjaxResult editSave(Field field) {
        field.setUpdateTime(LocalDateTime.now());
        boolean b = fieldService.updateById(field);
        return b ? success() : error();
    }


}
