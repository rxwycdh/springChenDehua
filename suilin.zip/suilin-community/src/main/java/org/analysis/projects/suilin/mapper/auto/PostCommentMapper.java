package org.analysis.projects.suilin.mapper.auto;

import org.analysis.projects.suilin.model.auto.PostComment;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 帖子评论表 Mapper 接口
 * </p>
 *
 * @author Feliz
 * @since 2020-08-19
 */
public interface PostCommentMapper extends BaseMapper<PostComment> {

}
