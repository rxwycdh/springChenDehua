package org.analysis.projects.suilin.miniapp.param;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;

/**
 * @author ChenDehua  597701764@qq.com
 * @date 2020/8/19 16:06
 */
@Data
@ApiModel("帖子点赞参数")
public class PostLikeParam {

    @ApiModelProperty(value = "帖子id/评论id/评论回复id")
    @NotNull
    private Integer postInfoId;

    @ApiModelProperty(value = "用户号")
    @NotNull
    private Integer userId;

    public Integer getPostInfoId() {
        return postInfoId;
    }

    public void setPostInfoId(Integer postInfoId) {
        this.postInfoId = postInfoId;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }
}
