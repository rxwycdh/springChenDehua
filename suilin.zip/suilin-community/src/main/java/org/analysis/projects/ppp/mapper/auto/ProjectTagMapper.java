package org.analysis.projects.ppp.mapper.auto;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.analysis.projects.ppp.model.auto.ProjectTag;
import org.apache.ibatis.annotations.CacheNamespace;

/**
 * <p>
 * 项目标签中间 Mapper 接口
 * </p>
 *
 * @author Feliz
 * @since 2020-04-03
 */
@CacheNamespace(flushInterval = 3600000, size = 4096)
public interface ProjectTagMapper extends BaseMapper<ProjectTag> {

}
