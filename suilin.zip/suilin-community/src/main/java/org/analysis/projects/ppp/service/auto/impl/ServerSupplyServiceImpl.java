package org.analysis.projects.ppp.service.auto.impl;

import org.analysis.projects.ppp.model.auto.ServerSupply;
import org.analysis.projects.ppp.mapper.auto.ServerSupplyMapper;
import org.analysis.projects.ppp.service.auto.ServerSupplyService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 服务版服务商信息 服务实现类
 * </p>
 *
 * @author Feliz
 * @since 2020-04-23
 */
@Service
public class ServerSupplyServiceImpl extends ServiceImpl<ServerSupplyMapper, ServerSupply> implements ServerSupplyService {

}
