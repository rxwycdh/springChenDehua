package org.analysis.projects.ppp.model.auto;

import com.baomidou.mybatisplus.annotation.*;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * <p>
 * 项目信息
 * </p>
 *
 * @author Feliz
 * @since 2020-04-03
 */
@TableName("ppp_project")
@ApiModel(value="Project对象", description="项目信息")
public class Project implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "项目标题")
    @TableField("title")
    private String title;

    @ApiModelProperty(value = "项目状态；0：待审核；1：已通过；2：未通过；3：下架中；4：已取消")
    @TableField("state")
    private Integer state;

    @ApiModelProperty(value = "项目类型id")
    @TableField("type_id")
    private Integer typeId;

    @ApiModelProperty(value = "发布单位")
    @TableField("publish_unit")
    private String publishUnit;

    @ApiModelProperty(value = "负责人id（server_user）")
    @TableField("leader_id")
    private Integer leaderId;

    @ApiModelProperty(value = "负责人姓名")
    @TableField("leader_name")
    private String leaderName;

    @ApiModelProperty(value = "负责人手机")
    @TableField("phone_number")
    private String phoneNumber;

    @ApiModelProperty(value = "负责人微信")
    @TableField("leader_wechat")
    private String leaderWechat;

    @ApiModelProperty(value = "项目内容")
    @TableField("project_content")
    private String projectContent;

    @ApiModelProperty(value = "项目收获")
    @TableField("project_harvest")
    private String projectHarvest;

    @ApiModelProperty(value = "项目地址")
    @TableField("location")
    private String location;

    @ApiModelProperty(value = "项目详细地址")
    @TableField("detail_location")
    private String detailLocation;

    @ApiModelProperty(value = "位置经度")
    @TableField("longitude")
    private BigDecimal longitude;

    @ApiModelProperty(value = "位置纬度")
    @TableField("latitude")
    private BigDecimal latitude;

    @ApiModelProperty(value = "项目权重值")
    @TableField("weight")
    private Integer weight;

    @ApiModelProperty(value = "审核人id（sys_user）")
    @TableField("auditor_id")
    private Integer auditorId;

    @ApiModelProperty(value = "审核意见")
    @TableField("audit_opinion")
    private String auditOpinion;

    @ApiModelProperty(value = "逻辑删除；0：未删除；1：已删除")
    @TableField("deleted")
    @TableLogic
    private Integer deleted;

    @ApiModelProperty(value = "创建时间")
    @TableField("create_time")
    private LocalDateTime createTime;

    @ApiModelProperty(value = "修改时间")
    @TableField("update_time")
    private LocalDateTime updateTime;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Integer getState() {
        return state;
    }

    public void setState(Integer state) {
        this.state = state;
    }

    public Integer getTypeId() {
        return typeId;
    }

    public void setTypeId(Integer typeId) {
        this.typeId = typeId;
    }

    public String getPublishUnit() {
        return publishUnit;
    }

    public void setPublishUnit(String publishUnit) {
        this.publishUnit = publishUnit;
    }

    public Integer getLeaderId() {
        return leaderId;
    }

    public void setLeaderId(Integer leaderId) {
        this.leaderId = leaderId;
    }

    public String getLeaderName() {
        return leaderName;
    }

    public void setLeaderName(String leaderName) {
        this.leaderName = leaderName;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getLeaderWechat() {
        return leaderWechat;
    }

    public void setLeaderWechat(String leaderWechat) {
        this.leaderWechat = leaderWechat;
    }

    public String getProjectContent() {
        return projectContent;
    }

    public void setProjectContent(String projectContent) {
        this.projectContent = projectContent;
    }

    public String getProjectHarvest() {
        return projectHarvest;
    }

    public void setProjectHarvest(String projectHarvest) {
        this.projectHarvest = projectHarvest;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getDetailLocation() {
        return detailLocation;
    }

    public void setDetailLocation(String detailLocation) {
        this.detailLocation = detailLocation;
    }

    public BigDecimal getLongitude() {
        return longitude;
    }

    public void setLongitude(BigDecimal longitude) {
        this.longitude = longitude;
    }

    public BigDecimal getLatitude() {
        return latitude;
    }

    public void setLatitude(BigDecimal latitude) {
        this.latitude = latitude;
    }

    public Integer getWeight() {
        return weight;
    }

    public void setWeight(Integer weight) {
        this.weight = weight;
    }

    public Integer getAuditorId() {
        return auditorId;
    }

    public void setAuditorId(Integer auditorId) {
        this.auditorId = auditorId;
    }

    public String getAuditOpinion() {
        return auditOpinion;
    }

    public void setAuditOpinion(String auditOpinion) {
        this.auditOpinion = auditOpinion;
    }

    public Integer getDeleted() {
        return deleted;
    }

    public void setDeleted(Integer deleted) {
        this.deleted = deleted;
    }

    public LocalDateTime getCreateTime() {
        return createTime;
    }

    public void setCreateTime(LocalDateTime createTime) {
        this.createTime = createTime;
    }

    public LocalDateTime getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(LocalDateTime updateTime) {
        this.updateTime = updateTime;
    }

    @Override
    public String toString() {
        return "Project{" +
                "id=" + id +
                ", title='" + title + '\'' +
                ", state=" + state +
                ", typeId=" + typeId +
                ", publishUnit='" + publishUnit + '\'' +
                ", leaderId=" + leaderId +
                ", leaderName='" + leaderName + '\'' +
                ", phoneNumber='" + phoneNumber + '\'' +
                ", leaderWechat='" + leaderWechat + '\'' +
                ", projectContent='" + projectContent + '\'' +
                ", projectHarvest='" + projectHarvest + '\'' +
                ", location='" + location + '\'' +
                ", detailLocation='" + detailLocation + '\'' +
                ", longitude=" + longitude +
                ", latitude=" + latitude +
                ", weight=" + weight +
                ", auditorId=" + auditorId +
                ", auditOpinion='" + auditOpinion + '\'' +
                ", deleted=" + deleted +
                ", createTime=" + createTime +
                ", updateTime=" + updateTime +
                '}';
    }
}
