package org.analysis.projects.brainwave.service.custom;


import org.analysis.projects.brainwave.model.custom.DataQueryCondition;

import java.util.ArrayList;

public interface BrainWaveDataService {

    void splitBrainWave();

    ArrayList<String> splitDataFile(Integer dataId);

    void saveBatchRawData(ArrayList<String> datas, DataQueryCondition dataQueryCondition);
}
