package org.analysis.projects.ppp.service.auto.impl;

import org.analysis.projects.ppp.model.auto.UserProjectCollection;
import org.analysis.projects.ppp.mapper.auto.UserProjectCollectionMapper;
import org.analysis.projects.ppp.service.auto.UserProjectCollectionService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 用户收藏信息 服务实现类
 * </p>
 *
 * @author Feliz
 * @since 2020-04-09
 */
@Service
public class UserProjectCollectionServiceImpl extends ServiceImpl<UserProjectCollectionMapper, UserProjectCollection> implements UserProjectCollectionService {

}
