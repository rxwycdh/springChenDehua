package org.analysis.projects.ppp.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.analysis.projects.ppp.model.auto.RotationChart;
import org.analysis.projects.ppp.service.auto.RotationChartService;
import org.analysis.system.common.base.BaseController;
import org.analysis.system.common.domain.AjaxResult;
import org.analysis.system.common.domain.TableSplitResult;
import org.analysis.system.common.domain.Tablepar;
import org.analysis.system.common.log.Log;
import org.analysis.system.common.support.Convert;
import org.analysis.system.model.auto.TsysFile;
import org.analysis.system.model.custom.TitleVo;
import org.analysis.system.util.StringUtils;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;


/**
 * <p>
 * 轮播信息表 前端控制器
 * </p>
 *
 * @author Feliz
 * @since 2020-03-29 17:31:58
 */
@Controller
@Api(tags = {"轮播信息表"})
@RequestMapping("/ppp/RotationChartController")
public class RotationChartController extends BaseController{

    private static Logger logger = LoggerFactory.getLogger(RotationChartController.class);

    //跳转页面参数
    private String prefix = "projects/ppp/rotationChart";

	@Autowired
	private RotationChartService rotationChartService;

	//跳转轮播信息表页面
    @GetMapping("/view")
    @RequiresPermissions("ppp:rotationChart:view")
    public String view(Model model) {
        String str="轮播信息表";
        setTitle(model, new TitleVo(str+"列表", str+"管理", false, "欢迎进入"+str+"页面", false, false));
        return prefix + "/list";
    }

    @Log(title = "轮播信息表列表查询", action = "111")
    @ApiOperation(value = "获取轮播信息表列表", notes = "获取轮播信息表列表")
    @PostMapping("/list")
    @RequiresPermissions("ppp:rotationChart:list")
    @ResponseBody
    public TableSplitResult<RotationChart> list(Tablepar tablepar, String searchText) {

        QueryWrapper<RotationChart> queryWrapper = new QueryWrapper<>();
        if (StringUtils.isNotEmpty(searchText)) {
            queryWrapper.and(wrapper -> wrapper
                    .like("title", searchText).or()
                    .like("description", searchText).or()
            );
        }

        queryWrapper.orderByAsc("sort=0, sort");
        PageHelper.startPage(tablepar.getPageNum(), tablepar.getPageSize());
        List<RotationChart> list = rotationChartService.list(queryWrapper);
        PageInfo<RotationChart> pageInfo = new PageInfo<RotationChart>(list);

        return new TableSplitResult<>(pageInfo.getPageNum(), pageInfo.getTotal(), pageInfo.getList());
    }

    @ApiOperation(value = "获取全部轮播信息表信息", notes = "获取全部轮播信息表信息")
    @PostMapping("/getAllRotationChart")
    @ResponseBody
    public AjaxResult<TableSplitResult<RotationChart>> getAllRotationChart() {
        try {
            QueryWrapper<RotationChart> queryWrapper = new QueryWrapper<>();
            queryWrapper.orderByAsc("sort=0, sort");
            List<RotationChart> list = rotationChartService.list(queryWrapper);
            return AjaxResult.successDataList(list);
        } catch (Exception e) {
            logger.error(e.toString());
            return AjaxResult.error(e.getMessage());
        }
    }

    //跳转轮播信息表新增页面
    @GetMapping("/add")
    public String add() {
        return prefix + "/add";
    }

    @Log(title = "轮播信息表新增", action = "111")
    @ApiOperation(value = "添加轮播信息表", notes = "添加轮播信息表")
    @PostMapping("add")
    @RequiresPermissions("ppp:rotationChart:add")
    @Transactional
    @ResponseBody
    public AjaxResult add(RotationChart rotationChart, Integer dataId) {

        //添加文件
        TsysFile record = new TsysFile();
        record.setFileName("rotationChart-" + rotationChart.getTitle());
        int fileId = sysFileService.insertSelective(record, dataId);
        rotationChart.setImageId(fileId);

        rotationChart.setCreateTime(LocalDateTime.now());
        boolean save = rotationChartService.save(rotationChart);
        if (save) {
            return success();
        } else {
            return error();
        }
    }

    @Log(title = "轮播信息表删除", action = "111")
    @ApiOperation(value = "删除轮播信息表", notes = "根据id删除轮播信息表（可批量）")
    @PostMapping("/remove")
    @RequiresPermissions("ppp:rotationChart:remove")
    @ResponseBody
    public AjaxResult remove(String ids) {
        List<String> idList= Convert.toListStrArray(ids);
        boolean delete = rotationChartService.removeByIds(idList);
        if (delete) {
            return success();
        } else {
            return error();
        }
    }


    //跳转轮播信息表修改页面
    @GetMapping("/edit/{id}")
    public String edit(@PathVariable("id") String id, ModelMap mmap) {
        mmap.put("rotationChart", rotationChartService.getById(id));
        return prefix + "/edit";
    }

    @Log(title = "轮播信息表修改", action = "111")
    @ApiOperation(value = "修改轮播信息表", notes = "修改轮播信息表")
    @PostMapping("/edit")
    @RequiresPermissions("ppp:rotationChart:edit")
    @ResponseBody
    public AjaxResult editSave(RotationChart rotationChart, Integer dataId) {

        //修改文件
        TsysFile record = sysFileService.selectByPrimaryKey(rotationChart.getImageId());
        record.setFileName("rotationChart-" + rotationChart.getTitle());
        sysFileService.updateByPrimaryKey(record, dataId);

        rotationChart.setUpdateTime(LocalDateTime.now());
        boolean b = rotationChartService.updateById(rotationChart);
        return b ? success() : error();
    }


}
