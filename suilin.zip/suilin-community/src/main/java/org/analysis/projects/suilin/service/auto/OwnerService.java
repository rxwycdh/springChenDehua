package org.analysis.projects.suilin.service.auto;

import org.analysis.projects.suilin.model.auto.Owner;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 业主信息 服务类
 * </p>
 *
 * @author Feliz
 * @since 2020-08-04
 */
public interface OwnerService extends IService<Owner> {

}
