package org.analysis.projects.ppp.model.custom;

import com.baomidou.mybatisplus.annotation.*;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

/**
 * <p>
 * 项目详情
 * </p>
 *
 * @author Feliz
 * @since 2020-04-03
 */
@ApiModel(value="ProjectDetailsIF对象", description="项目详情")
public class ProjectDetailsIF implements Serializable {

    private static final long serialVersionUID = 1L;

    private Integer id;

    @ApiModelProperty(value = "项目标题")
    private String title;

    @ApiModelProperty(value = "项目类型")
    private String typeName;

    @ApiModelProperty(value = "发布单位")
    @TableField("publish_unit")
    private String publishUnit;

    @ApiModelProperty(value = "负责人姓名")
    @TableField("leader_name")
    private String leaderName;

    @ApiModelProperty(value = "负责人手机")
    @TableField("phone_number")
    private String phoneNumber;

    @ApiModelProperty(value = "负责人微信")
    @TableField("leader_wechat")
    private String leaderWechat;

    @ApiModelProperty(value = "项目内容")
    @TableField("project_content")
    private String projectContent;

    @ApiModelProperty(value = "项目收获")
    @TableField("project_harvest")
    private String projectHarvest;

    @ApiModelProperty(value = "项目地址")
    @TableField("location")
    private String location;

    @ApiModelProperty(value = "项目详细地址")
    @TableField("detail_location")
    private String detailLocation;

    @ApiModelProperty(value = "位置经度")
    @TableField("longitude")
    private BigDecimal longitude;

    @ApiModelProperty(value = "位置纬度")
    @TableField("latitude")
    private BigDecimal latitude;

    @ApiModelProperty(value = "距离")
    private String distance;

    @ApiModelProperty(value = "标签列表")
    private List tags;

    @ApiModelProperty(value = "是否已收藏")
    private Boolean favored;

    @ApiModelProperty(value = "是否已报名")
    private Boolean enrolled;

    @ApiModelProperty(value = "发布时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime createTime;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getTypeName() {
        return typeName;
    }

    public void setTypeName(String typeName) {
        this.typeName = typeName;
    }

    public String getPublishUnit() {
        return publishUnit;
    }

    public void setPublishUnit(String publishUnit) {
        this.publishUnit = publishUnit;
    }

    public String getLeaderName() {
        return leaderName;
    }

    public void setLeaderName(String leaderName) {
        this.leaderName = leaderName;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getLeaderWechat() {
        return leaderWechat;
    }

    public void setLeaderWechat(String leaderWechat) {
        this.leaderWechat = leaderWechat;
    }

    public String getProjectContent() {
        return projectContent;
    }

    public void setProjectContent(String projectContent) {
        this.projectContent = projectContent;
    }

    public String getProjectHarvest() {
        return projectHarvest;
    }

    public void setProjectHarvest(String projectHarvest) {
        this.projectHarvest = projectHarvest;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getDetailLocation() {
        return detailLocation;
    }

    public void setDetailLocation(String detailLocation) {
        this.detailLocation = detailLocation;
    }

    public BigDecimal getLongitude() {
        return longitude;
    }

    public void setLongitude(BigDecimal longitude) {
        this.longitude = longitude;
    }

    public BigDecimal getLatitude() {
        return latitude;
    }

    public void setLatitude(BigDecimal latitude) {
        this.latitude = latitude;
    }

    public String getDistance() {
        return distance;
    }

    public void setDistance(String distance) {
        this.distance = distance;
    }

    public List getTags() {
        return tags;
    }

    public void setTags(List tags) {
        this.tags = tags;
    }

    public LocalDateTime getCreateTime() {
        return createTime;
    }

    public void setCreateTime(LocalDateTime createTime) {
        this.createTime = createTime;
    }

    public Boolean getFavored() {
        return favored;
    }

    public void setFavored(Boolean favored) {
        this.favored = favored;
    }

    public Boolean getEnrolled() {
        return enrolled;
    }

    public void setEnrolled(Boolean enrolled) {
        this.enrolled = enrolled;
    }

    @Override
    public String toString() {
        return "ProjectDetailsIF{" +
                "id=" + id +
                ", title='" + title + '\'' +
                ", typeName='" + typeName + '\'' +
                ", publishUnit='" + publishUnit + '\'' +
                ", leaderName='" + leaderName + '\'' +
                ", phoneNumber='" + phoneNumber + '\'' +
                ", leaderWechat='" + leaderWechat + '\'' +
                ", projectContent='" + projectContent + '\'' +
                ", projectHarvest='" + projectHarvest + '\'' +
                ", location='" + location + '\'' +
                ", detailLocation='" + detailLocation + '\'' +
                ", longitude=" + longitude +
                ", latitude=" + latitude +
                ", distance='" + distance + '\'' +
                ", tags=" + tags +
                ", favored=" + favored +
                ", enrolled=" + enrolled +
                ", createTime=" + createTime +
                '}';
    }
}
