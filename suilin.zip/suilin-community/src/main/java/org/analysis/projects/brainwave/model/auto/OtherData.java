package org.analysis.projects.brainwave.model.auto;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * <p>
 * 其他脑波数据表
 * </p>
 *
 * @author Feliz
 * @since 2019-06-06
 */
@TableName("brainwave_other_data")
@ApiModel(value="OtherData对象", description="其他脑波数据表")
public class OtherData implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "id", required = true, example = "0", position = 1)
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "穿戴人", example = "0")
    @TableField("user_id")
    private Integer userId;

    @ApiModelProperty(value = "设备id", example = "0")
    @TableField("device_id")
    private Integer deviceId;

    @ApiModelProperty(value = "场景id", example = "0")
    @TableField("scene_id")
    private Integer sceneId;

    @ApiModelProperty(value = "时间戳")
    @TableField("time")
    private LocalDateTime time;

    @ApiModelProperty(value = "信号值", example = "200")
    @TableField("pq")
    private Integer pq;

    @ApiModelProperty(value = "专注度", example = "0")
    @TableField("attention")
    private Integer attention;

    @ApiModelProperty(value = "冥想度", example = "0")
    @TableField("meditation")
    private Integer meditation;

    @ApiModelProperty(value = "创建时间")
    @TableField("create_time")
    private LocalDateTime createTime;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public Integer getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(Integer deviceId) {
        this.deviceId = deviceId;
    }

    public Integer getSceneId() {
        return sceneId;
    }

    public void setSceneId(Integer sceneId) {
        this.sceneId = sceneId;
    }

    public LocalDateTime getTime() {
        return time;
    }

    public void setTime(LocalDateTime time) {
        this.time = time;
    }

    public Integer getPq() {
        return pq;
    }

    public void setPq(Integer pq) {
        this.pq = pq;
    }

    public Integer getAttention() {
        return attention;
    }

    public void setAttention(Integer attention) {
        this.attention = attention;
    }

    public Integer getMeditation() {
        return meditation;
    }

    public void setMeditation(Integer meditation) {
        this.meditation = meditation;
    }

    public LocalDateTime getCreateTime() {
        return createTime;
    }

    public void setCreateTime(LocalDateTime createTime) {
        this.createTime = createTime;
    }

    @Override
    public String toString() {
        return "OtherData{" +
        "id=" + id +
        ", userId=" + userId +
        ", deviceId=" + deviceId +
        ", sceneId=" + sceneId +
        ", time=" + time +
        ", pq=" + pq +
        ", attention=" + attention +
        ", meditation=" + meditation +
        ", createTime=" + createTime +
        "}";
    }
}
