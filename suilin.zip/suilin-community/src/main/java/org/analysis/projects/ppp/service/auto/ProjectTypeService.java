package org.analysis.projects.ppp.service.auto;

import org.analysis.projects.ppp.model.auto.ProjectType;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 项目类型信息 服务类
 * </p>
 *
 * @author Feliz
 * @since 2020-04-02
 */
public interface ProjectTypeService extends IService<ProjectType> {

}
