package org.analysis.projects.ppp.model.auto;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import java.time.LocalDateTime;
import com.baomidou.mybatisplus.annotation.TableLogic;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * <p>
 * 项目动态信息
 * </p>
 *
 * @author Feliz
 * @since 2020-04-05
 */
@TableName("ppp_project_dynamic")
@ApiModel(value="ProjectDynamic对象", description="项目动态信息")
public class ProjectDynamic implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "项目id")
    @TableField("project_id")
    private Integer projectId;

    @ApiModelProperty(value = "项目状态；0：报名中；1：已邀请；2：已拒绝；3：已取消")
    @TableField("state")
    private Integer state;

    @ApiModelProperty(value = "申请人id（client_user）")
    @TableField("applicant_id")
    private Integer applicantId;

    @ApiModelProperty(value = "批复人id（server_user）")
    @TableField("reply_id")
    private Integer replyId;

    @ApiModelProperty(value = "面试说明")
    @TableField("interview_note")
    private String interviewNote;

    @ApiModelProperty(value = "申请时间")
    @TableField("applicant_time")
    private LocalDateTime applicantTime;

    @ApiModelProperty(value = "批复时间")
    @TableField("reply_time")
    private LocalDateTime replyTime;

    @ApiModelProperty(value = "逻辑删除；0：未删除；1：已删除")
    @TableField("deleted")
    @TableLogic
    private Integer deleted;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getProjectId() {
        return projectId;
    }

    public void setProjectId(Integer projectId) {
        this.projectId = projectId;
    }

    public Integer getState() {
        return state;
    }

    public void setState(Integer state) {
        this.state = state;
    }

    public Integer getApplicantId() {
        return applicantId;
    }

    public void setApplicantId(Integer applicantId) {
        this.applicantId = applicantId;
    }

    public Integer getReplyId() {
        return replyId;
    }

    public void setReplyId(Integer replyId) {
        this.replyId = replyId;
    }

    public String getInterviewNote() {
        return interviewNote;
    }

    public void setInterviewNote(String interviewNote) {
        this.interviewNote = interviewNote;
    }

    public LocalDateTime getApplicantTime() {
        return applicantTime;
    }

    public void setApplicantTime(LocalDateTime applicantTime) {
        this.applicantTime = applicantTime;
    }

    public LocalDateTime getReplyTime() {
        return replyTime;
    }

    public void setReplyTime(LocalDateTime replyTime) {
        this.replyTime = replyTime;
    }

    public Integer getDeleted() {
        return deleted;
    }

    public void setDeleted(Integer deleted) {
        this.deleted = deleted;
    }

    @Override
    public String toString() {
        return "ProjectDynamic{" +
        "id=" + id +
        ", projectId=" + projectId +
        ", state=" + state +
        ", applicantId=" + applicantId +
        ", replyId=" + replyId +
        ", interviewNote=" + interviewNote +
        ", applicantTime=" + applicantTime +
        ", replyTime=" + replyTime +
        ", deleted=" + deleted +
        "}";
    }
}
