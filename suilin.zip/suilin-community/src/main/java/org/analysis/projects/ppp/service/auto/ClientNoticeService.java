package org.analysis.projects.ppp.service.auto;

import org.analysis.projects.ppp.model.auto.ClientNotice;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 用户版通知信息 服务类
 * </p>
 *
 * @author Feliz
 * @since 2020-03-31
 */
public interface ClientNoticeService extends IService<ClientNotice> {

}
