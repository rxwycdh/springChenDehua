package org.analysis.projects.ppp.minapp.client;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.analysis.projects.ppp.logic.ProjectTagLogic;
import org.analysis.projects.ppp.model.auto.Project;
import org.analysis.projects.ppp.model.auto.ProjectType;
import org.analysis.projects.ppp.model.auto.UserProjectCollection;
import org.analysis.projects.ppp.model.custom.ProjectIF;
import org.analysis.projects.ppp.service.auto.ProjectService;
import org.analysis.projects.ppp.service.auto.ProjectTypeService;
import org.analysis.projects.ppp.service.auto.UserProjectCollectionService;
import org.analysis.system.common.base.BaseController;
import org.analysis.system.common.domain.AjaxResult;
import org.analysis.system.common.domain.TableSplitResult;
import org.analysis.system.common.domain.Tablepar;
import org.analysis.system.common.support.Convert;
import org.analysis.system.util.GPSUtil;
import org.apache.commons.beanutils.BeanUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;


/**
 * <p>
 * 用户收藏信息 前端控制器
 * </p>
 *
 * @author Feliz
 * @since 2020-04-09 18:09:11
 */
@RestController
@Api(tags = {"微信小程序用户版-用户收藏信息接口"})
@RequestMapping("/wx/pppclient/minapp/collection")
public class WxMaClientUserCollectionController extends BaseController {

    private static Logger logger = LoggerFactory.getLogger(WxMaClientUserCollectionController.class);

    @Autowired
    private UserProjectCollectionService userProjectCollectionService;
    @Autowired
    private ProjectService projectService;
    @Autowired
    private ProjectTypeService projectTypeService;
    @Autowired
    private ProjectTagLogic projectTagLogic;

    @ApiOperation(value = "获取用户收藏信息列表", notes = "获取用户收藏信息列表")
    @GetMapping("/list")
    public TableSplitResult<ProjectIF> list(Tablepar tablepar,
                                            @ApiParam(name = "id", value = "用户id") Integer id,
                                            @ApiParam(name = "longitude", value = "用户经度") double longitude,
                                            @ApiParam(name = "latitude", value = "用户纬度") double latitude) {

        try {
            QueryWrapper<UserProjectCollection> queryWrapper = new QueryWrapper<>();
            queryWrapper.eq("user_id", id);
            queryWrapper.orderByDesc("create_time is null, create_time");
            PageHelper.startPage(tablepar.getPageNum(), tablepar.getPageSize());
            List<UserProjectCollection> userProjectCollections = userProjectCollectionService.list(queryWrapper);
            PageInfo<UserProjectCollection> pageInfo = new PageInfo<>(userProjectCollections);

            if (userProjectCollections.size() == 0) {
                return null;
            }
            List<Integer> projectIds = new ArrayList<>();
            for (UserProjectCollection upc : userProjectCollections) {
                projectIds.add(upc.getProjectId());
            }
            List<Project> projects = (List<Project>) projectService.listByIds(projectIds);

            List<ProjectIF> list = new ArrayList<>();
            for (Project p : projects) {
                ProjectIF projectIF = new ProjectIF();

                BeanUtils.copyProperties(projectIF, p);

                ProjectType projectType = projectTypeService.getById(p.getTypeId());
                projectIF.setTypeName(projectType!=null ? projectType.getName() : "");

                String tagsName = projectTagLogic.queryProjectTags(p.getId());
                projectIF.setTags(Convert.toListStrArray(tagsName));

                //计算距离
                double distance = GPSUtil.distanceByLongNLat(latitude, longitude, p.getLatitude().doubleValue(), p.getLongitude().doubleValue());
                projectIF.setDistance(String.valueOf(Math.round(distance)));

                list.add(projectIF);
            }

            return new TableSplitResult<>(pageInfo.getPageNum(), pageInfo.getTotal(), list);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            return null;
        }
    }

    @ApiOperation(value = "用户收藏项目接口", notes = "用户收藏项目接口")
    @GetMapping("/add")
    public AjaxResult add(UserProjectCollection userProjectCollection) {

        try {
            userProjectCollection.setCreateTime(LocalDateTime.now());
            boolean save = userProjectCollectionService.save(userProjectCollection);
            return save ? success() : error();
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            return error();
        }
    }

    @ApiOperation(value = "用户取消收藏项目接口", notes = "用户取消收藏项目接口")
    @GetMapping("/remove")
    public AjaxResult remove(UserProjectCollection userProjectCollection) {
        try {
            QueryWrapper<UserProjectCollection> queryWrapper = new QueryWrapper<>();
            queryWrapper.eq("user_id", userProjectCollection.getUserId());
            queryWrapper.eq("project_id", userProjectCollection.getProjectId());

            boolean delete = userProjectCollectionService.remove(queryWrapper);
            return delete ? success() : error();
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            return error();
        }
    }

}
