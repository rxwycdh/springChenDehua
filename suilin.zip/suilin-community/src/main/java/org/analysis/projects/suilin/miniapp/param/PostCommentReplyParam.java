package org.analysis.projects.suilin.miniapp.param;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableLogic;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;

/**
 * @author ChenDehua  597701764@qq.com
 * @date 2020/8/19 15:06
 */
@Data
@ApiModel("评论回复参数")
public class PostCommentReplyParam {

    @ApiModelProperty(value = "用户号")
    @NotNull
    private Integer suilinUserId;

    @ApiModelProperty(value = "回复编号")
    @NotNull
    private Integer suilinCommentId;

    @ApiModelProperty(value = "回复内容")
    @NotEmpty
    private String reply;

}
