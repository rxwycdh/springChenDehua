package org.analysis.projects.suilin.model.auto;

import java.math.BigDecimal;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import java.time.LocalDateTime;
import com.baomidou.mybatisplus.annotation.TableLogic;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.springframework.format.annotation.DateTimeFormat;

/**
 * <p>
 * 审核信息
 * </p>
 *
 * @author Feliz
 * @since 2020-07-28
 */
@TableName("suilin_examine")
@ApiModel(value="Examine对象", description="审核信息")
public class Examine implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "用户id")
    @TableField("suilin_user_id")
    private Integer suilinUserId;

    @ApiModelProperty(value = "姓名")
    @TableField("name")
    private String name;

    @ApiModelProperty(value = "认证类型")
    @TableField("certification_type")
    private String certificationType;

    @ApiModelProperty(value = "审核状态；0：未审核；1：已通过；2：未通过")
    @TableField("state")
    private Integer state;

    @ApiModelProperty(value = "证件类型")
    @TableField("id_card_type")
    private String idCardType;

    @ApiModelProperty(value = "身份证号")
    @TableField("id_card")
    private String idCard;

    @ApiModelProperty(value = "身份证照file-id")
    @TableField("id_card_file_id")
    private Integer idCardFileId;

    @ApiModelProperty(value = "房产证照file-id")
    @TableField("property_file_id")
    private Integer propertyFileId;

    @ApiModelProperty(value = "楼栋&房号")
    @TableField("room_number")
    private String roomNumber;

    @ApiModelProperty(value = "房屋面积")
    @TableField("room_area")
    private BigDecimal roomArea;

    @ApiModelProperty(value = "是否为小组成员0：否1：是")
    @TableField("is_party_member")
    private Integer isPartyMember;

    @ApiModelProperty(value = "审核意见")
    @TableField("examine_opinion")
    private String examineOpinion;

    @ApiModelProperty(value = "逻辑删除；0：未删除；1：已删除")
    @TableField("deleted")
    @TableLogic
    private Integer deleted;

    @ApiModelProperty(value = "提交时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @TableField("create_time")
    private LocalDateTime createTime;

    @ApiModelProperty(value = "审核时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @TableField("update_time")
    private LocalDateTime updateTime;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getSuilinUserId() {
        return suilinUserId;
    }

    public void setSuilinUserId(Integer suilinUserId) {
        this.suilinUserId = suilinUserId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCertificationType() {
        return certificationType;
    }

    public void setCertificationType(String certificationType) {
        this.certificationType = certificationType;
    }

    public Integer getState() {
        return state;
    }

    public void setState(Integer state) {
        this.state = state;
    }

    public String getIdCardType() {
        return idCardType;
    }

    public void setIdCardType(String idCardType) {
        this.idCardType = idCardType;
    }

    public String getIdCard() {
        return idCard;
    }

    public void setIdCard(String idCard) {
        this.idCard = idCard;
    }

    public Integer getIdCardFileId() {
        return idCardFileId;
    }

    public void setIdCardFileId(Integer idCardFileId) {
        this.idCardFileId = idCardFileId;
    }

    public Integer getPropertyFileId() {
        return propertyFileId;
    }

    public void setPropertyFileId(Integer propertyFileId) {
        this.propertyFileId = propertyFileId;
    }

    public String getRoomNumber() {
        return roomNumber;
    }

    public void setRoomNumber(String roomNumber) {
        this.roomNumber = roomNumber;
    }

    public BigDecimal getRoomArea() {
        return roomArea;
    }

    public void setRoomArea(BigDecimal roomArea) {
        this.roomArea = roomArea;
    }

    public Integer getIsPartyMember() {
        return isPartyMember;
    }

    public void setIsPartyMember(Integer isPartyMember) {
        this.isPartyMember = isPartyMember;
    }

    public String getExamineOpinion() {
        return examineOpinion;
    }

    public void setExamineOpinion(String examineOpinion) {
        this.examineOpinion = examineOpinion;
    }

    public Integer getDeleted() {
        return deleted;
    }

    public void setDeleted(Integer deleted) {
        this.deleted = deleted;
    }

    public LocalDateTime getCreateTime() {
        return createTime;
    }

    public void setCreateTime(LocalDateTime createTime) {
        this.createTime = createTime;
    }

    public LocalDateTime getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(LocalDateTime updateTime) {
        this.updateTime = updateTime;
    }

    @Override
    public String toString() {
        return "Examine{" +
        "id=" + id +
        ", suilinUserId=" + suilinUserId +
        ", name=" + name +
        ", certificationType=" + certificationType +
        ", state=" + state +
        ", idCardType=" + idCardType +
        ", idCard=" + idCard +
        ", idCardFileId=" + idCardFileId +
        ", propertyFileId=" + propertyFileId +
        ", roomNumber=" + roomNumber +
        ", roomArea=" + roomArea +
        ", isPartyMember=" + isPartyMember +
        ", examineOpinion=" + examineOpinion +
        ", deleted=" + deleted +
        ", createTime=" + createTime +
        ", updateTime=" + updateTime +
        "}";
    }
}
