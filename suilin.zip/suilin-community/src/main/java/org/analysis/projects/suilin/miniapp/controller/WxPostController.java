package org.analysis.projects.suilin.miniapp.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.AllArgsConstructor;
import org.analysis.projects.suilin.common.enums.PostStatisticsEnum;
import org.analysis.projects.suilin.miniapp.model.PostCommentDTO;
import org.analysis.projects.suilin.miniapp.model.PostCommentReplyDTO;
import org.analysis.projects.suilin.miniapp.model.PostInfoDTO;
import org.analysis.projects.suilin.miniapp.param.*;
import org.analysis.projects.suilin.model.auto.PostComment;
import org.analysis.projects.suilin.service.auto.PostCommentService;
import org.analysis.projects.suilin.service.auto.PostInfoService;
import org.analysis.projects.suilin.service.custom.PostCustomService;
import org.analysis.system.common.domain.AjaxResult;
import org.analysis.system.common.domain.TableSplitResult;
import org.analysis.system.common.domain.Tablepar;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

/**
 * @author ChenDehua  597701764@qq.com
 * @date 2020/8/19 10:02
 */
@RestController
@Api(tags = {"微信小程序用户版-话题接口"})
@RequestMapping("/wx/suilinclient/minapp/post")
@AllArgsConstructor
public class WxPostController {

    private PostInfoService postInfoService;

    private PostCommentService postCommentService;

    private PostCustomService postCustomService;

    @ApiOperation("查看帖子")
    @GetMapping("/info")
    public AjaxResult<PostInfoDTO> getPostInfo(@RequestParam Integer postInfoId,
                                               @RequestParam(required = false)Integer userId) {

        if(postCustomService.isNotExistPostInfo(postInfoId)) {
            return AjaxResult.error("帖子不存在");
        }

        postCustomService.updatePostInfoCount(postInfoId, PostStatisticsEnum.READ.type, 1);
        return AjaxResult.successData(postCustomService.getPostInfo(postInfoId, userId));
    }

    @ApiOperation("点赞/取消点赞帖子")
    @PutMapping("/info/like")
    public AjaxResult likeInfo(@RequestBody @Valid PostLikeParam param) {

        if(postCustomService.isNotExistPostInfo(param.getPostInfoId())) {
            return AjaxResult.error("帖子不存在");
        }

        if(postCustomService.updatePostLike(param.getUserId(), param.getPostInfoId())) {
            return AjaxResult.success();
        }

        return AjaxResult.error();
    }

    @ApiOperation("用户分享帖子")
    @PostMapping("/info/share")
    public AjaxResult insertShareUser(@RequestBody @Valid PostLikeParam param) {

        if(postCustomService.isNotExistPostInfo(param.getPostInfoId())) {
            return AjaxResult.error("帖子不存在");
        }

        if(postCustomService.insertShareUser(param.getPostInfoId(), param.getUserId())) {
            return AjaxResult.success();
        }

        return AjaxResult.error();
    }

    @ApiOperation("分页：获取帖子列表")
    @GetMapping("/info/list")
    public AjaxResult<TableSplitResult<PostInfoDTO>>
    listPostInfo(Tablepar tablepar,
                 @ApiParam(name = "sortType", value = "排序类型1：最新2：热门") @RequestParam Integer sortType,
                 @RequestParam(required = false)Integer userId,
                 @ApiParam(name = "searchText", value = "搜索关键词")@RequestParam(required = false) String searchText) {
        return AjaxResult.successData(postCustomService.listPostInfo(userId, tablepar, sortType, searchText));
    }

    @ApiOperation("分页：获取帖子评论")
    @GetMapping("/info/comment/list")
    public AjaxResult<TableSplitResult<PostCommentDTO>>
    listPostComment(Tablepar tablepar,
                    @ApiParam(name = "sort", value = "排序类型1：升序2：倒序")@RequestParam Integer sort,
                    @RequestParam Integer postInfoId,
                    @RequestParam(required = false)Integer userId) {
        return AjaxResult.successData(postCustomService.listPostComment(userId, postInfoId, tablepar, sort));
    }

    @ApiOperation("评论帖子")
    @PostMapping("/info/comment")
    public AjaxResult insertInfoComment(@RequestBody @Valid PostCommentParam param) {

        if(postCustomService.isNotExistPostInfo(param.getPostInfoId())) {
            return AjaxResult.error("帖子不存在");
        }

        if(postCustomService.isNotAllowComment(param.getPostInfoId())) {
            return AjaxResult.error("帖子不允许评论");
        }

        if(postCustomService.insertPostComment(param)) {
            return AjaxResult.success();
        }

        return AjaxResult.error();
    }

    @ApiOperation("点赞/取消帖子评论")
    @PutMapping("/info/comment/like")
    public AjaxResult updateCommentLike(@RequestBody @Valid PostCommentLikeParam param) {

        if(postCustomService.isNotExistComment(param.getCommentId())) {
            return AjaxResult.error("评论不存在");
        }

        if(postCustomService.updatePostCommentLike(param.getUserId(), param.getCommentId())) {
            return AjaxResult.success();
        }

        return AjaxResult.error();
    }

    @ApiOperation("点赞/取消帖子评论回复")
    @PutMapping("/info/comment/reply/like")
    public AjaxResult updateCommentReplyLike(@RequestBody @Valid PostCommentReplyLikeParam param) {

        if(postCustomService.isNotExistCommentReply(param.getCommentReplyId())) {
            return AjaxResult.error("评论回复不存在");
        }

        if(postCustomService.updatePostCommentReplyLike(param.getCommentReplyId(), param.getUserId())) {
            return AjaxResult.success();
        }

        return AjaxResult.error();
    }

    @ApiOperation("分页：根据评论编号获取评论回复")
    @GetMapping("/info/comment/reply/list")
    public AjaxResult<TableSplitResult<PostCommentReplyDTO>>
    listCommentReply(Tablepar tablepar,
                     @RequestParam Integer commentId,
                     @RequestParam(required = false)Integer userId) {

        if(postCustomService.isNotExistComment(commentId)) {
            return AjaxResult.error("评论不存在");
        }

        return AjaxResult.successData(postCustomService.listPostCommentReply(userId, commentId, tablepar));
    }

    @ApiOperation("删除评论")
    @DeleteMapping("/info/comment")
    public AjaxResult deleteInfoComment(@RequestParam Integer commentId) {

        if(postCustomService.isNotExistComment(commentId)) {
            return AjaxResult.error("评论不存在");
        }

        if(postCustomService.deleteComment(commentId)) {
            return AjaxResult.success();
        }

        return AjaxResult.error();
    }

    @ApiOperation("删除评论回复")
    @DeleteMapping("/info/comment/reply")
    public AjaxResult deleteInfoCommentReply(@RequestParam Integer commentReplyId) {

        if(postCustomService.isNotExistCommentReply(commentReplyId)) {
            return AjaxResult.error("评论不存在此评论回复");
        }

        if(postCustomService.deleteCommentReply(commentReplyId)) {
            return AjaxResult.success();
        }

        return AjaxResult.error();
    }

    @ApiOperation("插入评论回复")
    @PostMapping("/info/comment/reply")
    public AjaxResult insertCommentReply(@RequestBody @Valid PostCommentReplyParam param) {

        if(postCustomService.isNotExistComment(param.getSuilinCommentId())) {
            return AjaxResult.error("评论不存在");
        }
        PostComment comment = postCommentService.getById(param.getSuilinCommentId());

        if(postCustomService.isNotAllowComment(comment.getPostInfoId())) {
            return AjaxResult.error("帖子不允许评论");
        }

        if(postCustomService.insertCommentReply(param)) {
            return AjaxResult.success();
        }

        return AjaxResult.error();
    }

}
