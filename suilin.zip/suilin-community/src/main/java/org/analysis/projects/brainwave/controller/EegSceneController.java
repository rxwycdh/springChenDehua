package org.analysis.projects.brainwave.controller;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.analysis.projects.brainwave.model.auto.EegScene;
import org.analysis.projects.brainwave.service.auto.EegSceneService;
import org.analysis.system.common.base.BaseController;
import org.analysis.system.common.domain.AjaxResult;
import org.analysis.system.common.domain.TableSplitResult;
import org.analysis.system.common.domain.Tablepar;
import org.analysis.system.common.support.Convert;
import org.analysis.system.model.custom.TitleVo;
import org.analysis.system.util.StringUtils;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

/**
 * <p>
 * 脑波采集场景 前端控制器
 * </p>
 *
 * @author Feliz
 * @since 2019-06-06
 */
@Api(tags={"脑波采集场景"})
@Controller
@RequestMapping("/brainwave/eeg-scene")
public class EegSceneController extends BaseController {

    private static Logger logger = LoggerFactory.getLogger(EegSceneController.class);

    @Autowired
    private EegSceneService eegSceneService;

    //跳转页面前缀参数
    private String prefix = "projects/brainwave/scene";

    @ApiOperation(value = "获取全部场景数据", notes = "获取全部场景数据")
    @PostMapping("getalleegscene")
    @ResponseBody
    public AjaxResult<TableSplitResult<EegScene>> getAllEegUser() {
        try {
            List<EegScene> list = eegSceneService.list();
            return AjaxResult.successDataList(list);
        } catch (Exception e) {
            logger.error(e.toString());
            return AjaxResult.error(e.getMessage());
        }
    }

    @ApiOperation(value = "跳转场景管理页面", notes = "跳转到场景管理页面", hidden = true)
    @GetMapping("view")
    @RequiresPermissions("brainwave:scene:view")
    public String view(Model model) {
        setTitle(model, new TitleVo("场景列表", "场景管理", false, "欢迎进入场景管理页面", false, false));
        return prefix + "/list";
    }

    @ApiOperation(value = "获取场景列表", notes = "获取场景列表")
    @PostMapping("list")
    @RequiresPermissions("brainwave:scene:list")
    @ResponseBody
    public TableSplitResult<EegScene> list(Tablepar tablepar, String searchText) {

        QueryWrapper<EegScene> queryWrapper = new QueryWrapper<>();
        if (StringUtils.isNotEmpty(searchText)) {
            queryWrapper.like("device_name", searchText).or().like("device_type", searchText).or().like("description", searchText);
        }

        PageHelper.startPage(tablepar.getPageNum(), tablepar.getPageSize());
        List<EegScene> list = eegSceneService.list(queryWrapper);
        PageInfo<EegScene> pageInfo = new PageInfo<EegScene>(list);

        return new TableSplitResult<>(pageInfo.getPageNum(), pageInfo.getTotal(), pageInfo.getList());
    }


    @ApiOperation(value = "跳转新增场景页面", notes = "跳转新增场景页面", hidden = true)
    @GetMapping("/add")
    public String add() {
        return prefix + "/add";
    }


    @ApiOperation(value = "添加场景", notes = "添加新的场景")
    @PostMapping("add")
    @RequiresPermissions("brainwave:scene:add")
    @ResponseBody
    public AjaxResult add(EegScene eegScene) {
        boolean save = eegSceneService.save(eegScene);
        if (save) {
            return success();
        } else {
            return error();
        }
    }

    @ApiOperation(value = "删除场景", notes = "根据id删除场景（批量）")
    @PostMapping("remove")
    @RequiresPermissions("brainwave:scene:remove")
    @ResponseBody
    public AjaxResult remove(String ids) {
        List<String> idList = Convert.toListStrArray(ids);
        boolean save = eegSceneService.removeByIds(idList);
        if (save) {
            return success();
        } else {
            return error();
        }
    }


    @ApiOperation(value = "检查场景名字是否存在", notes = "传入: deviceName; 返回: 1-存在; 0-不存在")
    @PostMapping("checkNameUnique")
    @ResponseBody
    public Integer checkNameUnique(String sceneName) {
        QueryWrapper<EegScene> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("scene_name", sceneName);
        List<EegScene> list = eegSceneService.list(queryWrapper);
        if (list.size() > 0) {
            return 1;
        } else {
            return 0;
        }
    }

    @ApiOperation(value = "跳转场景修改页面", notes = "跳转到场景修改页面", hidden = true)
    @GetMapping("/edit/{id}")
    public String edit(@PathVariable("id") String id, ModelMap mmap) {
        mmap.put("eegScene", eegSceneService.getById(id));
        return prefix + "/edit";
    }


    @ApiOperation(value = "修改设备", notes = "修改保存设备")
    @PostMapping("/edit")
    @RequiresPermissions("brainwave:scene:edit")
    @ResponseBody
    public AjaxResult editSave(EegScene eegScene) {
        eegScene.setUpdateTime(LocalDateTime.now());
        boolean b = eegSceneService.updateById(eegScene);
        return b ? success() : error();
    }
}

