package org.analysis.projects.ppp.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.analysis.projects.ppp.model.auto.ClientNotice;
import org.analysis.projects.ppp.model.auto.ClientUser;
import org.analysis.projects.ppp.model.custom.ClientNoticeVO;
import org.analysis.projects.ppp.service.auto.ClientNoticeService;
import org.analysis.projects.ppp.service.auto.ClientUserService;
import org.analysis.system.common.base.BaseController;
import org.analysis.system.common.domain.AjaxResult;
import org.analysis.system.common.domain.TableSplitResult;
import org.analysis.system.common.domain.Tablepar;
import org.analysis.system.common.log.Log;
import org.analysis.system.common.support.Convert;
import org.analysis.system.model.custom.TitleVo;
import org.analysis.system.util.StringUtils;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;


/**
 * <p>
 * 用户版通知信息 前端控制器
 * </p>
 *
 * @author Feliz
 * @since 2020-03-31 20:27:52
 */
@Controller
@Api(tags = {"用户版通知信息"})
@RequestMapping("/ppp/ClientNoticeController")
public class ClientNoticeController extends BaseController{

    private static Logger logger = LoggerFactory.getLogger(ClientNoticeController.class);

    //跳转页面参数
    private String prefix = "projects/ppp/clientNotice";

	@Autowired
	private ClientNoticeService clientNoticeService;
	@Autowired
    private ClientUserService clientUserService;

	//跳转用户版通知信息页面
    @GetMapping("/view")
    @RequiresPermissions("ppp:clientNotice:view")
    public String view(Model model) {
        String str="用户版通知信息";
        setTitle(model, new TitleVo(str+"列表", str+"管理", false, "欢迎进入"+str+"页面", false, false));
        return prefix + "/list";
    }

    @Log(title = "用户版通知信息列表查询", action = "111")
    @ApiOperation(value = "获取用户版通知信息列表", notes = "获取用户版通知信息列表")
    @PostMapping("/list")
    @RequiresPermissions("ppp:clientNotice:list")
    @ResponseBody
    public TableSplitResult<ClientNoticeVO> list(Tablepar tablepar, String searchText) {

        QueryWrapper<ClientNotice> queryWrapper = new QueryWrapper<>();
        if (StringUtils.isNotEmpty(searchText)) {
            queryWrapper.and(wrapper -> wrapper
                    .like("title", searchText).or()
            );
        }

        PageHelper.startPage(tablepar.getPageNum(), tablepar.getPageSize());
        List<ClientNotice> clientNotices = clientNoticeService.list(queryWrapper);
        PageInfo<ClientNotice> pageInfo = new PageInfo<ClientNotice>(clientNotices);

        List<ClientNoticeVO> list = new ArrayList<>();
        for (ClientNotice cn : clientNotices) {
            ClientNoticeVO clientNoticeVO = new ClientNoticeVO();
            try {
                BeanUtils.copyProperties(clientNoticeVO, cn);
            } catch (Exception e) {
                logger.error(e.getMessage());
            }

            List<Integer> targetUserId = Convert.toListIntArray(cn.getTargetUser());
            if (targetUserId.size() > 0) {
                List<ClientUser> clientUsers = (List<ClientUser>) clientUserService.listByIds(targetUserId);

                List<String> targetUserName = new ArrayList<>();
                for (ClientUser cu: clientUsers) {
                    targetUserName.add(cu.getName());
                }

                clientNoticeVO.setTargetUserName(String.join(",", targetUserName));
            }

            list.add(clientNoticeVO);
        }

        return new TableSplitResult<>(pageInfo.getPageNum(), pageInfo.getTotal(), list);
    }

    @ApiOperation(value = "获取全部用户版通知信息信息", notes = "获取全部用户版通知信息信息")
    @PostMapping("/getAllClientNotice")
    @ResponseBody
    public AjaxResult<TableSplitResult<ClientNotice>> getAllClientNotice() {
        try {
            List<ClientNotice> list = clientNoticeService.list();
            return AjaxResult.successDataList(list);
        } catch (Exception e) {
            logger.error(e.toString());
            return AjaxResult.error(e.getMessage());
        }
    }

    //跳转用户版通知信息新增页面
    @GetMapping("/add")
    public String add() {
        return prefix + "/add";
    }

    @Log(title = "用户版通知信息新增", action = "111")
    @ApiOperation(value = "添加用户版通知信息", notes = "添加用户版通知信息")
    @PostMapping("add")
    @RequiresPermissions("ppp:clientNotice:add")
    @ResponseBody
    public AjaxResult add(ClientNotice clientNotice) {
        clientNotice.setCreateTime(LocalDateTime.now());
        boolean save = clientNoticeService.save(clientNotice);
        return save ? success() : error();
    }

    @Log(title = "用户版通知信息删除", action = "111")
    @ApiOperation(value = "删除用户版通知信息", notes = "根据id删除用户版通知信息（可批量）")
    @PostMapping("/remove")
    @RequiresPermissions("ppp:clientNotice:remove")
    @ResponseBody
    public AjaxResult remove(String ids) {
        List<Integer> idList= Convert.toListIntArray(ids);
        boolean delete = clientNoticeService.removeByIds(idList);
        return delete ? success() : error();
    }

    //跳转用户版通知信息修改页面
    @GetMapping("/edit/{id}")
    public String edit(@PathVariable("id") Integer id, ModelMap mmap) {
        mmap.put("clientNotice", clientNoticeService.getById(id));
        return prefix + "/edit";
    }

    @Log(title = "用户版通知信息修改", action = "111")
    @ApiOperation(value = "修改用户版通知信息", notes = "修改用户版通知信息")
    @PostMapping("/edit")
    @RequiresPermissions("ppp:clientNotice:edit")
    @ResponseBody
    public AjaxResult editSave(ClientNotice clientNotice) {
        clientNotice.setUpdateTime(LocalDateTime.now());
        boolean edit = clientNoticeService.updateById(clientNotice);
        return edit ? success() : error();
    }

}
