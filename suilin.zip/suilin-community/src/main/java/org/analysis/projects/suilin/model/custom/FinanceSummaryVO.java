package org.analysis.projects.suilin.model.custom;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * @author ChenDehua  597701764@qq.com
 * @date 2020/8/13 10:36
 */
@Setter
@Getter
@ToString
@ApiModel("小区财务概况")
public class FinanceSummaryVO extends FinanceStatisticsVO{

    /**
     * 本月收入同比上月变化幅度
     */
    @ApiModelProperty(value = "本月收入同比上月变化幅度")
    private Double incomeChangeRange;

    /**
     * 本月支出同比上月变化幅度
     */
    @ApiModelProperty(value = "本月支出同比上月变化幅度")
    private Double expensesChangeRange;

    /**
     * 本月余额同比上月变化幅度
     */
    @ApiModelProperty(value = "本月余额同比上月变化幅度")
    private Double balanceChangeRange;
}
