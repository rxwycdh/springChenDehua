package org.analysis.projects.oasystem.controller;


import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.analysis.system.common.base.BaseController;
import org.analysis.system.model.custom.TitleVo;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * <p>
 * 流程管理 前端控制器
 * </p>
 *
 * @author Feliz
 * @since 2019-06-14
 */
@Api(tags = {"流程管理"})
@Controller
@RequestMapping("/oasystem/process")
public class ProcessController extends BaseController {

    private static Logger logger = LoggerFactory.getLogger(DeptController.class);

    //跳转页面参数
    private String prefix = "projects/oasystem/process";

    @ApiOperation(value = "跳转新建流程页面", notes = "跳转到新建流程页面", hidden = true)
    @GetMapping("add")
    @RequiresPermissions("oasystem:process:add")
    public String view(Model model) {
        setTitle(model, new TitleVo("新建流程", "流程管理", false, "欢迎进入新建流程页面", false, false));
        return prefix + "/add";
    }

}
