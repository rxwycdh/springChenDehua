package org.analysis.projects.suilin.service.auto.impl;

import org.analysis.projects.suilin.model.auto.Finance;
import org.analysis.projects.suilin.mapper.auto.FinanceMapper;
import org.analysis.projects.suilin.service.auto.FinanceService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 财务信息 服务实现类
 * </p>
 *
 * @author Feliz
 * @since 2020-07-28
 */
@Service
public class FinanceServiceImpl extends ServiceImpl<FinanceMapper, Finance> implements FinanceService {

}
