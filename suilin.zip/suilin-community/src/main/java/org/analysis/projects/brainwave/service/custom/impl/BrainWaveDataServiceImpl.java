package org.analysis.projects.brainwave.service.custom.impl;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import org.analysis.projects.brainwave.model.auto.*;
import org.analysis.projects.brainwave.model.custom.DataQueryCondition;
import org.analysis.projects.brainwave.service.auto.*;
import org.analysis.projects.brainwave.service.custom.BrainWaveDataService;
import org.analysis.projects.brainwave.util.EEGUtil;
import org.analysis.system.model.auto.TsysDatas;
import org.analysis.system.service.SysDatasService;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Service
public class BrainWaveDataServiceImpl implements BrainWaveDataService {

    private static Logger logger = LoggerFactory.getLogger(BrainWaveDataServiceImpl.class);

    @Autowired
    private RawDataService rawDataService;
    @Autowired
    private AlphaDataService alphaDataService;
    @Autowired
    private BetaDataService betaDataService;
    @Autowired
    private DeltaDataService deltaDataService;
    @Autowired
    private GammaDataService gammaDataService;
    @Autowired
    private ThetaDataService thetaDataService;
    @Autowired
    private OtherDataService otherDataService;
    @Autowired
    private SysDatasService sysDatasService;

    /**
     * 保存原始数据
     *
     * @param datas              原始数据
     * @param dataQueryCondition 脑波数据查询条件
     */
    @DS("db_brainwave")
    @Transactional
    @Override
    public void saveBatchRawData(ArrayList<String> datas, DataQueryCondition dataQueryCondition) {
        try {
            ArrayList<RawData> rawDataList = new ArrayList<>();
            for (String str : datas) {
                RawData rawData = new RawData();
                rawData.setUserId(dataQueryCondition.getEegUser());
                rawData.setDeviceId(dataQueryCondition.getEegDevice());
                rawData.setSceneId(dataQueryCondition.getEegScene());

                String timeStr = str.split(" ")[0];
                LocalDateTime time = LocalDateTime.parse(timeStr);

                //检测是否存在重复数据
                QueryWrapper<RawData> queryWrapper = new QueryWrapper<>();
                queryWrapper.eq("user_id", dataQueryCondition.getEegUser())
                        .eq("device_id", dataQueryCondition.getEegDevice())
                        .eq("scene_id", dataQueryCondition.getEegScene())
                        .eq("time", time);

                if (rawDataService.list(queryWrapper).size() == 0) {

                    rawData.setTime(time);
                    rawData.setRawData(str);
                    rawData.setAnalysed(0);

                    rawDataList.add(rawData);
                }
            }
            rawDataService.saveBatch(rawDataList);

            System.out.println("=================================");
            System.out.println("==========原始数据保存完成==========");
            System.out.println("=================================");

            //解析后分散波形储存
            this.splitBrainWave();

        } catch (Exception e) {
            //            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly(); //手动回滚失误
            throw new RuntimeException("报错原始数据出错--" + e.toString());
        }
    }

    /**
     * 解析后分散波形储存
     */
    @DS("db_brainwave")
    @Override
    public void splitBrainWave() {
        try {
            QueryWrapper queryWrapper = new QueryWrapper();
            queryWrapper.eq("analysed", 0);
            queryWrapper.orderByAsc("time is null, time");
            List<RawData> rawDataList = rawDataService.list(queryWrapper);

            for (int l = 0; l < rawDataList.size(); l++) {

                String[] rdatas = rawDataList.get(l).getRawData().split(" ");

                AlphaData alphaData = new AlphaData();
                BetaData betaData = new BetaData();
                DeltaData deltaData = new DeltaData();
                GammaData gammaData = new GammaData();
                ThetaData thetaData = new ThetaData();
                OtherData otherData = new OtherData();

                //时间戳
                LocalDateTime time = LocalDateTime.parse(rdatas[0]);
                alphaData.setTime(time);
                betaData.setTime(time);
                deltaData.setTime(time);
                gammaData.setTime(time);
                thetaData.setTime(time);
                otherData.setTime(time);
                //穿戴者
                Integer userId = rawDataList.get(l).getUserId();
                alphaData.setUserId(userId);
                betaData.setUserId(userId);
                deltaData.setUserId(userId);
                gammaData.setUserId(userId);
                thetaData.setUserId(userId);
                otherData.setUserId(userId);
                //穿戴设备
                Integer deviceId = rawDataList.get(l).getDeviceId();
                alphaData.setDeviceId(deviceId);
                betaData.setDeviceId(deviceId);
                deltaData.setDeviceId(deviceId);
                gammaData.setDeviceId(deviceId);
                thetaData.setDeviceId(deviceId);
                otherData.setDeviceId(deviceId);
                //场景
                Integer sceneId = rawDataList.get(l).getSceneId();
                alphaData.setSceneId(sceneId);
                betaData.setSceneId(sceneId);
                deltaData.setSceneId(sceneId);
                gammaData.setSceneId(sceneId);
                thetaData.setSceneId(sceneId);
                otherData.setSceneId(sceneId);
                //创建时间
                alphaData.setCreateTime(time);
                betaData.setCreateTime(time);
                deltaData.setCreateTime(time);
                gammaData.setCreateTime(time);
                thetaData.setCreateTime(time);
                otherData.setCreateTime(time);
                //判断数据是否同步; AA 同步
                for (int i = 1; i < rdatas.length; i++) {

                    rawDataList.get(l).setAnalysed(1);

                    if (rdatas.length - i < 8) {
                        logger.info("----掉包+1-----");
                        continue;
                    }

                    //大包
                    if ("AA".equals(rdatas[i]) && "AA".equals(rdatas[i + 1]) && "20".equals(rdatas[i + 2])) {

                        if (rdatas.length - i < 36) {
                            logger.info("----掉包+1-----");
                            continue;
                        }

                        i = i + 3;
                        //信号值
                        if ("02".equals(rdatas[i++])) {
                            alphaData.setPq(Integer.parseInt(rdatas[i], 16));
                            betaData.setPq(Integer.parseInt(rdatas[i], 16));
                            deltaData.setPq(Integer.parseInt(rdatas[i], 16));
                            gammaData.setPq(Integer.parseInt(rdatas[i], 16));
                            thetaData.setPq(Integer.parseInt(rdatas[i], 16));
                            otherData.setPq(Integer.parseInt(rdatas[i], 16));
                            i++;
                        }
                        //EEG值
                        if ("83".equals(rdatas[i++]) && "18".equals(rdatas[i++])) {
                            deltaData.setDelta1(Integer.parseInt(rdatas[i++], 16));
                            deltaData.setDelta2(Integer.parseInt(rdatas[i++], 16));
                            deltaData.setDelta3(Integer.parseInt(rdatas[i++], 16));

                            thetaData.setTheta1(Integer.parseInt(rdatas[i++], 16));
                            thetaData.setTheta2(Integer.parseInt(rdatas[i++], 16));
                            thetaData.setTheta3(Integer.parseInt(rdatas[i++], 16));

                            alphaData.setLowAlpha1(Integer.parseInt(rdatas[i++], 16));
                            alphaData.setLowAlpha2(Integer.parseInt(rdatas[i++], 16));
                            alphaData.setLowAlpha3(Integer.parseInt(rdatas[i++], 16));
                            alphaData.setHighAlpha1(Integer.parseInt(rdatas[i++], 16));
                            alphaData.setHighAlpha2(Integer.parseInt(rdatas[i++], 16));
                            alphaData.setHighAlpha3(Integer.parseInt(rdatas[i++], 16));

                            betaData.setLowBeta1(Integer.parseInt(rdatas[i++], 16));
                            betaData.setLowBeta2(Integer.parseInt(rdatas[i++], 16));
                            betaData.setLowBeta3(Integer.parseInt(rdatas[i++], 16));
                            betaData.setHighBeta1(Integer.parseInt(rdatas[i++], 16));
                            betaData.setHighBeta2(Integer.parseInt(rdatas[i++], 16));
                            betaData.setHighBeta3(Integer.parseInt(rdatas[i++], 16));

                            gammaData.setLowGamma1(Integer.parseInt(rdatas[i++], 16));
                            gammaData.setLowGamma2(Integer.parseInt(rdatas[i++], 16));
                            gammaData.setLowGamma3(Integer.parseInt(rdatas[i++], 16));
                            gammaData.setMiddleGamma1(Integer.parseInt(rdatas[i++], 16));
                            gammaData.setMiddleGamma2(Integer.parseInt(rdatas[i++], 16));
                            gammaData.setMiddleGamma3(Integer.parseInt(rdatas[i++], 16));
                        }
                        //Attention关注度
                        if ("04".equals(rdatas[i++])) {
                            otherData.setAttention(Integer.parseInt(rdatas[i++], 16));
                        }
                        //Meditation冥想度
                        if ("05".equals(rdatas[i++])) {
                            otherData.setMeditation(Integer.parseInt(rdatas[i++], 16));
                        }
                        i--;

                        alphaDataService.save(alphaData);
                        betaDataService.save(betaData);
                        gammaDataService.save(gammaData);
                        thetaDataService.save(thetaData);
                        deltaDataService.save(deltaData);
                        otherDataService.save(otherData);


                        logger.info("----大包+1-----");

                    } else if ("AA".equals(rdatas[i]) && "AA".equals(rdatas[i + 1]) && "04".equals(rdatas[i + 2]) &&
                            "80".equals(rdatas[i + 3]) && "02".equals(rdatas[i + 4])) {

                        i = i + 5;
                        //小包
                        Integer xxHigh = Integer.parseInt(rdatas[i++], 16);
                        Integer xxLow = Integer.parseInt(rdatas[i++], 16);
                        Integer sum = 0x80 + 0x02 + xxHigh + xxLow;
                        Integer checkSum = Integer.parseInt(rdatas[i++], 16);

                        Integer rawData = EEGUtil.getRawData(xxHigh, xxLow, sum, checkSum);
                        if (rawData != null) {
                            //TODO 获取rawData
                        }

                        i--;

                        logger.info("----小包+1-----");

                    }
                }
            }
            if (rawDataList.size() > 0) {
                rawDataService.updateBatchById(rawDataList);
            }

            System.out.println("=================================");
            System.out.println("==========分散波形储存完成==========");
            System.out.println("=================================");
        } catch (Exception e) {
            throw new RuntimeException("分割脑波数据出错--" + ExceptionUtils.getFullStackTrace(e));
        }
    }

    /**
     * 分割原始数据文件
     *
     * @param dataId 文件id
     * @return
     */
    @Override
    public ArrayList<String> splitDataFile(Integer dataId) {
        TsysDatas tsysDatas = sysDatasService.selectByPrimaryKey(dataId);
        String filePath = tsysDatas.getFilePath();
        ArrayList<String> dataList = new ArrayList<>();

        File file = new File(filePath);
        BufferedReader reader = null;
        try {
            //以行为单位读取文件内容，一次读一整行
            reader = new BufferedReader(new FileReader(file));
            String tempString = null;
            int line = 1;
            // 一次读入一行，直到读入null为文件结束
            while ((tempString = reader.readLine()) != null) {
                // 显示行号
                dataList.add(tempString);
                line++;
            }
            reader.close();
            return dataList;
        } catch (IOException e) {
            logger.error(ExceptionUtils.getFullStackTrace(e));
        } finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException ex) {
                    logger.error(ExceptionUtils.getFullStackTrace(ex));
                }
            }
        }
        return null;
    }

}
