package org.analysis.projects.suilin.service.auto;

import org.analysis.projects.suilin.model.auto.Position;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 岗位信息 服务类
 * </p>
 *
 * @author Feliz
 * @since 2020-07-28
 */
public interface PositionService extends IService<Position> {

}
