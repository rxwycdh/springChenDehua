package org.analysis.projects.brainwave.model.auto;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * <p>
 * theta脑波数据表
 * </p>
 *
 * @author Feliz
 * @since 2019-06-06
 */
@TableName("brainwave_theta_data")
@ApiModel(value="ThetaData对象", description="theta脑波数据表")
public class ThetaData implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "id", required = true, example = "0", position = 1)
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "穿戴人", example = "0")
    @TableField("user_id")
    private Integer userId;

    @ApiModelProperty(value = "设备id", example = "0")
    @TableField("device_id")
    private Integer deviceId;

    @ApiModelProperty(value = "场景id", example = "0")
    @TableField("scene_id")
    private Integer sceneId;

    @ApiModelProperty(value = "时间戳")
    @TableField("time")
    private LocalDateTime time;

    @ApiModelProperty(value = "信号值", example = "200")
    @TableField("pq")
    private Integer pq;

    @TableField("theta1")
    private Integer theta1;

    @TableField("theta2")
    private Integer theta2;

    @TableField("theta3")
    private Integer theta3;

    @ApiModelProperty(value = "创建时间")
    @TableField("create_time")
    private LocalDateTime createTime;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public Integer getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(Integer deviceId) {
        this.deviceId = deviceId;
    }

    public Integer getSceneId() {
        return sceneId;
    }

    public void setSceneId(Integer sceneId) {
        this.sceneId = sceneId;
    }

    public LocalDateTime getTime() {
        return time;
    }

    public void setTime(LocalDateTime time) {
        this.time = time;
    }

    public Integer getPq() {
        return pq;
    }

    public void setPq(Integer pq) {
        this.pq = pq;
    }

    public Integer getTheta1() {
        return theta1;
    }

    public void setTheta1(Integer theta1) {
        this.theta1 = theta1;
    }

    public Integer getTheta2() {
        return theta2;
    }

    public void setTheta2(Integer theta2) {
        this.theta2 = theta2;
    }

    public Integer getTheta3() {
        return theta3;
    }

    public void setTheta3(Integer theta3) {
        this.theta3 = theta3;
    }

    public LocalDateTime getCreateTime() {
        return createTime;
    }

    public void setCreateTime(LocalDateTime createTime) {
        this.createTime = createTime;
    }

    @Override
    public String toString() {
        return "ThetaData{" +
        "id=" + id +
        ", userId=" + userId +
        ", deviceId=" + deviceId +
        ", sceneId=" + sceneId +
        ", time=" + time +
        ", pq=" + pq +
        ", theta1=" + theta1 +
        ", theta2=" + theta2 +
        ", theta3=" + theta3 +
        ", createTime=" + createTime +
        "}";
    }
}
