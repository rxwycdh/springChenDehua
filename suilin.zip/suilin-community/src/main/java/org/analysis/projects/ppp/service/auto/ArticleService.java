package org.analysis.projects.ppp.service.auto;

import org.analysis.projects.ppp.model.auto.Article;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 文章信息表 服务类
 * </p>
 *
 * @author Feliz
 * @since 2020-03-29
 */
public interface ArticleService extends IService<Article> {

}
