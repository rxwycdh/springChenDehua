package org.analysis.projects.ppp.minapp.server;

import cn.binarywang.wx.miniapp.api.WxMaService;
import cn.binarywang.wx.miniapp.bean.WxMaJscode2SessionResult;
import cn.binarywang.wx.miniapp.bean.WxMaPhoneNumberInfo;
import cn.binarywang.wx.miniapp.bean.WxMaUserInfo;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.analysis.projects.ppp.model.auto.ServerUser;
import org.analysis.projects.ppp.model.custom.ServerUserIF;
import org.analysis.projects.ppp.service.auto.ServerUserService;
import org.analysis.system.common.base.BaseController;
import org.analysis.system.common.domain.AjaxResult;
import org.analysis.system.model.auto.TsysFile;
import org.analysis.wx.common.utils.JsonUtils;
import org.analysis.wx.miniapp.config.WxMaConfiguration;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.time.LocalDateTime;
import java.util.List;

/**
 * 微信小程序用户版用户接口
 */
@RestController
@Api(tags = {"微信小程序服务版-用户接口"})
@RequestMapping("/wx/pppserver/minapp/user")
public class WxMaServerUserController extends BaseController {
    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    private final String appid = "wxd840f0b47aceb8e6";

    @Autowired
    private ServerUserService serverUserService;

    /**
     * 登陆接口
     */
    @GetMapping("/login")
    @ApiOperation(value = "登陆接口", notes = "微信小程序用户登陆")
    public AjaxResult<ServerUserIF> login(String code, HttpServletRequest request) {

        if (StringUtils.isBlank(code)) {
            return AjaxResult.error("empty code");
        }

        final WxMaService wxService = WxMaConfiguration.getMaService(appid);

        try {
            WxMaJscode2SessionResult session = wxService.getUserService().getSessionInfo(code);

            //检测是否已注册用户
            QueryWrapper<ServerUser> queryWrapper = new QueryWrapper<>();
            queryWrapper.eq("openid", session.getOpenid());
            List<ServerUser> list = serverUserService.list(queryWrapper);

            //若没有注册即注册用户
            if (list.size() == 0) {

                ServerUserIF serverUserIF = new ServerUserIF(null, null, session.getSessionKey());
                return AjaxResult.successData(serverUserIF);

            } else {
                ServerUserIF serverUserIF = new ServerUserIF();
                ServerUser serverUser = list.get(0);
                BeanUtils.copyProperties(serverUserIF, serverUser);
                String avatarUrl = "https://" + request.getServerName() + request.getContextPath() + "/FileController/viewFileByFileId/" + serverUser.getAvatarId();
                serverUserIF.setAvatarUrl(avatarUrl);
                serverUserIF.setSessionKey(session.getSessionKey());

                return AjaxResult.successData(serverUserIF);
            }

        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            return AjaxResult.error("login error");
        }
    }

    /**
     * <pre>
     * 注册接口
     * </pre>
     */
    @GetMapping("/register")
    @Transactional
    @ApiOperation(value = "注册接口", notes = "微信小程序初次获取用户微信信息并注册用户")
    public AjaxResult<ServerUserIF> register(String sessionKey, String signature, String rawData, String encryptedData, String iv, HttpServletRequest request) {

        final WxMaService wxService = WxMaConfiguration.getMaService(appid);

        try {
            // 用户信息校验
            if (!wxService.getUserService().checkUserInfo(sessionKey, rawData, signature)) {
                return AjaxResult.error("user check failed");
            }

            // 解密用户信息
            WxMaUserInfo userInfo = wxService.getUserService().getUserInfo(sessionKey, encryptedData, iv);

            //检测是否已注册用户
            QueryWrapper<ServerUser> queryWrapper = new QueryWrapper<>();
            queryWrapper.eq("openid", userInfo.getOpenId());
            List<ServerUser> list = serverUserService.list(queryWrapper);
            //若已注册直接返回用户信息
            if (list.size() != 0) {
                ServerUserIF serverUserIF = new ServerUserIF();
                ServerUser serverUser = list.get(0);
                BeanUtils.copyProperties(serverUserIF, serverUser);
                String avatarUrl = "https://" + request.getServerName() + request.getContextPath() + "/FileController/viewFileByFileId/" + serverUser.getAvatarId();
                serverUserIF.setAvatarUrl(avatarUrl);
                serverUserIF.setSessionKey(sessionKey);

                logger.info("#####用户已注册,直接返回用户信息-openid:" + userInfo.getOpenId());
                return AjaxResult.successData(serverUserIF);
            }

            ServerUser serverUser = new ServerUser();
            serverUser.setName(userInfo.getNickName());
            serverUser.setGender(Integer.parseInt(userInfo.getGender()));
            //上传头像到服务器
            int avatarId = sysFileService.insertUrl(userInfo.getNickName(), userInfo.getAvatarUrl(), "serverSideAvatar_" + userInfo.getOpenId() + ".png");
            serverUser.setAvatarId(avatarId);
            serverUser.setOpenid(userInfo.getOpenId());
            serverUser.setUnionid(userInfo.getUnionId());
//            serverUser.setCountry(userInfo.getCountry());
//            serverUser.setProvince(userInfo.getProvince());
//            serverUser.setCity(userInfo.getCity());
            serverUser.setCreateTime(LocalDateTime.now());
            boolean save = serverUserService.save(serverUser);

            ServerUserIF serverUserIF = new ServerUserIF();
            BeanUtils.copyProperties(serverUserIF, serverUser);
            String avatarUrl = "https://" + request.getServerName() + request.getContextPath() + "/FileController/viewFileByFileId/" + serverUser.getAvatarId();
            serverUserIF.setAvatarUrl(avatarUrl);
            serverUserIF.setSessionKey(sessionKey);
            if (save) {
                return AjaxResult.successData(serverUserIF);
            } else {
                return AjaxResult.error("register error");
            }
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            return AjaxResult.error("register error");
        }
    }


    @GetMapping("/getUserInfo/{id}")
    @ApiOperation(value = "获取用户信息", notes = "微信小程序获取用户信息")
    public AjaxResult<ServerUserIF> getUserInfo(@ApiParam(name = "id", value = "用户id") @PathVariable("id") Integer id, HttpServletRequest request) {

        try {
            ServerUser serverUser = serverUserService.getById(id);
            ServerUserIF serverUserIF = new ServerUserIF();
            BeanUtils.copyProperties(serverUser, serverUser);

            String avatarUrl = "https://" + request.getServerName() + request.getContextPath() + "/FileController/viewFileByFileId/" + serverUser.getAvatarId();
            serverUserIF.setAvatarUrl(avatarUrl);

            return AjaxResult.successData(serverUserIF);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            return AjaxResult.error("getUserInfo error");
        }

    }

    @GetMapping("/editUserInfo")
    @Transactional
    @ApiOperation(value = "修改用户信息", notes = "微信小程序修改用户信息")
    public AjaxResult editUserInfo(ServerUser serverUser, @ApiParam(name = "dataId", value = "文件数据id") Integer dataId) {

        try {
            if (dataId != null) {
                //修改文件
                TsysFile record = sysFileService.selectByPrimaryKey(serverUser.getAvatarId());
                sysFileService.updateByPrimaryKey(record, dataId);
            }

            serverUser.setUpdateTime(LocalDateTime.now());
            boolean edit = serverUserService.updateById(serverUser);
            return edit ? success() : error();
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            return AjaxResult.error("editUserInfo error");
        }

    }

    /**
     * <pre>
     * 获取用户绑定手机号信息
     * </pre>
     */
    @GetMapping("/phone")
    @ApiOperation(value = "获取用户绑定手机号信息", notes = "微信小程序获取用户绑定手机号信息")
    public String phone(String sessionKey, String signature, String rawData, String encryptedData, String iv) {
        final WxMaService wxService = WxMaConfiguration.getMaService(appid);

        // 用户信息校验
        if (!wxService.getUserService().checkUserInfo(sessionKey, rawData, signature)) {
            return "user check failed";
        }

        // 解密
        WxMaPhoneNumberInfo phoneNoInfo = wxService.getUserService().getPhoneNoInfo(sessionKey, encryptedData, iv);

        return JsonUtils.toJson(phoneNoInfo);
    }


}
