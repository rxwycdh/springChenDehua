package org.analysis.projects.brainwave.service.auto;

import com.baomidou.mybatisplus.extension.service.IService;
import org.analysis.projects.brainwave.model.auto.GammaData;

/**
 * <p>
 * gamma脑波数据表 服务类
 * </p>
 *
 * @author Feliz
 * @since 2019-06-06
 */
public interface GammaDataService extends IService<GammaData> {

}
