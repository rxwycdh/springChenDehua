package org.analysis.projects.ppp.model.custom;

import com.baomidou.mybatisplus.annotation.TableField;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * <p>
 * 项目动态信息
 * </p>
 *
 * @author Feliz
 * @since 2020-04-05
 */
@ApiModel(value="ClientDynamicIF对象", description="用户版项目动态信息")
public class DynamicIF implements Serializable {

    private static final long serialVersionUID = 1L;

    private Integer id;

    @ApiModelProperty(value = "项目标题")
    private String projectTitle;

    @ApiModelProperty(value = "项目类型")
    private String projectType;

    @ApiModelProperty(value = "状态；0：报名中；1：已邀请；2：已拒绝；3：已取消")
    @TableField("state")
    private Integer state;

    @ApiModelProperty(value = "动态信息")
    private String dynamicContent;

    @ApiModelProperty(value = "动态时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime dynamicTime;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getProjectTitle() {
        return projectTitle;
    }

    public void setProjectTitle(String projectTitle) {
        this.projectTitle = projectTitle;
    }

    public String getProjectType() {
        return projectType;
    }

    public void setProjectType(String projectType) {
        this.projectType = projectType;
    }

    public Integer getState() {
        return state;
    }

    public void setState(Integer state) {
        this.state = state;
    }

    public String getDynamicContent() {
        return dynamicContent;
    }

    public void setDynamicContent(String dynamicContent) {
        this.dynamicContent = dynamicContent;
    }

    public LocalDateTime getDynamicTime() {
        return dynamicTime;
    }

    public void setDynamicTime(LocalDateTime dynamicTime) {
        this.dynamicTime = dynamicTime;
    }

    @Override
    public String toString() {
        return "DynamicIF{" +
                "id=" + id +
                ", projectTitle='" + projectTitle + '\'' +
                ", projectType='" + projectType + '\'' +
                ", state=" + state +
                ", dynamicContent='" + dynamicContent + '\'' +
                ", dynamicTime=" + dynamicTime +
                '}';
    }
}
