package org.analysis.projects.brainwave.service.auto.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.analysis.projects.brainwave.mapper.auto.EegUserMapper;
import org.analysis.projects.brainwave.model.auto.EegUser;
import org.analysis.projects.brainwave.service.auto.EegUserService;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author Feliz
 * @since 2019-05-30
 */
@Service
public class EegUserServiceImpl extends ServiceImpl<EegUserMapper, EegUser> implements EegUserService {

}
