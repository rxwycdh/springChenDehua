package org.analysis.projects.ppp;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * 轮播信息表项目启动器
 */
@MapperScan(value = "org.analysis.projects.ppp.mapper")
@SpringBootApplication
public class PppSystemApplication {

    public static void main(String[] args) {
        SpringApplication.run(PppSystemApplication.class, args);
        System.out.println("=================================");
        System.out.println("===========项目汇启动成功===========");
        System.out.println("=================================");
    }
}
