package org.analysis.projects.ppp.mapper.auto;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.analysis.projects.ppp.model.auto.Tag;
import org.apache.ibatis.annotations.CacheNamespace;

/**
 * <p>
 * 标签信息表 Mapper 接口
 * </p>
 *
 * @author Feliz
 * @since 2020-03-30
 */
@CacheNamespace(flushInterval = 3600000, size = 4096)
public interface TagMapper extends BaseMapper<Tag> {

}
