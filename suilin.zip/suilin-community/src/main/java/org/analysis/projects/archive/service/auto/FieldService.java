package org.analysis.projects.archive.service.auto;

import org.analysis.projects.archive.model.auto.Field;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;

/**
 * <p>
 * 档案字段 服务类
 * </p>
 *
 * @author Feliz
 * @since 2019-09-10
 */
public interface FieldService extends IService<Field> {

    List<Field> listByIds(String ids);
}
