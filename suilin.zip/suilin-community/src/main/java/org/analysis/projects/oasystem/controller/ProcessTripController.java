package org.analysis.projects.oasystem.controller;


import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.analysis.projects.oasystem.model.auto.ProcessTrip;
import org.analysis.projects.oasystem.service.auto.ProcessTripService;
import org.analysis.system.common.base.BaseController;
import org.analysis.system.common.domain.AjaxResult;
import org.analysis.system.common.support.Convert;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * <p>
 * 出差申请 前端控制器
 * </p>
 *
 * @author Feliz
 * @since 2019-06-22
 */
@Api(tags = {"出差申请"})
@Controller
@RequestMapping("/oasystem/process-trip")
public class ProcessTripController extends BaseController {

    private static Logger logger = LoggerFactory.getLogger(ProcessTripController.class);

    @Autowired
    private ProcessTripService processTripService;

    //跳转页面参数
    private String prefix = "projects/oasystem/process/trip";

    @ApiOperation(value = "跳转出差申请页面", notes = "跳转出差申请页面", hidden = true)
    @GetMapping("/add")
    public String add() {
        return prefix + "/add";
    }

    @ApiOperation(value = "添加出差申请单", notes = "添加出差申请单")
    @PostMapping("add")
    @RequiresPermissions("oasystem:trip:add")
    @ResponseBody
    public AjaxResult add(ProcessTrip processTrip) {
        try {
            boolean save = processTripService.save(processTrip);
            return save ? success() : error();
        } catch (Exception e) {
            logger.error(ExceptionUtils.getFullStackTrace(e));
            return error();
        }
    }

    @ApiOperation(value = "删除出差申请单", notes = "根据id删除出差申请单（批量）")
    @PostMapping("remove")
    @RequiresPermissions("oasystem:trip:remove")
    @ResponseBody
    public AjaxResult remove(String ids) {
        List<String> idList= Convert.toListStrArray(ids);
        boolean remove = processTripService.removeByIds(idList);
        return remove ? success() : error();
    }

    @ApiOperation(value = "跳转出差申请修改页面", notes = "跳转到出差申请修改页面", hidden = true)
    @GetMapping("/edit/{id}")
    public String edit(@PathVariable("id") String id, ModelMap mmap) {
        mmap.put("trip", processTripService.getById(id));
        return prefix + "/edit";
    }

    @ApiOperation(value = "修改出差申请单", notes = "修改保存出差申请单")
    @PostMapping("/edit")
    @RequiresPermissions("oasystem:trip:edit")
    @ResponseBody
    public AjaxResult editSave(ProcessTrip processTrip) {
        boolean b = processTripService.updateById(processTrip);
        return b ? success() : error();
    }
}

