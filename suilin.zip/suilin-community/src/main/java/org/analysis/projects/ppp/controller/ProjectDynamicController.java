package org.analysis.projects.ppp.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.analysis.projects.ppp.model.auto.ClientUser;
import org.analysis.projects.ppp.model.auto.Project;
import org.analysis.projects.ppp.model.auto.ProjectDynamic;
import org.analysis.projects.ppp.model.auto.ServerUser;
import org.analysis.projects.ppp.model.custom.ProjectDynamicVO;
import org.analysis.projects.ppp.service.auto.ClientUserService;
import org.analysis.projects.ppp.service.auto.ProjectDynamicService;
import org.analysis.projects.ppp.service.auto.ProjectService;
import org.analysis.projects.ppp.service.auto.ServerUserService;
import org.analysis.system.common.base.BaseController;
import org.analysis.system.common.domain.AjaxResult;
import org.analysis.system.common.domain.TableSplitResult;
import org.analysis.system.common.domain.Tablepar;
import org.analysis.system.common.log.Log;
import org.analysis.system.model.custom.TitleVo;
import org.analysis.system.util.StringUtils;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.ArrayList;
import java.util.List;


/**
 * <p>
 * 项目动态信息 前端控制器
 * </p>
 *
 * @author Feliz
 * @since 2020-04-05 14:33:57
 */
@Controller
@Api(tags = {"项目动态信息"})
@RequestMapping("/ppp/ProjectDynamicController")
public class ProjectDynamicController extends BaseController {

    private static Logger logger = LoggerFactory.getLogger(ProjectDynamicController.class);

    //跳转页面参数
    private String prefix = "projects/ppp/projectDynamic";

    @Autowired
    private ProjectDynamicService projectDynamicService;
    @Autowired
    private ProjectService projectService;
    @Autowired
    private ClientUserService clientUserService;
    @Autowired
    private ServerUserService serverUserService;

    //跳转项目动态信息页面
    @GetMapping("/view")
    @RequiresPermissions("ppp:projectDynamic:view")
    public String view(Model model) {
        String str = "项目动态信息";
        setTitle(model, new TitleVo(str + "列表", str + "管理", false, "欢迎进入" + str + "页面", false, false));
        return prefix + "/list";
    }

    @Log(title = "项目动态信息列表查询", action = "111")
    @ApiOperation(value = "获取项目动态信息列表", notes = "获取项目动态信息列表")
    @PostMapping("/list")
    @RequiresPermissions("ppp:projectDynamic:list")
    @ResponseBody
    public TableSplitResult<ProjectDynamicVO> list(Tablepar tablepar, String searchText) {

        QueryWrapper<ProjectDynamic> queryWrapper = new QueryWrapper<>();
        if (StringUtils.isNotEmpty(searchText)) {
            QueryWrapper<Project> projectQueryWrapper = new QueryWrapper<>();
            projectQueryWrapper.like("title", searchText);
            List<Project> list = projectService.list(projectQueryWrapper);

            if (list.size() > 0) {
                List<Integer> ids = new ArrayList<>();
                for (Project p : list) {
                    ids.add(p.getId());
                }
                queryWrapper.and(wrapper -> wrapper
                        .in("project_id", ids).or()
                );
            }else {
                return new TableSplitResult<ProjectDynamicVO>(0, 0L, new ArrayList<ProjectDynamicVO>());
            }
        }

        queryWrapper.orderByAsc("state","applicant_time");
        PageHelper.startPage(tablepar.getPageNum(), tablepar.getPageSize());
        List<ProjectDynamic> projectDynamics = projectDynamicService.list(queryWrapper);
        PageInfo<ProjectDynamic> pageInfo = new PageInfo<ProjectDynamic>(projectDynamics);

        List<ProjectDynamicVO> list = new ArrayList<>();
        for (ProjectDynamic pd : projectDynamics) {
            ProjectDynamicVO projectDynamicVO = new ProjectDynamicVO();

            try {
                BeanUtils.copyProperties(projectDynamicVO, pd);
            } catch (Exception e) {
                logger.error(e.getMessage());
            }

            Project project = projectService.getById(pd.getProjectId());
            projectDynamicVO.setProject((project != null) ? project : new Project());
            ClientUser applicantUser = clientUserService.getById(pd.getApplicantId());
            projectDynamicVO.setApplicantUser((applicantUser != null) ? applicantUser : new ClientUser());
            ServerUser replyUser = serverUserService.getById(pd.getReplyId());
            projectDynamicVO.setReplyUser((replyUser != null) ? replyUser : new ServerUser());

            list.add(projectDynamicVO);
        }

        return new TableSplitResult<>(pageInfo.getPageNum(), pageInfo.getTotal(), list);
    }

    @ApiOperation(value = "获取全部项目动态信息信息", notes = "获取全部项目动态信息信息")
    @PostMapping("/getAllProjectDynamic")
    @ResponseBody
    public AjaxResult<TableSplitResult<ProjectDynamic>> getAllProjectDynamic() {
        try {
            List<ProjectDynamic> list = projectDynamicService.list();
            return AjaxResult.successDataList(list);
        } catch (Exception e) {
            logger.error(e.toString());
            return AjaxResult.error(e.getMessage());
        }
    }

//    //跳转项目动态信息新增页面
//    @GetMapping("/add")
//    public String add() {
//        return prefix + "/add";
//    }
//
//    @Log(title = "项目动态信息新增", action = "111")
//    @ApiOperation(value = "添加项目动态信息", notes = "添加项目动态信息")
//    @PostMapping("add")
//    @RequiresPermissions("ppp:projectDynamic:add")
//    @ResponseBody
//    public AjaxResult add(ProjectDynamic projectDynamic) {
//
//        projectDynamic.setState(0);
//        projectDynamic.setApplicantTime(LocalDateTime.now());
//        boolean save = projectDynamicService.save(projectDynamic);
//        return save ? success() : error();
//    }
//
//    @Log(title = "项目动态信息删除", action = "111")
//    @ApiOperation(value = "删除项目动态信息", notes = "根据id删除项目动态信息（可批量）")
//    @PostMapping("/remove")
//    @RequiresPermissions("ppp:projectDynamic:remove")
//    @ResponseBody
//    public AjaxResult remove(String ids) {
//        List<Integer> idList = Convert.toListIntArray(ids);
//        boolean delete = projectDynamicService.removeByIds(idList);
//        return delete ? success() : error();
//    }
//
//    //跳转项目动态信息修改页面
//    @GetMapping("/edit/{id}")
//    public String edit(@PathVariable("id") Integer id, ModelMap modelMap) {
//        modelMap.put("projectDynamic", projectDynamicService.getById(id));
//        return prefix + "/edit";
//    }

//    @Log(title = "项目动态信息修改", action = "111")
//    @ApiOperation(value = "修改项目动态信息", notes = "修改项目动态信息")
//    @PostMapping("/edit")
//    @RequiresPermissions("ppp:projectDynamic:edit")
//    @ResponseBody
//    public AjaxResult editSave(ProjectDynamic projectDynamic) {
//
//        return invitation(projectDynamic);
//    }

//    @Log(title = "邀请面试", action = "111")
//    @ApiOperation(value = "邀请面试", notes = "邀请面试")
//    @PostMapping("/invitation")
//    @RequiresPermissions("ppp:projectDynamic:edit")
//    @ResponseBody
//    public AjaxResult invitation(ProjectDynamic projectDynamic) {
//
//        projectDynamic.setState(1);
//        boolean edit = projectDynamicService.updateById(projectDynamic);
//        return edit ? success() : error();
//    }
//
//    @Log(title = "拒绝面试", action = "111")
//    @ApiOperation(value = "拒绝面试", notes = "邀请面试")
//    @PostMapping("/refuse")
//    @RequiresPermissions("ppp:projectDynamic:edit")
//    @ResponseBody
//    public AjaxResult refuse(ProjectDynamic projectDynamic) {
//
//        projectDynamic.setState(2);
//        boolean edit = projectDynamicService.updateById(projectDynamic);
//        return edit ? success() : error();
//    }

}
