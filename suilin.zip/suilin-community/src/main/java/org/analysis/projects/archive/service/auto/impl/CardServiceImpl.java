package org.analysis.projects.archive.service.auto.impl;

import org.analysis.projects.archive.model.auto.Card;
import org.analysis.projects.archive.mapper.auto.CardMapper;
import org.analysis.projects.archive.service.auto.CardService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 档案卡片 服务实现类
 * </p>
 *
 * @author Feliz
 * @since 2019-09-10
 */
@Service
public class CardServiceImpl extends ServiceImpl<CardMapper, Card> implements CardService {

}
