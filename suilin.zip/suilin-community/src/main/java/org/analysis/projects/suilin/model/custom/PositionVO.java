package org.analysis.projects.suilin.model.custom;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableLogic;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.time.LocalDateTime;

@ApiModel(value="PositionVO对象", description="岗位信息")
public class PositionVO implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "业主id（suilin_owner）")
    @TableField("suilin_user_id")
    private Integer suilinUserId;

    @ApiModelProperty(value = "业主姓名")
    @TableField("owner_name")
    private String ownerName;

    @ApiModelProperty(value = "业主楼栋&房号")
    @TableField("owner_roomNumber")
    private String ownerRoomNumber;

    @ApiModelProperty(value = "业主手机")
    @TableField("owner_phone")
    private String ownerPhone;

    @ApiModelProperty(value = "职位")
    @TableField("position")
    private String position;

    @ApiModelProperty(value = "任期")
    @TableField("position_time")
    private Integer positionTime;

    @ApiModelProperty(value = "备注")
    @TableField("remark")
    private String remark;

    @ApiModelProperty(value = "逻辑删除；0：未删除；1：已删除")
    @TableField("deleted")
    @TableLogic
    private Integer deleted;

    @ApiModelProperty(value = "上任时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @TableField("create_time")
    private LocalDateTime createTime;

    @ApiModelProperty(value = "修改时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @TableField("update_time")
    private LocalDateTime updateTime;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getSuilinUserId() {
        return suilinUserId;
    }

    public void setSuilinUserId(Integer suilinUserId) {
        this.suilinUserId = suilinUserId;
    }

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public Integer getPositionTime() {
        return positionTime;
    }

    public void setPositionTime(Integer positionTime) {
        this.positionTime = positionTime;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public Integer getDeleted() {
        return deleted;
    }

    public void setDeleted(Integer deleted) {
        this.deleted = deleted;
    }

    public LocalDateTime getCreateTime() {
        return createTime;
    }

    public void setCreateTime(LocalDateTime createTime) {
        this.createTime = createTime;
    }

    public LocalDateTime getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(LocalDateTime updateTime) {
        this.updateTime = updateTime;
    }

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public String getOwnerName() {
        return ownerName;
    }

    public void setOwnerName(String ownerName) {
        this.ownerName = ownerName;
    }

    public String getOwnerRoomNumber() {
        return ownerRoomNumber;
    }

    public void setOwnerRoomNumber(String ownerRoomNumber) {
        this.ownerRoomNumber = ownerRoomNumber;
    }

    public String getOwnerPhone() {
        return ownerPhone;
    }

    public void setOwnerPhone(String ownerPhone) {
        this.ownerPhone = ownerPhone;
    }

    @Override
    public String toString() {
        return "PositionVO{" +
                "id=" + id +
                ", ownerId=" + suilinUserId +
                ", ownerName='" + ownerName + '\'' +
                ", ownerRoomNumber='" + ownerRoomNumber + '\'' +
                ", ownerPhone='" + ownerPhone + '\'' +
                ", position='" + position + '\'' +
                ", positionTime=" + positionTime +
                ", remark='" + remark + '\'' +
                ", deleted=" + deleted +
                ", createTime=" + createTime +
                ", updateTime=" + updateTime +
                '}';
    }
}
