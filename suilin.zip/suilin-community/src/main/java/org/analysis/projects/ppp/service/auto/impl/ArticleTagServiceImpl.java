package org.analysis.projects.ppp.service.auto.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.analysis.projects.ppp.mapper.auto.ArticleTagMapper;
import org.analysis.projects.ppp.model.auto.ArticleTag;
import org.analysis.projects.ppp.service.auto.ArticleTagService;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 文章标签中间表 服务实现类
 * </p>
 *
 * @author Feliz
 * @since 2020-03-29
 */
@Service
public class ArticleTagServiceImpl extends ServiceImpl<ArticleTagMapper, ArticleTag> implements ArticleTagService {


}
