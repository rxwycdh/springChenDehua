package org.analysis.projects.ppp.service.auto.impl;

import org.analysis.projects.ppp.model.auto.RotationChart;
import org.analysis.projects.ppp.mapper.auto.RotationChartMapper;
import org.analysis.projects.ppp.service.auto.RotationChartService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 轮播信息表 服务实现类
 * </p>
 *
 * @author Feliz
 * @since 2020-03-29
 */
@Service
public class RotationChartServiceImpl extends ServiceImpl<RotationChartMapper, RotationChart> implements RotationChartService {

}
