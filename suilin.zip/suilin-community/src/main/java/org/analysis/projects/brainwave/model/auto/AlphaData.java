package org.analysis.projects.brainwave.model.auto;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * <p>
 * alpha脑波数据表
 * </p>
 *
 * @author Feliz
 * @since 2019-06-06
 */
@TableName("brainwave_alpha_data")
@ApiModel(value="AlphaData对象", description="alpha脑波数据表")
public class AlphaData implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "id", required = true, example = "0", position = 1)
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "穿戴人", example = "0")
    @TableField("user_id")
    private Integer userId;

    @ApiModelProperty(value = "设备id", example = "0")
    @TableField("device_id")
    private Integer deviceId;

    @ApiModelProperty(value = "场景id", example = "0")
    @TableField("scene_id")
    private Integer sceneId;

    @ApiModelProperty(value = "时间戳")
    @TableField("time")
    private LocalDateTime time;

    @ApiModelProperty(value = "信号值", example = "200")
    @TableField("pq")
    private Integer pq;

    @TableField("low_alpha1")
    private Integer lowAlpha1;

    @TableField("low_alpha2")
    private Integer lowAlpha2;

    @TableField("low_alpha3")
    private Integer lowAlpha3;

    @TableField("high_alpha1")
    private Integer highAlpha1;

    @TableField("high_alpha2")
    private Integer highAlpha2;

    @TableField("high_alpha3")
    private Integer highAlpha3;

    @ApiModelProperty(value = "创建时间")
    @TableField("create_time")
    private LocalDateTime createTime;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public Integer getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(Integer deviceId) {
        this.deviceId = deviceId;
    }

    public Integer getSceneId() {
        return sceneId;
    }

    public void setSceneId(Integer sceneId) {
        this.sceneId = sceneId;
    }

    public LocalDateTime getTime() {
        return time;
    }

    public void setTime(LocalDateTime time) {
        this.time = time;
    }

    public Integer getPq() {
        return pq;
    }

    public void setPq(Integer pq) {
        this.pq = pq;
    }

    public Integer getLowAlpha1() {
        return lowAlpha1;
    }

    public void setLowAlpha1(Integer lowAlpha1) {
        this.lowAlpha1 = lowAlpha1;
    }

    public Integer getLowAlpha2() {
        return lowAlpha2;
    }

    public void setLowAlpha2(Integer lowAlpha2) {
        this.lowAlpha2 = lowAlpha2;
    }

    public Integer getLowAlpha3() {
        return lowAlpha3;
    }

    public void setLowAlpha3(Integer lowAlpha3) {
        this.lowAlpha3 = lowAlpha3;
    }

    public Integer getHighAlpha1() {
        return highAlpha1;
    }

    public void setHighAlpha1(Integer highAlpha1) {
        this.highAlpha1 = highAlpha1;
    }

    public Integer getHighAlpha2() {
        return highAlpha2;
    }

    public void setHighAlpha2(Integer highAlpha2) {
        this.highAlpha2 = highAlpha2;
    }

    public Integer getHighAlpha3() {
        return highAlpha3;
    }

    public void setHighAlpha3(Integer highAlpha3) {
        this.highAlpha3 = highAlpha3;
    }

    public LocalDateTime getCreateTime() {
        return createTime;
    }

    public void setCreateTime(LocalDateTime createTime) {
        this.createTime = createTime;
    }

    @Override
    public String toString() {
        return "AlphaData{" +
        "id=" + id +
        ", userId=" + userId +
        ", deviceId=" + deviceId +
        ", sceneId=" + sceneId +
        ", time=" + time +
        ", pq=" + pq +
        ", lowAlpha1=" + lowAlpha1 +
        ", lowAlpha2=" + lowAlpha2 +
        ", lowAlpha3=" + lowAlpha3 +
        ", highAlpha1=" + highAlpha1 +
        ", highAlpha2=" + highAlpha2 +
        ", highAlpha3=" + highAlpha3 +
        ", createTime=" + createTime +
        "}";
    }
}
