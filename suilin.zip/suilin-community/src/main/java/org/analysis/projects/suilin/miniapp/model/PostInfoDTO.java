package org.analysis.projects.suilin.miniapp.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.analysis.projects.suilin.model.auto.PostInfo;

/**
 * @author ChenDehua  597701764@qq.com
 * @date 2020/8/19 11:32
 */
@Getter
@Setter
@ToString
@ApiModel("小程序帖子详情")
public class PostInfoDTO extends PostInfo {

    @ApiModelProperty("用户是否已点赞")
    private Boolean isLike;
}
