package org.analysis.projects.brainwave;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * 脑波项目启动器
 */
@MapperScan(value = "org.analysis.projects.brainwave.mapper")
@SpringBootApplication
public class BrainwaveApplication {

    public static void main(String[] args) {
        SpringApplication.run(BrainwaveApplication.class, args);
        System.out.println("=================================");
        System.out.println("==========脑波项目启动成功==========");
        System.out.println("=================================");
    }
}
