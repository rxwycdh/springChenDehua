package org.analysis.projects.oasystem.service.auto;

import com.baomidou.mybatisplus.extension.service.IService;
import org.analysis.projects.oasystem.model.auto.LeaveNote;

/**
 * <p>
 * 请假说明 服务类
 * </p>
 *
 * @author Feliz
 * @since 2019-06-22
 */
public interface LeaveNoteService extends IService<LeaveNote> {

}
