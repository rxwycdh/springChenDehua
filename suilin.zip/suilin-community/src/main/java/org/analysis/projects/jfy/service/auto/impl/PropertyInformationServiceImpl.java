package org.analysis.projects.jfy.service.auto.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.analysis.projects.jfy.mapper.auto.PropertyInformationMapper;
import org.analysis.projects.jfy.model.auto.PropertyInformation;
import org.analysis.projects.jfy.service.auto.PropertyInformationService;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 业主决策物业信息表 服务实现类
 * </p>
 *
 * @author Feliz
 * @since 2019-07-03
 */
@Service
public class PropertyInformationServiceImpl extends ServiceImpl<PropertyInformationMapper, PropertyInformation> implements PropertyInformationService {

}
