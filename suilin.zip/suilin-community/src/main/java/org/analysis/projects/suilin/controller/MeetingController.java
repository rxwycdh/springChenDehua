package org.analysis.projects.suilin.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.analysis.projects.ppp.model.auto.Article;
import org.analysis.projects.ppp.model.custom.ArticleVO;
import org.analysis.projects.suilin.model.auto.Meeting;
import org.analysis.projects.suilin.service.auto.MeetingService;
import org.analysis.system.common.domain.AjaxResult;
import org.analysis.system.common.domain.TableSplitResult;
import org.analysis.system.common.domain.Tablepar;
import org.analysis.system.common.support.Convert;
import org.analysis.system.model.custom.TitleVo;
import org.analysis.system.util.StringUtils;
import org.analysis.system.common.log.Log;
import org.analysis.system.util.ExcelUtils;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.analysis.system.common.base.BaseController;

import java.time.LocalDateTime;
import javax.servlet.http.HttpServletResponse;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.*;


/**
 * <p>
 * 会议纪要 前端控制器
 * </p>
 *
 * @author Feliz
 * @since 2020-07-28 16:53:34
 */
@Controller
@Api(tags = {"会议纪要"})
@RequestMapping("/suilin/MeetingController")
public class MeetingController extends BaseController{

    private static Logger logger = LoggerFactory.getLogger(MeetingController.class);

    //跳转页面参数
    private String prefix = "projects/suilin/meeting";

	@Autowired
	private MeetingService meetingService;

	//跳转会议纪要页面
    @GetMapping("/view")
    @RequiresPermissions("suilin:meeting:view")
    public String view(Model model) {
        String str="会议纪要";
        setTitle(model, new TitleVo(str+"列表", str+"管理", false, "欢迎进入"+str+"页面", false, false));
        return prefix + "/list";
    }

    @Log(title = "会议纪要列表查询", action = "111")
    @ApiOperation(value = "获取会议纪要列表", notes = "获取会议纪要列表")
    @PostMapping("/list")
    @RequiresPermissions("suilin:meeting:list")
    @ResponseBody
    public TableSplitResult<Meeting> list(Tablepar tablepar, String searchText) {

        QueryWrapper<Meeting> queryWrapper = new QueryWrapper<>();
        if (StringUtils.isNotEmpty(searchText)) {
            queryWrapper.and(wrapper -> wrapper
                    .like("id", searchText).or()
                    .like("title", searchText).or()
                    .like("place", searchText).or()
                    .like("participate", searchText).or()
                    .like("meeting_record", searchText).or()
                    .like("attachment_file_id", searchText).or()
                    .like("meeting_time", searchText).or()
            );
        }

        PageHelper.startPage(tablepar.getPageNum(), tablepar.getPageSize());
        List<Meeting> list = meetingService.list(queryWrapper);
        PageInfo<Meeting> pageInfo = new PageInfo<Meeting>(list);

        return new TableSplitResult<>(pageInfo.getPageNum(), pageInfo.getTotal(), pageInfo.getList());
    }

    @ApiOperation(value = "获取全部会议纪要信息", notes = "获取全部会议纪要信息")
    @PostMapping("/getAllMeeting")
    @ResponseBody
    public AjaxResult<TableSplitResult<Meeting>> getAllMeeting() {
        try {
            List<Meeting> list = meetingService.list();
            return AjaxResult.successDataList(list);
        } catch (Exception e) {
            logger.error(e.toString());
            return AjaxResult.error(e.getMessage());
        }
    }

    //跳转会议纪要新增页面
    @GetMapping("/add")
    public String add() {
        return prefix + "/add";
    }

    @Log(title = "会议纪要新增", action = "111")
    @ApiOperation(value = "添加会议纪要", notes = "添加会议纪要")
    @PostMapping("add")
    @RequiresPermissions("suilin:meeting:add")
    @ResponseBody
    public AjaxResult add(Meeting meeting) {
        meeting.setCreateTime(LocalDateTime.now());
        boolean save = meetingService.save(meeting);
        return save ? success() : error();
    }

    @Log(title = "会议纪要删除", action = "111")
    @ApiOperation(value = "删除会议纪要", notes = "根据id删除会议纪要（可批量）")
    @PostMapping("/remove")
    @RequiresPermissions("suilin:meeting:remove")
    @ResponseBody
    public AjaxResult remove(String ids) {
        List<Integer> idList= Convert.toListIntArray(ids);
        boolean delete = meetingService.removeByIds(idList);
        return delete ? success() : error();
    }

    @ApiOperation(value = "检查会议纪要是否存在", notes = "返回: 1-存在; 0-不存在")
    @PostMapping("/checkUnique")
    @ResponseBody
    public Integer checkUnique(Meeting meeting) {
        QueryWrapper<Meeting> queryWrapper = new QueryWrapper<>();
        //TODO 注意是否正确，默认检测name字段
        //queryWrapper.eq("name", meeting.getName());
        List<Meeting> list = meetingService.list(queryWrapper);
        if (list.size() > 0) {
            return 1;
        } else {
            return 0;
        }
    }

    //跳转会议纪要修改页面
    @GetMapping("/edit/{id}")
    public String edit(@PathVariable("id") Integer id, ModelMap modelMap) {
        modelMap.put("meeting", meetingService.getById(id));
        return prefix + "/edit";
    }

    @Log(title = "会议纪要修改", action = "111")
    @ApiOperation(value = "修改会议纪要", notes = "修改会议纪要")
    @PostMapping("/edit")
    @RequiresPermissions("suilin:meeting:edit")
    @ResponseBody
    public AjaxResult editSave(Meeting meeting) {
        meeting.setUpdateTime(LocalDateTime.now());
        boolean edit = meetingService.updateById(meeting);
        return edit ? success() : error();
    }


    //跳转会议纪要批量新增页面
    @GetMapping("/batchAdd")
    public String batchAdd() {
        return prefix + "/batchAdd";
    }

    @Log(title = "会议纪要批量导入", action = "111")
    @ApiOperation(value = "批量导入会议纪要", notes = "批量导入会议纪要")
    @RequiresPermissions("suilin:meeting:add")
    @Transactional(propagation = Propagation.REQUIRED)
    @PostMapping("/batchAdd")
    @ResponseBody
    public AjaxResult batchAdd(@RequestParam(value = "file", required = false) MultipartFile file) {
        try {
            String suffer = file.getOriginalFilename().substring(file.getOriginalFilename().indexOf(".") + 1);
            if ("xls".equals(suffer) || "xlsx".equals(suffer)) {
                InputStream in = file.getInputStream();
                Map<String, String> fields = new LinkedHashMap<String, String>();

                fields.put("主题", "title");
                fields.put("地点", "place");
                fields.put("参会人员", "participate");
                fields.put("会议记录", "meetingRecord");
                fields.put("会议附件file_id", "attachmentFileId");
                fields.put("开会时间", "meetingTime");

                List<Meeting> list = new ArrayList<Meeting>();
                list = ExcelUtils.ExecltoList(in, Meeting.class, fields);

                int sum = list.size();//总需导入数
                int successNum = 0;//成功导入数
                int failNum = 0;//失败导入数
                for (Meeting o : list) {

                    if (checkUnique(o) == 0) {
                        add(o);
                        successNum++;
                    }else {
                        failNum++;
                    }
                }

                return success("总需导入数：" + sum + "</br>成功导入数：" + successNum +" </br>失败导入数：" + failNum);
            }
            return error("上传文件格式应为xls或xlsx");

        } catch (Exception e) {
            logger.error(ExceptionUtils.getFullStackTrace(e));
            return error("上传文件模板有误，请对比导入模板！");
        }
    }

    @Log(title = "会议纪要导入模板获取", action = "111")
    @GetMapping("/getExcelModel")
    @ResponseBody
    public void getUserCardExcelModel(HttpServletResponse response) throws Exception {
        OutputStream out = null;
        //通过response对象获取outputStream流
        response.setContentType("application/octect-stream"); // 下载文件能正常显示中文
        response.setHeader("Content-Disposition", "attachment;filename=" + new String(("会议纪要的导入模板.xls").getBytes("gb2312"), "ISO8859-1"));
        out = response.getOutputStream();

        Map<String, String> fields = new LinkedHashMap<String, String>();

        fields.put("title", "主题");
        fields.put("place", "地点");
        fields.put("participate", "参会人员");
        fields.put("meetingRecord", "会议记录");
        fields.put("attachmentFileId", "会议附件file_id");
        fields.put("meetingTime", "开会时间");

        ExcelUtils.ListtoExecl(null, out, fields);
        out.flush();
        out.close();
    }
    @GetMapping("/detail/{id}")
    public String detail(@PathVariable("id") Integer id, ModelMap modelMap) {
        modelMap.put("meeting", meetingService.getById(id));
        return prefix + "/detail";
    }

	
}
