package org.analysis.projects.suilin.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.analysis.projects.suilin.model.auto.Owner;
import org.analysis.projects.suilin.model.auto.Position;
import org.analysis.projects.suilin.model.custom.PositionVO;
import org.analysis.projects.suilin.service.auto.OwnerService;
import org.analysis.projects.suilin.service.auto.PositionService;
import org.analysis.system.common.domain.AjaxResult;
import org.analysis.system.common.domain.TableSplitResult;
import org.analysis.system.common.domain.Tablepar;
import org.analysis.system.common.support.Convert;
import org.analysis.system.model.custom.TitleVo;
import org.analysis.system.util.StringUtils;
import org.analysis.system.common.log.Log;
import org.analysis.system.util.ExcelUtils;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.analysis.system.common.base.BaseController;

import java.time.LocalDateTime;
import javax.servlet.http.HttpServletResponse;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.*;


/**
 * <p>
 * 岗位信息 前端控制器
 * </p>
 *
 * @author Feliz
 * @since 2020-07-28 16:53:34
 */
@Controller
@Api(tags = {"岗位信息"})
@RequestMapping("/suilin/PositionController")
public class PositionController extends BaseController{

    private static Logger logger = LoggerFactory.getLogger(PositionController.class);

    //跳转页面参数
    private String prefix = "projects/suilin/position";

	@Autowired
	private PositionService positionService;
    @Autowired
    private OwnerService ownerService;

	//跳转岗位信息页面
    @GetMapping("/view")
    @RequiresPermissions("suilin:position:view")
    public String view(Model model) {
        String str="岗位信息";
        setTitle(model, new TitleVo(str+"列表", str+"管理", false, "欢迎进入"+str+"页面", false, false));
        return prefix + "/list";
    }

    @Log(title = "岗位信息列表查询", action = "111")
    @ApiOperation(value = "获取岗位信息列表", notes = "获取岗位信息列表")
    @PostMapping("/list")
    @RequiresPermissions("suilin:position:list")
    @ResponseBody
    public TableSplitResult<PositionVO> list(Tablepar tablepar, String searchText) {

        QueryWrapper<Position> queryWrapper = new QueryWrapper<>();
        if (StringUtils.isNotEmpty(searchText)) {
            queryWrapper.and(wrapper -> wrapper
                    .like("id", searchText).or()
                    .like("suilin_user_id", searchText).or()
                    .like("position", searchText).or()
                    .like("position_time", searchText).or()
                    .like("remark", searchText).or()
            );
        }

        PageHelper.startPage(tablepar.getPageNum(), tablepar.getPageSize());
        List<Position> positionList = positionService.list(queryWrapper);
        PageInfo<Position> pageInfo = new PageInfo<Position>(positionList);
        List<PositionVO> list = new ArrayList<>();
            for (Position position : positionList) {
                PositionVO positionVO = new PositionVO();
            try {
                BeanUtils.copyProperties(positionVO,position);
            } catch (Exception e) {
                logger.error(e.getMessage());
            }

            if (position.getSuilinUserId() != null) {
                Owner owner = ownerService.getById(position.getSuilinUserId());
                positionVO.setOwnerName(owner.getName());
                positionVO.setOwnerRoomNumber(owner.getRoomNumber());
                positionVO.setOwnerPhone(owner.getPhone());
            }
            list.add(positionVO);
                
        }

        return new TableSplitResult<>(pageInfo.getPageNum(), pageInfo.getTotal(), list);
    }

    @ApiOperation(value = "获取全部岗位信息信息", notes = "获取全部岗位信息信息")
    @PostMapping("/getAllPosition")
    @ResponseBody
    public AjaxResult<TableSplitResult<Position>> getAllPosition() {
        try {
            List<Position> list = positionService.list();
            return AjaxResult.successDataList(list);
        } catch (Exception e) {
            logger.error(e.toString());
            return AjaxResult.error(e.getMessage());
        }
    }

    //跳转岗位信息新增页面
    @GetMapping("/add")
    public String add() {
        return prefix + "/add";
    }

    @Log(title = "岗位信息新增", action = "111")
    @ApiOperation(value = "添加岗位信息", notes = "添加岗位信息")
    @PostMapping("add")
    @RequiresPermissions("suilin:position:add")
    @ResponseBody
    public AjaxResult add(Position position) {
        position.setCreateTime(LocalDateTime.now());
        boolean save = positionService.save(position);
        return save ? success() : error();
    }

    @Log(title = "岗位信息删除", action = "111")
    @ApiOperation(value = "删除岗位信息", notes = "根据id删除岗位信息（可批量）")
    @PostMapping("/remove")
    @RequiresPermissions("suilin:position:remove")
    @ResponseBody
    public AjaxResult remove(String ids) {
        List<Integer> idList= Convert.toListIntArray(ids);
        boolean delete = positionService.removeByIds(idList);
        return delete ? success() : error();
    }

    @ApiOperation(value = "检查岗位信息是否存在", notes = "返回: 1-存在; 0-不存在")
    @PostMapping("/checkUnique")
    @ResponseBody
    public Integer checkUnique(Position position) {
        QueryWrapper<Position> queryWrapper = new QueryWrapper<>();
        //TODO 注意是否正确，默认检测name字段
        //queryWrapper.eq("name", position.getName());
        List<Position> list = positionService.list(queryWrapper);
        if (list.size() > 0) {
            return 1;
        } else {
            return 0;
        }
    }

    //跳转岗位信息修改页面
    @GetMapping("/edit/{id}")
    public String edit(@PathVariable("id") Integer id, ModelMap modelMap) {
        modelMap.put("position", positionService.getById(id));
        return prefix + "/edit";
    }

    @Log(title = "岗位信息修改", action = "111")
    @ApiOperation(value = "修改岗位信息", notes = "修改岗位信息")
    @PostMapping("/edit")
    @RequiresPermissions("suilin:position:edit")
    @ResponseBody
    public AjaxResult editSave(Position position) {
        position.setUpdateTime(LocalDateTime.now());
        boolean edit = positionService.updateById(position);
        return edit ? success() : error();
    }


    //跳转岗位信息批量新增页面
    @GetMapping("/batchAdd")
    public String batchAdd() {
        return prefix + "/batchAdd";
    }

    @Log(title = "岗位信息批量导入", action = "111")
    @ApiOperation(value = "批量导入岗位信息", notes = "批量导入岗位信息")
    @RequiresPermissions("suilin:position:add")
    @Transactional(propagation = Propagation.REQUIRED)
    @PostMapping("/batchAdd")
    @ResponseBody
    public AjaxResult batchAdd(@RequestParam(value = "file", required = false) MultipartFile file) {
        try {
            String suffer = file.getOriginalFilename().substring(file.getOriginalFilename().indexOf(".") + 1);
            if ("xls".equals(suffer) || "xlsx".equals(suffer)) {
                InputStream in = file.getInputStream();
                Map<String, String> fields = new LinkedHashMap<String, String>();

                fields.put("业主id（suilin_owner）", "suilinUserId");
                fields.put("职位", "position");
                fields.put("任期", "positionTime");
                fields.put("备注", "remark");

                List<Position> list = new ArrayList<Position>();
                list = ExcelUtils.ExecltoList(in, Position.class, fields);

                int sum = list.size();//总需导入数
                int successNum = 0;//成功导入数
                int failNum = 0;//失败导入数
                for (Position o : list) {

                    if (checkUnique(o) == 0) {
                        add(o);
                        successNum++;
                    }else {
                        failNum++;
                    }
                }

                return success("总需导入数：" + sum + "</br>成功导入数：" + successNum +" </br>失败导入数：" + failNum);
            }
            return error("上传文件格式应为xls或xlsx");

        } catch (Exception e) {
            logger.error(ExceptionUtils.getFullStackTrace(e));
            return error("上传文件模板有误，请对比导入模板！");
        }
    }

    @Log(title = "岗位信息导入模板获取", action = "111")
    @GetMapping("/getExcelModel")
    @ResponseBody
    public void getUserCardExcelModel(HttpServletResponse response) throws Exception {
        OutputStream out = null;
        //通过response对象获取outputStream流
        response.setContentType("application/octect-stream"); // 下载文件能正常显示中文
        response.setHeader("Content-Disposition", "attachment;filename=" + new String(("岗位信息的导入模板.xls").getBytes("gb2312"), "ISO8859-1"));
        out = response.getOutputStream();

        Map<String, String> fields = new LinkedHashMap<String, String>();

        fields.put("suilinUserId", "业主id（suilin_owner）");
        fields.put("position", "职位");
        fields.put("positionTime", "任期");
        fields.put("remark", "备注");

        ExcelUtils.ListtoExecl(null, out, fields);
        out.flush();
        out.close();
    }

	
}
