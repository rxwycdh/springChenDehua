package org.analysis.projects.suilin.service.auto.impl;

import org.analysis.projects.suilin.model.auto.Community;
import org.analysis.projects.suilin.mapper.auto.CommunityMapper;
import org.analysis.projects.suilin.service.auto.CommunityService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 小区信息 服务实现类
 * </p>
 *
 * @author Feliz
 * @since 2020-07-28
 */
@Service
public class CommunityServiceImpl extends ServiceImpl<CommunityMapper, Community> implements CommunityService {

}
