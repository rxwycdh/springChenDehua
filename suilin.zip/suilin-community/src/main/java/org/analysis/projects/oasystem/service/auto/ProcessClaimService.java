package org.analysis.projects.oasystem.service.auto;

import com.baomidou.mybatisplus.extension.service.IService;
import org.analysis.projects.oasystem.model.auto.ProcessClaim;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author Feliz
 * @since 2019-06-21
 */
public interface ProcessClaimService extends IService<ProcessClaim> {

}
