package org.analysis.projects.suilin.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.analysis.projects.suilin.model.auto.PostComment;
import org.analysis.projects.suilin.service.auto.PostCommentService;
import org.analysis.system.common.domain.AjaxResult;
import org.analysis.system.common.domain.TableSplitResult;
import org.analysis.system.common.domain.Tablepar;
import org.analysis.system.common.support.Convert;
import org.analysis.system.model.custom.TitleVo;
import org.analysis.system.util.StringUtils;
import org.analysis.system.common.log.Log;
import org.analysis.system.util.ExcelUtils;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.analysis.system.common.base.BaseController;

import java.time.LocalDateTime;
import javax.servlet.http.HttpServletResponse;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.*;


/**
 * <p>
 * 帖子评论表 前端控制器
 * </p>
 *
 * @author Feliz
 * @since 2020-08-19 11:05:17
 */
@Controller
@Api(tags = {"帖子评论表"})
@RequestMapping("/suilin/PostCommentController")
public class PostCommentController extends BaseController{

    private static Logger logger = LoggerFactory.getLogger(PostCommentController.class);

    //跳转页面参数
    private String prefix = "projects/suilin/postComment";

	@Autowired
	private PostCommentService postCommentService;

	//跳转帖子评论表页面
    @GetMapping("/view")
    @RequiresPermissions("suilin:postComment:view")
    public String view(Model model) {
        String str="帖子评论表";
        setTitle(model, new TitleVo(str+"列表", str+"管理", false, "欢迎进入"+str+"页面", false, false));
        return prefix + "/list";
    }

    @Log(title = "帖子评论表列表查询", action = "111")
    @ApiOperation(value = "获取帖子评论表列表", notes = "获取帖子评论表列表")
    @PostMapping("/list")
    @RequiresPermissions("suilin:postComment:list")
    @ResponseBody
    public TableSplitResult<PostComment> list(Tablepar tablepar, String searchText) {

        QueryWrapper<PostComment> queryWrapper = new QueryWrapper<>();
        if (StringUtils.isNotEmpty(searchText)) {
            queryWrapper.and(wrapper -> wrapper
                    .like("id", searchText).or()
                    .like("post_info_id", searchText).or()
                    .like("suilin_user_id", searchText).or()
                    .like("like_user", searchText).or()
                    .like("like_count", searchText).or()
                    .like("reply_count", searchText).or()
                    .like("comment", searchText).or()
            );
        }

        PageHelper.startPage(tablepar.getPageNum(), tablepar.getPageSize());
        List<PostComment> list = postCommentService.list(queryWrapper);
        PageInfo<PostComment> pageInfo = new PageInfo<PostComment>(list);

        return new TableSplitResult<>(pageInfo.getPageNum(), pageInfo.getTotal(), pageInfo.getList());
    }

    @ApiOperation(value = "获取全部帖子评论表信息", notes = "获取全部帖子评论表信息")
    @PostMapping("/getAllPostComment")
    @ResponseBody
    public AjaxResult<TableSplitResult<PostComment>> getAllPostComment() {
        try {
            List<PostComment> list = postCommentService.list();
            return AjaxResult.successDataList(list);
        } catch (Exception e) {
            logger.error(e.toString());
            return AjaxResult.error(e.getMessage());
        }
    }

    //跳转帖子评论表新增页面
    @GetMapping("/add")
    public String add() {
        return prefix + "/add";
    }

    @Log(title = "帖子评论表新增", action = "111")
    @ApiOperation(value = "添加帖子评论表", notes = "添加帖子评论表")
    @PostMapping("add")
    @RequiresPermissions("suilin:postComment:add")
    @ResponseBody
    public AjaxResult add(PostComment postComment) {
        postComment.setCreateTime(LocalDateTime.now());
        boolean save = postCommentService.save(postComment);
        return save ? success() : error();
    }

    @Log(title = "帖子评论表删除", action = "111")
    @ApiOperation(value = "删除帖子评论表", notes = "根据id删除帖子评论表（可批量）")
    @PostMapping("/remove")
    @RequiresPermissions("suilin:postComment:remove")
    @ResponseBody
    public AjaxResult remove(String ids) {
        List<Integer> idList= Convert.toListIntArray(ids);
        boolean delete = postCommentService.removeByIds(idList);
        return delete ? success() : error();
    }

    @ApiOperation(value = "检查帖子评论表是否存在", notes = "返回: 1-存在; 0-不存在")
    @PostMapping("/checkUnique")
    @ResponseBody
    public Integer checkUnique(PostComment postComment) {
        QueryWrapper<PostComment> queryWrapper = new QueryWrapper<>();
        //TODO 注意是否正确，默认检测name字段
        //queryWrapper.eq("name", postComment.getName());
        List<PostComment> list = postCommentService.list(queryWrapper);
        if (list.size() > 0) {
            return 1;
        } else {
            return 0;
        }
    }

    //跳转帖子评论表修改页面
    @GetMapping("/edit/{id}")
    public String edit(@PathVariable("id") Integer id, ModelMap modelMap) {
        modelMap.put("postComment", postCommentService.getById(id));
        return prefix + "/edit";
    }

    @Log(title = "帖子评论表修改", action = "111")
    @ApiOperation(value = "修改帖子评论表", notes = "修改帖子评论表")
    @PostMapping("/edit")
    @RequiresPermissions("suilin:postComment:edit")
    @ResponseBody
    public AjaxResult editSave(PostComment postComment) {
        postComment.setUpdateTime(LocalDateTime.now());
        boolean edit = postCommentService.updateById(postComment);
        return edit ? success() : error();
    }


    //跳转帖子评论表批量新增页面
    @GetMapping("/batchAdd")
    public String batchAdd() {
        return prefix + "/batchAdd";
    }

    @Log(title = "帖子评论表批量导入", action = "111")
    @ApiOperation(value = "批量导入帖子评论表", notes = "批量导入帖子评论表")
    @RequiresPermissions("suilin:postComment:add")
    @Transactional(propagation = Propagation.REQUIRED)
    @PostMapping("/batchAdd")
    @ResponseBody
    public AjaxResult batchAdd(@RequestParam(value = "file", required = false) MultipartFile file) {
        try {
            String suffer = file.getOriginalFilename().substring(file.getOriginalFilename().indexOf(".") + 1);
            if ("xls".equals(suffer) || "xlsx".equals(suffer)) {
                InputStream in = file.getInputStream();
                Map<String, String> fields = new LinkedHashMap<String, String>();

                fields.put("所属帖子编号", "postInfoId");
                fields.put("用户号", "suilinUserId");
                fields.put("点赞用户好，按照逗号隔开", "likeUser");
                fields.put("点赞数", "likeCount");
                fields.put("评论回复数", "replyCount");
                fields.put("评论内容", "comment");

                List<PostComment> list = new ArrayList<PostComment>();
                list = ExcelUtils.ExecltoList(in, PostComment.class, fields);

                int sum = list.size();//总需导入数
                int successNum = 0;//成功导入数
                int failNum = 0;//失败导入数
                for (PostComment o : list) {

                    if (checkUnique(o) == 0) {
                        add(o);
                        successNum++;
                    }else {
                        failNum++;
                    }
                }

                return success("总需导入数：" + sum + "</br>成功导入数：" + successNum +" </br>失败导入数：" + failNum);
            }
            return error("上传文件格式应为xls或xlsx");

        } catch (Exception e) {
            logger.error(ExceptionUtils.getFullStackTrace(e));
            return error("上传文件模板有误，请对比导入模板！");
        }
    }

    @Log(title = "帖子评论表导入模板获取", action = "111")
    @GetMapping("/getExcelModel")
    @ResponseBody
    public void getUserCardExcelModel(HttpServletResponse response) throws Exception {
        OutputStream out = null;
        //通过response对象获取outputStream流
        response.setContentType("application/octect-stream"); // 下载文件能正常显示中文
        response.setHeader("Content-Disposition", "attachment;filename=" + new String(("帖子评论表的导入模板.xls").getBytes("gb2312"), "ISO8859-1"));
        out = response.getOutputStream();

        Map<String, String> fields = new LinkedHashMap<String, String>();

        fields.put("postInfoId", "所属帖子编号");
        fields.put("suilinUserId", "用户号");
        fields.put("likeUser", "点赞用户好，按照逗号隔开");
        fields.put("likeCount", "点赞数");
        fields.put("replyCount", "评论回复数");
        fields.put("comment", "评论内容");

        ExcelUtils.ListtoExecl(null, out, fields);
        out.flush();
        out.close();
    }

	
}
