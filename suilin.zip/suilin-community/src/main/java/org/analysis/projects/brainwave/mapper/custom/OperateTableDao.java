package org.analysis.projects.brainwave.mapper.custom;

import com.baomidou.dynamic.datasource.annotation.DS;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

/**
 * 数据表操作
 */
@Mapper
@DS("db_brainwave")
public interface OperateTableDao {

    @Update({"CREATE TABLE `{tableName}`  (\n" +
            "  `id` int(11) NOT NULL AUTO_INCREMENT,\n" +
            "  `user_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '穿戴人',\n" +
            "  `raw_data` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '原始数据',\n" +
            "  `time` datetime(0) NULL DEFAULT NULL COMMENT '时间戳',\n" +
            "  PRIMARY KEY (`id`) USING BTREE\n" +
            ") ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '原始脑波数据表' ROW_FORMAT = Compact;"})
    void createTodolist(@Param("tableName") String tableName);

    @Update({"drop table if exists ${tableName}"})
    void dropExistTable(@Param("tableName") String tableName);

    @Select({"select count(*) from all_tables where table_name=${tableName}"})
    int countTable(@Param("tableName") String tableName);

}
