package org.analysis.projects.suilin.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.analysis.projects.suilin.model.auto.Examine;
import org.analysis.projects.suilin.model.auto.Owner;
import org.analysis.projects.suilin.service.auto.ExamineService;
import org.analysis.projects.suilin.service.auto.OwnerService;
import org.analysis.system.common.domain.AjaxResult;
import org.analysis.system.common.domain.TableSplitResult;
import org.analysis.system.common.domain.Tablepar;
import org.analysis.system.common.support.Convert;
import org.analysis.system.model.custom.TitleVo;
import org.analysis.system.util.StringUtils;
import org.analysis.system.common.log.Log;
import org.analysis.system.util.ExcelUtils;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.analysis.system.common.base.BaseController;

import java.time.LocalDateTime;
import javax.servlet.http.HttpServletResponse;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.*;


/**
 * <p>
 * 审核信息 前端控制器
 * </p>
 *
 * @author Feliz
 * @since 2020-07-28 16:53:34
 */
@Controller
@Api(tags = {"审核信息"})
@RequestMapping("/suilin/ExamineController")
public class ExamineController extends BaseController{

    private static Logger logger = LoggerFactory.getLogger(ExamineController.class);

    //跳转页面参数
    private String prefix = "projects/suilin/examine";

	@Autowired
	private ExamineService examineService;

    @Autowired
    private OwnerService ownerService;

	//跳转审核信息页面
    @GetMapping("/view")
    @RequiresPermissions("suilin:examine:view")
    public String view(Model model) {
        String str="审核信息";
        setTitle(model, new TitleVo(str+"列表", str+"管理", false, "欢迎进入"+str+"页面", false, false));
        return prefix + "/list";
    }

    @Log(title = "审核信息列表查询", action = "111")
    @ApiOperation(value = "获取审核信息列表", notes = "获取审核信息列表")
    @PostMapping("/list")
    @RequiresPermissions("suilin:examine:list")
    @ResponseBody
    public TableSplitResult<Examine> list(Tablepar tablepar, String searchText) {

        QueryWrapper<Examine> queryWrapper = new QueryWrapper<>();
        if (StringUtils.isNotEmpty(searchText)) {
            queryWrapper.and(wrapper -> wrapper
                    .like("id", searchText).or()
                    .like("suilin_user_id", searchText).or()
                    .like("name", searchText).or()
                    .like("certification_type", searchText).or()
                    .like("state", searchText).or()
                    .like("id_card_type", searchText).or()
                    .like("id_card", searchText).or()
                    .like("id_card_file_id", searchText).or()
                    .like("property_file_id", searchText).or()
                    .like("room_number", searchText).or()
                    .like("room_area", searchText).or()
                    .like("is_party_member", searchText).or()
                    .like("examine_opinion", searchText).or()
            );
        }

        PageHelper.startPage(tablepar.getPageNum(), tablepar.getPageSize());
        List<Examine> list = examineService.list(queryWrapper);
        PageInfo<Examine> pageInfo = new PageInfo<Examine>(list);

        return new TableSplitResult<>(pageInfo.getPageNum(), pageInfo.getTotal(), pageInfo.getList());
    }

    @ApiOperation(value = "获取全部审核信息信息", notes = "获取全部审核信息信息")
    @PostMapping("/getAllExamine")
    @ResponseBody
    public AjaxResult<TableSplitResult<Examine>> getAllExamine() {
        try {
            List<Examine> list = examineService.list();
            return AjaxResult.successDataList(list);
        } catch (Exception e) {
            logger.error(e.toString());
            return AjaxResult.error(e.getMessage());
        }
    }

    //跳转审核信息新增页面
    @GetMapping("/add")
    public String add() {
        return prefix + "/add";
    }

    @Log(title = "审核信息新增", action = "111")
    @ApiOperation(value = "添加审核信息", notes = "添加审核信息")
    @PostMapping("add")
    @RequiresPermissions("suilin:examine:add")
    @ResponseBody
    public AjaxResult add(Examine examine) {
        examine.setCreateTime(LocalDateTime.now());
        boolean save = examineService.save(examine);
        return save ? success() : error();
    }

    @Log(title = "审核信息删除", action = "111")
    @ApiOperation(value = "删除审核信息", notes = "根据id删除审核信息（可批量）")
    @PostMapping("/remove")
    @RequiresPermissions("suilin:examine:remove")
    @ResponseBody
    public AjaxResult remove(String ids) {
        List<Integer> idList= Convert.toListIntArray(ids);
        boolean delete = examineService.removeByIds(idList);
        return delete ? success() : error();
    }

    @ApiOperation(value = "检查审核信息是否存在", notes = "返回: 1-存在; 0-不存在")
    @PostMapping("/checkUnique")
    @ResponseBody
    public Integer checkUnique(Examine examine) {
        QueryWrapper<Examine> queryWrapper = new QueryWrapper<>();
        //TODO 注意是否正确，默认检测name字段
        //queryWrapper.eq("name", examine.getName());
        List<Examine> list = examineService.list(queryWrapper);
        if (list.size() > 0) {
            return 1;
        } else {
            return 0;
        }
    }

    //跳转审核信息修改页面
    @GetMapping("/edit/{id}")
    public String edit(@PathVariable("id") Integer id, ModelMap modelMap) {
        modelMap.put("examine", examineService.getById(id));
        return prefix + "/edit";
    }

    //跳转审核信息详情
    @GetMapping("/detail/{id}")
    public String detail(@PathVariable("id") Integer id, ModelMap modelMap) {
        modelMap.put("examine", examineService.getById(id));
        return prefix + "/detail";
    }

    @Log(title = "审核信息", action = "111")
    @ApiOperation(value = "审核信息", notes = "审核信息")
    @PostMapping("/edit")
    @RequiresPermissions("suilin:examine:edit")
    @ResponseBody
    public AjaxResult editSave(Examine examine, Owner owner) {
        examine.setUpdateTime(LocalDateTime.now());
        boolean edit = examineService.updateById(examine);
        if (examine.getState() == 1) {
            Examine examine1 = examineService.getById(examine.getId());
            owner.setSuilinUserId(examine1.getSuilinUserId());
            owner.setName(examine1.getName());
            owner.setIdCardType(examine1.getIdCardType());
            owner.setIdCard(examine1.getIdCard());
            owner.setIdCardFileId(examine1.getIdCardFileId());
            owner.setPropertyFileId(examine1.getPropertyFileId());
            owner.setRoomNumber(examine1.getRoomNumber());
            owner.setRoomArea(examine1.getRoomArea());
            owner.setCreateTime(LocalDateTime.now());
            ownerService.save(owner);
        }
        return edit ? success() : error();
    }


    //跳转审核信息批量新增页面
    @GetMapping("/batchAdd")
    public String batchAdd() {
        return prefix + "/batchAdd";
    }

    @Log(title = "审核信息批量导入", action = "111")
    @ApiOperation(value = "批量导入审核信息", notes = "批量导入审核信息")
    @RequiresPermissions("suilin:examine:add")
    @Transactional(propagation = Propagation.REQUIRED)
    @PostMapping("/batchAdd")
    @ResponseBody
    public AjaxResult batchAdd(@RequestParam(value = "file", required = false) MultipartFile file) {
        try {
            String suffer = file.getOriginalFilename().substring(file.getOriginalFilename().indexOf(".") + 1);
            if ("xls".equals(suffer) || "xlsx".equals(suffer)) {
                InputStream in = file.getInputStream();
                Map<String, String> fields = new LinkedHashMap<String, String>();

                fields.put("用户id", "suilinUserId");
                fields.put("姓名", "name");
                fields.put("认证类型", "certificationType");
                fields.put("审核状态；0：未审核；1：已通过；2：未通过", "state");
                fields.put("证件类型", "idCardType");
                fields.put("身份证号", "idCard");
                fields.put("身份证照file-id", "idCardFileId");
                fields.put("房产证照file-id", "propertyFileId");
                fields.put("楼栋&房号", "roomNumber");
                fields.put("房屋面积", "roomArea");
                fields.put("是否为小组成员0：否1：是", "isPartyMember");
                fields.put("审核意见", "examineOpinion");

                List<Examine> list = new ArrayList<Examine>();
                list = ExcelUtils.ExecltoList(in, Examine.class, fields);

                int sum = list.size();//总需导入数
                int successNum = 0;//成功导入数
                int failNum = 0;//失败导入数
                for (Examine o : list) {

                    if (checkUnique(o) == 0) {
                        add(o);
                        successNum++;
                    }else {
                        failNum++;
                    }
                }

                return success("总需导入数：" + sum + "</br>成功导入数：" + successNum +" </br>失败导入数：" + failNum);
            }
            return error("上传文件格式应为xls或xlsx");

        } catch (Exception e) {
            logger.error(ExceptionUtils.getFullStackTrace(e));
            return error("上传文件模板有误，请对比导入模板！");
        }
    }

    @Log(title = "审核信息导入模板获取", action = "111")
    @GetMapping("/getExcelModel")
    @ResponseBody
    public void getUserCardExcelModel(HttpServletResponse response) throws Exception {
        OutputStream out = null;
        //通过response对象获取outputStream流
        response.setContentType("application/octect-stream"); // 下载文件能正常显示中文
        response.setHeader("Content-Disposition", "attachment;filename=" + new String(("审核信息的导入模板.xls").getBytes("gb2312"), "ISO8859-1"));
        out = response.getOutputStream();

        Map<String, String> fields = new LinkedHashMap<String, String>();

        fields.put("suilinUserId", "用户id");
        fields.put("name", "姓名");
        fields.put("certificationType", "认证类型");
        fields.put("state", "审核状态；0：未审核；1：已通过；2：未通过");
        fields.put("idCardType", "证件类型");
        fields.put("idCard", "身份证号");
        fields.put("idCardFileId", "身份证照file-id");
        fields.put("propertyFileId", "房产证照file-id");
        fields.put("roomNumber", "楼栋&房号");
        fields.put("roomArea", "房屋面积");
        fields.put("isPartyMember", "是否为小组成员0：否1：是");
        fields.put("examineOpinion", "审核意见");

        ExcelUtils.ListtoExecl(null, out, fields);
        out.flush();
        out.close();
    }



}
