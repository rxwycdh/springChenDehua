package org.analysis.projects.brainwave.service.auto.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.analysis.projects.brainwave.mapper.auto.EegSceneMapper;
import org.analysis.projects.brainwave.model.auto.EegScene;
import org.analysis.projects.brainwave.service.auto.EegSceneService;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 脑波采集场景 服务实现类
 * </p>
 *
 * @author Feliz
 * @since 2019-06-06
 */
@Service
public class EegSceneServiceImpl extends ServiceImpl<EegSceneMapper, EegScene> implements EegSceneService {

}
