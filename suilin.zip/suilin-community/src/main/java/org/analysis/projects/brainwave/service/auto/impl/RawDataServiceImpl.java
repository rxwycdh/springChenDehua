package org.analysis.projects.brainwave.service.auto.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.analysis.projects.brainwave.mapper.auto.RawDataMapper;
import org.analysis.projects.brainwave.model.auto.RawData;
import org.analysis.projects.brainwave.service.auto.RawDataService;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 原始脑波数据表 服务实现类
 * </p>
 *
 * @author Feliz
 * @since 2019-05-30
 */
@Service
public class RawDataServiceImpl extends ServiceImpl<RawDataMapper, RawData> implements RawDataService {

}
