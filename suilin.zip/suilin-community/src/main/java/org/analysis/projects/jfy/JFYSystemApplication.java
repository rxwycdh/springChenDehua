package org.analysis.projects.jfy;

import org.analysis.projects.oasystem.OASystemApplication;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * 居福苑项目启动器
 */
@MapperScan(value = "org.analysis.projects.jfy.mapper")
@SpringBootApplication
public class JFYSystemApplication {

    public static void main(String[] args) {
        SpringApplication.run(OASystemApplication.class, args);
        System.out.println("=================================");
        System.out.println("==========居福苑项目启动成功=========");
        System.out.println("=================================");
    }
}
