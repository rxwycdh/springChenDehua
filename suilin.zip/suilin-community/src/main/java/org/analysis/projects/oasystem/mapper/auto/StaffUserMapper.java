package org.analysis.projects.oasystem.mapper.auto;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.analysis.projects.oasystem.model.auto.StaffUser;

/**
 * <p>
 * 职员-系统用户连接表 Mapper 接口
 * </p>
 *
 * @author Feliz
 * @since 2019-06-18
 */
@DS("db_oasystem")
public interface StaffUserMapper extends BaseMapper<StaffUser> {

}
