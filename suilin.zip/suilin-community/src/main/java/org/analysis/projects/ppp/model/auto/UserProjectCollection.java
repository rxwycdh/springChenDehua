package org.analysis.projects.ppp.model.auto;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * <p>
 * 用户收藏信息
 * </p>
 *
 * @author Feliz
 * @since 2020-04-09
 */
@TableName("ppp_user_project_collection")
@ApiModel(value="UserProjectCollection对象", description="用户收藏信息")
public class UserProjectCollection implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "用户id (client_user)")
    @TableField("user_id")
    private Integer userId;

    @ApiModelProperty(value = "项目id")
    @TableField("project_id")
    private Integer projectId;

    @ApiModelProperty(value = "收藏时间")
    @TableField("create_time")
    private LocalDateTime createTime;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public Integer getProjectId() {
        return projectId;
    }

    public void setProjectId(Integer projectId) {
        this.projectId = projectId;
    }

    public LocalDateTime getCreateTime() {
        return createTime;
    }

    public void setCreateTime(LocalDateTime createTime) {
        this.createTime = createTime;
    }

    @Override
    public String toString() {
        return "UserProjectCollection{" +
                "id=" + id +
                ", userId=" + userId +
                ", projectId=" + projectId +
                ", createTime=" + createTime +
                '}';
    }
}
