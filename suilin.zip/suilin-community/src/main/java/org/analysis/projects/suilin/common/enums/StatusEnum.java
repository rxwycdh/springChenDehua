package org.analysis.projects.suilin.common.enums;

import io.swagger.annotations.ApiModel;

/**
 * @author ChenDehua  597701764@qq.com
 * @date 2020/8/19 11:09
 */
@ApiModel("状态枚举")
public enum StatusEnum {
    /**
     * 0：开启
     */
    OPEN(0, "开启"),
    /**
     * 1：关闭
     */
    CLOSE(1, "关闭");

    public Integer type;

    public String value;

    StatusEnum(Integer type, String value) {
        this.type = type;
        this.value = value;
    }
}
