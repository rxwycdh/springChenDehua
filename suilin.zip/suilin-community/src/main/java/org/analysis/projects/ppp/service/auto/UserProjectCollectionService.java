package org.analysis.projects.ppp.service.auto;

import org.analysis.projects.ppp.model.auto.UserProjectCollection;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 用户收藏信息 服务类
 * </p>
 *
 * @author Feliz
 * @since 2020-04-09
 */
public interface UserProjectCollectionService extends IService<UserProjectCollection> {

}
