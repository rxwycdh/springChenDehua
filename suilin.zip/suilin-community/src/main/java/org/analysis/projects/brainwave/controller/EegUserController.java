package org.analysis.projects.brainwave.controller;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.analysis.projects.brainwave.model.auto.EegUser;
import org.analysis.projects.brainwave.service.auto.EegUserService;
import org.analysis.system.common.base.BaseController;
import org.analysis.system.common.domain.AjaxResult;
import org.analysis.system.common.domain.TableSplitResult;
import org.analysis.system.common.domain.Tablepar;
import org.analysis.system.common.support.Convert;
import org.analysis.system.model.custom.TitleVo;
import org.analysis.system.util.StringUtils;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

/**
 * <p>
 * 前端控制器
 * </p>
 *
 * @author Feliz
 * @since 2019-05-20
 */
@Controller
@Api(tags = {"脑波用户"})
@RequestMapping("/brainwave/eeg-user")
public class EegUserController extends BaseController {

    private static Logger logger = LoggerFactory.getLogger(EegUserController.class);

    @Autowired
    private EegUserService eegUserService;


    //跳转页面参数
    private String prefix = "projects/brainwave/user";


    @ApiOperation(value = "获取全部用户数据", notes = "获取全部用户数据")
    @PostMapping("getalleeguser")
    @ResponseBody
    public AjaxResult<TableSplitResult<EegUser>> getAllEegUser() {
        try {
            List<EegUser> list = eegUserService.list();
            return AjaxResult.successDataList(list);
        } catch (Exception e) {
            logger.error(e.toString());
            return AjaxResult.error(e.getMessage());
        }
    }

    @ApiOperation(value = "跳转脑波用户管理页面", notes = "跳转到脑波用户管理页面", hidden = true)
    @GetMapping("view")
    @RequiresPermissions("brainwave:user:view")
    public String view(Model model) {
        setTitle(model, new TitleVo("用户列表", "穿戴用户管理", false, "欢迎进入穿戴用户管理页面", false, false));
        return prefix + "/list";
    }

    @ApiOperation(value = "获取用户列表", notes = "获取用户列表")
    @PostMapping("list")
    @RequiresPermissions("brainwave:user:list")
    @ResponseBody
    public TableSplitResult<EegUser> list(Tablepar tablepar, String searchText) {

        QueryWrapper<EegUser> queryWrapper = new QueryWrapper<>();
        if (StringUtils.isNotEmpty(searchText)) {
            queryWrapper.like("user_name", searchText).or().like("age", searchText).or().like("mobile", searchText).or()
                    .like("email", searchText).or().like("description", searchText);
        }

        PageHelper.startPage(tablepar.getPageNum(), tablepar.getPageSize());
        List<EegUser> list = eegUserService.list(queryWrapper);
        PageInfo<EegUser> pageInfo = new PageInfo<EegUser>(list);

        return new TableSplitResult<>(pageInfo.getPageNum(), pageInfo.getTotal(), pageInfo.getList());
    }


    @ApiOperation(value = "跳转新增用户页面", notes = "跳转新增用户页面", hidden = true)
    @GetMapping("/add")
    public String add() {
        return prefix + "/add";
    }

    @ApiOperation(value = "添加用户", notes = "添加新的用户")
    @PostMapping("add")
    @RequiresPermissions("brainwave:user:add")
    @ResponseBody
    public AjaxResult add(EegUser eegUser) {
        boolean save = eegUserService.save(eegUser);
        if (save) {
            return success();
        } else {
            return error();
        }
    }

    @ApiOperation(value = "删除用户", notes = "根据id删除用户（批量）")
    @PostMapping("remove")
    @RequiresPermissions("brainwave:user:remove")
    @ResponseBody
    public AjaxResult remove(String ids) {
        List<String> idList= Convert.toListStrArray(ids);
        boolean save = eegUserService.removeByIds(idList);
        if (save) {
            return success();
        } else {
            return error();
        }
    }


    @ApiOperation(value = "检查用户名字是否存在", notes = "传入: userName; 返回: 1-存在; 0-不存在")
    @PostMapping("checkNameUnique")
    @ResponseBody
    public Integer checkNameUnique(String userName) {
        QueryWrapper<EegUser> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("user_name", userName);
        List<EegUser> list = eegUserService.list(queryWrapper);
        if (list.size() > 0) {
            return 1;
        } else {
            return 0;
        }
    }

    @ApiOperation(value = "跳转用户修改页面", notes = "跳转到用户修改页面", hidden = true)
    @GetMapping("/edit/{id}")
    public String edit(@PathVariable("id") String id, ModelMap mmap) {

        mmap.put("eegUser", eegUserService.getById(id));
        return prefix + "/edit";
    }

    @ApiOperation(value = "修改用户", notes = "修改保存用户")
    @PostMapping("/edit")
    @RequiresPermissions("brainwave:user:edit")
    @ResponseBody
    public AjaxResult editSave(EegUser eegUser) {
        eegUser.setUpdateTime(LocalDateTime.now());
        boolean b = eegUserService.updateById(eegUser);
        return b ? success() : error();
    }
}

