package org.analysis.projects.suilin.service.auto.impl;

import org.analysis.projects.suilin.model.auto.PostCommentReply;
import org.analysis.projects.suilin.mapper.auto.PostCommentReplyMapper;
import org.analysis.projects.suilin.service.auto.PostCommentReplyService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 评论回复表 服务实现类
 * </p>
 *
 * @author Feliz
 * @since 2020-08-19
 */
@Service
public class PostCommentReplyServiceImpl extends ServiceImpl<PostCommentReplyMapper, PostCommentReply> implements PostCommentReplyService {

}
