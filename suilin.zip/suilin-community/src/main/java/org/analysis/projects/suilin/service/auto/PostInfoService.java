package org.analysis.projects.suilin.service.auto;

import org.analysis.projects.suilin.model.auto.PostInfo;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 帖子表 服务类
 * </p>
 *
 * @author Feliz
 * @since 2020-08-19
 */
public interface PostInfoService extends IService<PostInfo> {

}
