package org.analysis.projects.ppp.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.analysis.projects.ppp.model.auto.ServerDemand;
import org.analysis.projects.ppp.service.auto.ServerDemandService;
import org.analysis.system.common.base.BaseController;
import org.analysis.system.common.domain.AjaxResult;
import org.analysis.system.common.domain.TableSplitResult;
import org.analysis.system.common.domain.Tablepar;
import org.analysis.system.common.log.Log;
import org.analysis.system.common.support.Convert;
import org.analysis.system.model.custom.TitleVo;
import org.analysis.system.util.ExcelUtils;
import org.analysis.system.util.StringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.io.InputStream;
import java.io.OutputStream;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;


/**
 * <p>
 * 服务版需求信息 前端控制器
 * </p>
 *
 * @author Feliz
 * @since 2020-04-23 17:52:41
 */
@Controller
@Api(tags = {"服务版需求信息"})
@RequestMapping("/ppp/ServerDemandController")
public class ServerDemandController extends BaseController{

    private static Logger logger = LoggerFactory.getLogger(ServerDemandController.class);

    //跳转页面参数
    private String prefix = "projects/ppp/serverDemand";

	@Autowired
	private ServerDemandService serverDemandService;

	//跳转服务版需求信息页面
    @GetMapping("/view")
    @RequiresPermissions("ppp:serverDemand:view")
    public String view(Model model) {
        String str="需求委托信息";
        setTitle(model, new TitleVo(str+"列表", str+"管理", false, "欢迎进入"+str+"页面", false, false));
        return prefix + "/list";
    }

    @Log(title = "服务版需求信息列表查询", action = "111")
    @ApiOperation(value = "获取服务版需求信息列表", notes = "获取服务版需求信息列表")
    @PostMapping("/list")
    @RequiresPermissions("ppp:serverDemand:list")
    @ResponseBody
    public TableSplitResult<ServerDemand> list(Tablepar tablepar, String searchText) {

        QueryWrapper<ServerDemand> queryWrapper = new QueryWrapper<>();
        if (StringUtils.isNotEmpty(searchText)) {
            queryWrapper.and(wrapper -> wrapper
                    .like("type", searchText).or()
                    .like("description", searchText).or()
                    .like("name", searchText).or()
                    .like("phone", searchText).or()
                    .like("wechat", searchText).or()
            );
        }

        PageHelper.startPage(tablepar.getPageNum(), tablepar.getPageSize());
        List<ServerDemand> list = serverDemandService.list(queryWrapper);
        PageInfo<ServerDemand> pageInfo = new PageInfo<ServerDemand>(list);

        return new TableSplitResult<>(pageInfo.getPageNum(), pageInfo.getTotal(), pageInfo.getList());
    }

    @ApiOperation(value = "获取全部服务版需求信息信息", notes = "获取全部服务版需求信息信息")
    @PostMapping("/getAllServerDemand")
    @ResponseBody
    public AjaxResult<TableSplitResult<ServerDemand>> getAllServerDemand() {
        try {
            List<ServerDemand> list = serverDemandService.list();
            return AjaxResult.successDataList(list);
        } catch (Exception e) {
            logger.error(e.toString());
            return AjaxResult.error(e.getMessage());
        }
    }

    //跳转服务版需求信息新增页面
    @GetMapping("/add")
    public String add() {
        return prefix + "/add";
    }

    @Log(title = "服务版需求信息新增", action = "111")
    @ApiOperation(value = "添加服务版需求信息", notes = "添加服务版需求信息")
    @PostMapping("add")
    @RequiresPermissions("ppp:serverDemand:add")
    @ResponseBody
    public AjaxResult add(ServerDemand serverDemand) {
        serverDemand.setCreateTime(LocalDateTime.now());
        boolean save = serverDemandService.save(serverDemand);
        return save ? success() : error();
    }

    @Log(title = "服务版需求信息删除", action = "111")
    @ApiOperation(value = "删除服务版需求信息", notes = "根据id删除服务版需求信息（可批量）")
    @PostMapping("/remove")
    @RequiresPermissions("ppp:serverDemand:remove")
    @ResponseBody
    public AjaxResult remove(String ids) {
        List<Integer> idList= Convert.toListIntArray(ids);
        boolean delete = serverDemandService.removeByIds(idList);
        return delete ? success() : error();
    }

    //跳转服务版需求信息修改页面
    @GetMapping("/edit/{id}")
    public String edit(@PathVariable("id") Integer id, ModelMap modelMap) {
        modelMap.put("serverDemand", serverDemandService.getById(id));
        return prefix + "/edit";
    }

    @Log(title = "服务版需求信息修改", action = "111")
    @ApiOperation(value = "修改服务版需求信息", notes = "修改服务版需求信息")
    @PostMapping("/edit")
    @RequiresPermissions("ppp:serverDemand:edit")
    @ResponseBody
    public AjaxResult editSave(ServerDemand serverDemand) {
        serverDemand.setUpdateTime(LocalDateTime.now());
        boolean edit = serverDemandService.updateById(serverDemand);
        return edit ? success() : error();
    }


    //跳转服务版需求信息批量新增页面
    @GetMapping("/batchAdd")
    public String batchAdd() {
        return prefix + "/batchAdd";
    }

    @Log(title = "服务版需求信息批量导入", action = "111")
    @ApiOperation(value = "批量导入服务版需求信息", notes = "批量导入服务版需求信息")
    @RequiresPermissions("ppp:serverDemand:add")
    @Transactional(propagation = Propagation.REQUIRED)
    @PostMapping("/batchAdd")
    @ResponseBody
    public AjaxResult batchAdd(@RequestParam(value = "file", required = false) MultipartFile file) {
        try {
            String suffer = file.getOriginalFilename().substring(file.getOriginalFilename().indexOf(".") + 1);
            if ("xls".equals(suffer) || "xlsx".equals(suffer)) {
                InputStream in = file.getInputStream();
                Map<String, String> fields = new LinkedHashMap<String, String>();

                fields.put("类型", "type");
                fields.put("要求描述", "description");
                fields.put("联系人", "name");
                fields.put("联系电话", "phone");
                fields.put("联系微信", "wechat");

                List<ServerDemand> list = new ArrayList<ServerDemand>();
                list = ExcelUtils.ExecltoList(in, ServerDemand.class, fields);

                int sum = list.size();//总需导入数
                int successNum = 0;//成功导入数
                int failNum = 0;//失败导入数
                for (ServerDemand o : list) {

                    AjaxResult res = add(o);
                    if (res.getCode() == 200) {
                        successNum++;
                    }else {
                        failNum++;
                    }
                }

                return success("总需导入数：" + sum + "</br>成功导入数：" + successNum +" </br>失败导入数：" + failNum);
            }
            return error("上传文件格式应为xls或xlsx");

        } catch (Exception e) {
            logger.error(ExceptionUtils.getFullStackTrace(e));
            return error("上传文件模板有误，请对比导入模板！");
        }
    }

    @Log(title = "服务版需求信息导入模板获取", action = "111")
    @GetMapping("/getExcelModel")
    @ResponseBody
    public void getUserCardExcelModel(HttpServletResponse response) throws Exception {
        OutputStream out = null;
        //通过response对象获取outputStream流
        response.setContentType("application/octect-stream"); // 下载文件能正常显示中文
        response.setHeader("Content-Disposition", "attachment;filename=" + new String(("需求委托信息的导入模板.xls").getBytes("gb2312"), "ISO8859-1"));
        out = response.getOutputStream();

        Map<String, String> fields = new LinkedHashMap<String, String>();

        fields.put("type", "类型");
        fields.put("description", "要求描述");
        fields.put("name", "联系人");
        fields.put("phone", "联系电话");
        fields.put("wechat", "联系微信");

        ExcelUtils.ListtoExecl(null, out, fields);
        out.flush();
        out.close();
    }

	
}
