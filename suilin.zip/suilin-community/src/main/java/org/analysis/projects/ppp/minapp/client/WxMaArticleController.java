package org.analysis.projects.ppp.minapp.client;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.analysis.projects.ppp.logic.ArticleTagLogic;
import org.analysis.projects.ppp.model.auto.Article;
import org.analysis.projects.ppp.model.custom.ArticleIF;
import org.analysis.projects.ppp.service.auto.ArticleService;
import org.analysis.system.common.domain.AjaxResult;
import org.analysis.system.common.domain.TableSplitResult;
import org.analysis.system.common.domain.Tablepar;
import org.analysis.system.common.support.Convert;
import org.analysis.system.util.StringUtils;
import org.apache.commons.beanutils.BeanUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.List;

@RestController
@Api(tags = {"微信小程序用户版-资讯文章接口"})
@RequestMapping("/wx/pppclient/minapp/article")
public class WxMaArticleController {

    private static Logger logger = LoggerFactory.getLogger(WxMaArticleController.class);

    @Autowired
    private ArticleService articleService;
    @Autowired
    private ArticleTagLogic articleTagLogic;

    @ApiOperation(value = "获取文章信息表列表", notes = "获取文章信息表列表")
    @GetMapping("/list")
    public TableSplitResult<ArticleIF> list(Tablepar tablepar,  HttpServletRequest request,
                                            @ApiParam(name = "sortType", value = "排序类型;0:综合;1:最新;2:热门") Integer sortType,
                                            @ApiParam(name = "searchText", value = "搜索关键词") String searchText) {

        try {
            QueryWrapper<Article> queryWrapper = new QueryWrapper<>();
            if (StringUtils.isNotEmpty(searchText)) {
                queryWrapper.and(wrapper -> wrapper
                        .like("title", searchText).or()
                        .like("author", searchText).or()
                        .like("content", searchText)
                );
            }
            queryWrapper.eq("state", 1);
            if (sortType == 1) {
                queryWrapper.orderByDesc("create_time is null, create_time");
            }else if (sortType == 2) {
                queryWrapper.orderByDesc("views is null, views");
            }else {
                queryWrapper.orderByDesc("topped is null, topped", "weight is null, weight", "create_time is null, create_time");
            }

            PageHelper.startPage(tablepar.getPageNum(), tablepar.getPageSize());
            List<Article> articleList = articleService.list(queryWrapper);
            PageInfo<Article> pageInfo = new PageInfo<>(articleList);

            List<ArticleIF> list = new ArrayList<>();
            for (Article article : articleList) {
                ArticleIF articleIF = new ArticleIF();

                BeanUtils.copyProperties(articleIF, article);

                String tagsName = articleTagLogic.queryArticleTags(article.getId());
                articleIF.setTags(Convert.toListStrArray(tagsName));

                String url = "https://" + request.getServerName() + request.getContextPath() + "/FileController/viewFileByFileId/" + article.getCoverId();
                articleIF.setCoverUrl(url);

                list.add(articleIF);
            }

            return new TableSplitResult<>(pageInfo.getPageNum(), pageInfo.getTotal(), list);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            return null;
        }
    }

    @ApiOperation(value = "获取资讯详情", notes = "获取资讯详情")
    @GetMapping("/getOne")
    public AjaxResult<ArticleIF> getOne(@ApiParam(name = "id", value = "文章id") Integer id, HttpServletRequest request) {

        try {
            Article article = articleService.getById(id);
            ArticleIF articleIF = new ArticleIF();
            BeanUtils.copyProperties(articleIF, article);

            String tagsName = articleTagLogic.queryArticleTags(article.getId());
            articleIF.setTags(Convert.toListStrArray(tagsName));

            String url = "https://" + request.getServerName() + request.getContextPath() + "/FileController/viewFileByFileId/" + article.getCoverId();
            articleIF.setCoverUrl(url);

            //阅读数+1
            article.setViews(article.getViews()+1);
            articleService.updateById(article);

            return AjaxResult.successData(articleIF);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            return AjaxResult.error();
        }
    }

}
