package org.analysis.projects.brainwave.util;

import org.analysis.system.util.StringUtils;
import org.apache.ibatis.executor.statement.StatementHandler;
import org.apache.ibatis.mapping.BoundSql;
import org.apache.ibatis.plugin.*;
import org.apache.ibatis.reflection.DefaultReflectorFactory;
import org.apache.ibatis.reflection.MetaObject;
import org.apache.ibatis.reflection.ReflectorFactory;
import org.apache.ibatis.reflection.factory.DefaultObjectFactory;
import org.apache.ibatis.reflection.factory.ObjectFactory;
import org.apache.ibatis.reflection.wrapper.DefaultObjectWrapperFactory;
import org.apache.ibatis.reflection.wrapper.ObjectWrapperFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.sql.Connection;
import java.util.Properties;

/**
 * 分表策略，通过拦截器修改表名
 */
@Component
@Intercepts({@Signature(type = StatementHandler.class, method = "prepare", args = {Connection.class, Integer.class})})
public class CustomerIdShardInterceptor implements Interceptor {
    private static final ObjectFactory DEFAULT_OBJECT_FACTORY = new DefaultObjectFactory();
    private static final ObjectWrapperFactory DEFAULT_OBJECT_WRAPPER_FACTORY = new DefaultObjectWrapperFactory();
    private static final ReflectorFactory DEFAULT_REFLECTOR_FACTORY = new DefaultReflectorFactory();
    private static Logger logger = LoggerFactory.getLogger(CustomerIdShardInterceptor.class);

    @Override
    public Object intercept(Invocation invocation) throws Throwable {

        StatementHandler statementHandler = (StatementHandler) invocation.getTarget();
        // 保存会话信息
        MetaObject metaStatementHandler = MetaObject.forObject(statementHandler,
                DEFAULT_OBJECT_FACTORY, DEFAULT_OBJECT_WRAPPER_FACTORY, DEFAULT_REFLECTOR_FACTORY);
        // 获取原sql
        BoundSql boundSql = (BoundSql) metaStatementHandler.getValue("delegate.boundSql");
        //修改原有Sql数据
        String modifiedSql = modifySql(boundSql);
        //将修改后的Sql设置到metaStatementHandler中
        metaStatementHandler.setValue("delegate.boundSql.sql", modifiedSql);
        return invocation.proceed();
    }

    @Override
    public Object plugin(Object o) {
        //对应类型进行封装
        if (o instanceof StatementHandler) {
            return Plugin.wrap(o, this);
        } else {
            return o;
        }
    }

    @Override
    public void setProperties(Properties properties) {
    }

    private String modifySql(BoundSql boundSql) {
        String targetSql = boundSql.getSql().trim().toLowerCase();
        String tableName = getTableName(targetSql);

        // 对targetSql进行表名修改
        try {
//            String preTabelName = tableName.split("_")[0];
//            if ("brainwave".equals(preTabelName)) {
//                String newTabelName = "brainwave_data_" + LocalDateTimeUtils.formatTime(LocalDateTime.now(), "yyyyMMddHH");
//                String newTargetSql = targetSql.replace("brainwave_data", newTabelName);
//                logger.info(" - 分表操作--当前表:brainwave_data_" + newTabelName);
//                return newTargetSql;
//            }
        } catch (Exception e) {
            return targetSql;
        }

        return targetSql;
    }

    /**
     * 根据sql获取表名
     *
     * @param sql
     * @return
     */
    private String getTableName(String sql) {
        String[] sqls = sql.split("\\s+");
        switch (sqls[0]) {
            case "select": {
                // select tableName
                for (int i = 0; i < sqls.length; i++) {
                    if (sqls[i].equals("from")) {
                        return sqls[i + 1];
                    }
                }
                break;
            }
            case "update": {
                // update tableName
                return sqls[1];
            }
            case "insert": {
                // insert into tableName
                return sqls[2];
            }
            case "delete": {
                // delete tableName
                return sqls[1];
            }
        }
        return StringUtils.EMPTY;
    }

}
