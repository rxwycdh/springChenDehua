package org.analysis.projects.ppp.model.custom;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableLogic;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.analysis.projects.ppp.model.auto.ClientUser;
import org.analysis.projects.ppp.model.auto.Project;
import org.analysis.projects.ppp.model.auto.ServerUser;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * <p>
 * 项目动态信息
 * </p>
 *
 * @author Feliz
 * @since 2020-04-05
 */
@ApiModel(value="ProjectDynamicVO对象", description="项目动态信息")
public class ProjectDynamicVO implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "项目")
    private Project project;

    @ApiModelProperty(value = "项目状态；0：报名中；1：已邀请；2：已拒绝；3：已取消")
    @TableField("state")
    private Integer state;

    @ApiModelProperty(value = "申请人")
    private ClientUser applicantUser;

    @ApiModelProperty(value = "批复人")
    private ServerUser replyUser;

    @ApiModelProperty(value = "面试说明")
    @TableField("interview_note")
    private String interviewNote;

    @ApiModelProperty(value = "申请时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @TableField("applicant_time")
    private LocalDateTime applicantTime;

    @ApiModelProperty(value = "批复时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @TableField("reply_time")
    private LocalDateTime replyTime;

    @ApiModelProperty(value = "逻辑删除；0：未删除；1：已删除")
    @TableField("deleted")
    @TableLogic
    private Integer deleted;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getState() {
        return state;
    }

    public void setState(Integer state) {
        this.state = state;
    }

    public String getInterviewNote() {
        return interviewNote;
    }

    public void setInterviewNote(String interviewNote) {
        this.interviewNote = interviewNote;
    }

    public LocalDateTime getApplicantTime() {
        return applicantTime;
    }

    public void setApplicantTime(LocalDateTime applicantTime) {
        this.applicantTime = applicantTime;
    }

    public LocalDateTime getReplyTime() {
        return replyTime;
    }

    public void setReplyTime(LocalDateTime replyTime) {
        this.replyTime = replyTime;
    }

    public Integer getDeleted() {
        return deleted;
    }

    public void setDeleted(Integer deleted) {
        this.deleted = deleted;
    }

    public ClientUser getApplicantUser() {
        return applicantUser;
    }

    public void setApplicantUser(ClientUser applicantUser) {
        this.applicantUser = applicantUser;
    }

    public ServerUser getReplyUser() {
        return replyUser;
    }

    public void setReplyUser(ServerUser replyUser) {
        this.replyUser = replyUser;
    }

    public Project getProject() {
        return project;
    }

    public void setProject(Project project) {
        this.project = project;
    }

    @Override
    public String toString() {
        return "ProjectDynamicVO{" +
                "id=" + id +
                ", project=" + project +
                ", state=" + state +
                ", applicantUser=" + applicantUser +
                ", replyUser=" + replyUser +
                ", interviewNote='" + interviewNote + '\'' +
                ", applicantTime=" + applicantTime +
                ", replyTime=" + replyTime +
                ", deleted=" + deleted +
                '}';
    }
}
