package org.analysis.projects.ppp.service.auto.impl;

import org.analysis.projects.ppp.model.auto.ServerDemand;
import org.analysis.projects.ppp.mapper.auto.ServerDemandMapper;
import org.analysis.projects.ppp.service.auto.ServerDemandService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 服务版需求信息 服务实现类
 * </p>
 *
 * @author Feliz
 * @since 2020-04-23
 */
@Service
public class ServerDemandServiceImpl extends ServiceImpl<ServerDemandMapper, ServerDemand> implements ServerDemandService {

}
