package org.analysis.projects.oasystem.controller;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.analysis.projects.oasystem.model.auto.Dept;
import org.analysis.projects.oasystem.model.auto.Position;
import org.analysis.projects.oasystem.model.auto.Staff;
import org.analysis.projects.oasystem.service.auto.DeptService;
import org.analysis.projects.oasystem.service.auto.PositionService;
import org.analysis.projects.oasystem.service.auto.StaffService;
import org.analysis.system.common.base.BaseController;
import org.analysis.system.common.domain.AjaxResult;
import org.analysis.system.common.domain.TableSplitResult;
import org.analysis.system.common.domain.Tablepar;
import org.analysis.system.common.support.Convert;
import org.analysis.system.model.custom.TitleVo;
import org.analysis.system.util.StringUtils;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * <p>
 * 职员信息 前端控制器
 * </p>
 *
 * @author Feliz
 * @since 2019-06-14
 */
@Api(tags = {"职员信息"})
@Controller
@RequestMapping("/oasystem/staff")
public class StaffController extends BaseController {

    private static Logger logger = LoggerFactory.getLogger(StaffController.class);

    @Autowired
    private StaffService staffService;
    @Autowired
    private DeptService deptService;
    @Autowired
    private PositionService positionService;


    //跳转页面参数
    private String prefix = "projects/oasystem/staff";

    @ApiOperation(value = "跳转职员管理页面", notes = "跳转到职员管理页面", hidden = true)
    @GetMapping("view")
    @RequiresPermissions("oasystem:staff:view")
    public String view(Model model) {
        setTitle(model, new TitleVo("职员列表", "职员管理", false, "欢迎进入职员管理页面", false, false));
        return prefix + "/list";
    }

    @ApiOperation(value = "获取职员列表", notes = "获取职员列表")
    @PostMapping("list")
    @RequiresPermissions("oasystem:staff:list")
    @ResponseBody
    public TableSplitResult<Staff> list(Tablepar tablepar, String searchText) {

        QueryWrapper<Staff> queryWrapper = new QueryWrapper<>();
        if (StringUtils.isNotEmpty(searchText)) {
            Integer deptId = -1;
            QueryWrapper<Dept> deptQueryWrapper = new QueryWrapper<>();
            List<Dept> deptList = deptService.list(deptQueryWrapper.like("dept_name", searchText));
            if (deptList.size() > 0) {
                deptId = deptList.get(0).getId();
            }

            Integer positionId = -1;
            QueryWrapper<Position> positionQueryWrapper = new QueryWrapper<>();
            List<Position> positionList = positionService.list(positionQueryWrapper.like("name", searchText));
            if (positionList.size() > 0) {
                positionId = positionList.get(0).getId();
            }

            queryWrapper.like("dept_id", deptId).or().like("position_id", positionId).or().like("name", searchText)
                    .or().like("sex", searchText).or().like("school", searchText)
                    .or().like("address", searchText).or().like("bank", searchText)
                    .or().like("tel", searchText).or().like("idcard", searchText)
                    .or().like("salary", searchText).or().like("birth", searchText)
                    .or().like("email", searchText).or().like("edu", searchText)
                    .or().like("hire_time", searchText).or().like("description", searchText);
        }

        PageHelper.startPage(tablepar.getPageNum(), tablepar.getPageSize());
        List<Staff> list = staffService.list(queryWrapper);
        PageInfo<Staff> pageInfo = new PageInfo<>(list);

        return new TableSplitResult<>(pageInfo.getPageNum(), pageInfo.getTotal(), pageInfo.getList());
    }


    @ApiOperation(value = "跳转新增职员页面", notes = "跳转新增职员页面", hidden = true)
    @GetMapping("/add")
    public String add() {
        return prefix + "/add";
    }

    @ApiOperation(value = "添加职员", notes = "添加新的职员")
    @PostMapping("add")
    @RequiresPermissions("oasystem:staff:add")
    @ResponseBody
    public AjaxResult add(Staff staff) {
        boolean save = staffService.save(staff);
        if (save) {
            return success();
        } else {
            return error();
        }
    }

    @ApiOperation(value = "删除职员", notes = "根据id删除职员（批量）")
    @PostMapping("remove")
    @RequiresPermissions("oasystem:staff:remove")
    @ResponseBody
    public AjaxResult remove(String ids) {
        List<String> idList= Convert.toListStrArray(ids);
        boolean save = staffService.removeByIds(idList);
        if (save) {
            return success();
        } else {
            return error();
        }
    }


    @ApiOperation(value = "检查职员名字是否存在", notes = "传入: name; 返回: 1-存在; 0-不存在")
    @PostMapping("checkNameUnique")
    @ResponseBody
    public Integer checkNameUnique(String name) {
        QueryWrapper<Staff> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("name", name);
        List<Staff> list = staffService.list(queryWrapper);
        if (list.size() > 0) {
            return 1;
        } else {
            return 0;
        }
    }

    @ApiOperation(value = "跳转职员修改页面", notes = "跳转到职员修改页面", hidden = true)
    @GetMapping("/edit/{id}")
    public String edit(@PathVariable("id") String id, ModelMap mmap) {
        mmap.put("staff", staffService.getById(id));
        return prefix + "/edit";
    }

    @ApiOperation(value = "修改职员", notes = "修改保存职员")
    @PostMapping("/edit")
    @RequiresPermissions("oasystem:staff:edit")
    @ResponseBody
    public AjaxResult editSave(Staff staff) {
        boolean b = staffService.updateById(staff);
        return b ? success() : error();
    }
}

