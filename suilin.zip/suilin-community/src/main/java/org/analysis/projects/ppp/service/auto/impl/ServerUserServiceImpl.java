package org.analysis.projects.ppp.service.auto.impl;

import org.analysis.projects.ppp.model.auto.ServerUser;
import org.analysis.projects.ppp.mapper.auto.ServerUserMapper;
import org.analysis.projects.ppp.service.auto.ServerUserService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 服务版用户信息 服务实现类
 * </p>
 *
 * @author Feliz
 * @since 2020-04-01
 */
@Service
public class ServerUserServiceImpl extends ServiceImpl<ServerUserMapper, ServerUser> implements ServerUserService {

}
