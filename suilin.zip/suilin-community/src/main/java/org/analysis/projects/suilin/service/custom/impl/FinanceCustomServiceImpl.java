package org.analysis.projects.suilin.service.custom.impl;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.convert.Convert;
import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.math.MathUtil;
import cn.hutool.core.util.NumberUtil;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import lombok.AllArgsConstructor;
import org.analysis.projects.suilin.model.auto.Community;
import org.analysis.projects.suilin.model.auto.Finance;
import org.analysis.projects.suilin.model.custom.FinanceStatisticsVO;
import org.analysis.projects.suilin.model.custom.FinanceSummaryVO;
import org.analysis.projects.suilin.service.auto.CommunityService;
import org.analysis.projects.suilin.service.auto.FinanceService;
import org.analysis.projects.suilin.service.custom.FinanceCustomService;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.function.Function;
import java.util.function.ToDoubleFunction;
import java.util.function.ToIntFunction;

/**
 * @author ChenDehua  597701764@qq.com
 * @date 2020/8/12 20:29
 */
@Service
@AllArgsConstructor
public class FinanceCustomServiceImpl implements FinanceCustomService {
    /**
     * 分转元 100:1
     */
    private static final Double FEN_TO_YUAN = 100D;

    private FinanceService financeService;

    private CommunityService communityService;

    /**
     * 获取小区财政统计
     * @param start 开始日期
     * @param end   结束日期
     * @return 财政统计显示参数
     */
    @Override
    public FinanceStatisticsVO getFinanceStatistics(Date start, Date end) {
        FinanceStatisticsVO result = new FinanceStatisticsVO();

        List<Finance> financeList = listFinance(start, end);

        double amount = getSum(financeList, finance -> finance.getIncome() - finance.getOutcome());
        double incomeAmount = getSum(financeList, Finance::getIncome);
        double expensesAmount = getSum(financeList, Finance::getOutcome);

        List<Community> communityList = communityService.list();
        if(CollUtil.isEmpty(communityList)) {
            return result;
        }

        Integer communityBalance = communityList.get(0).getCommunityBalance();

        result.setAmount(amount);
        result.setBalance(communityBalance + amount);
        result.setExpensesAmount(expensesAmount);
        result.setIncomeAmount(incomeAmount);
        result.setFinanceList(financeList);
        return result;
    }

    /**
     * 获取小区财务列表
     * @param start 开始日期
     * @param end   结束日期
     * @return    财务列表
     */
    @Override
    public List<Finance> listFinance(Date start, Date end) {
        return  financeService
                .list(Wrappers.<Finance>lambdaQuery().between(Finance::getDate, start, end));
    }

    /**
     * 获取某一属性总计
     * @param list   财务列表
     * @param function 提供某一属性
     * @return 总计
     */
    private Double getSum(List<Finance> list, ToIntFunction<Finance> function) {
        int intSum = list.stream().mapToInt(function).sum();
        return Convert.toDouble(intSum) / FEN_TO_YUAN;
    }

    /**
     * 获取小区财务概要
     * @return 财务概要
     */
    @Override
    public FinanceSummaryVO getFinanceSummary() {
        FinanceSummaryVO result = new FinanceSummaryVO();

        DateTime dateTime = DateUtil.date();
        FinanceStatisticsVO thisMonth = getFinanceStatistics(DateUtil.beginOfMonth(dateTime),
                DateUtil.endOfMonth(dateTime));

        DateTime lastMonthDateTime = DateUtil.lastMonth();
        FinanceStatisticsVO lastMonth = getFinanceStatistics(DateUtil.beginOfMonth(lastMonthDateTime),
                DateUtil.endOfMonth(lastMonthDateTime));

        BeanUtils.copyProperties(thisMonth, result);
        result.setIncomeChangeRange(getRange(thisMonth, lastMonth, FinanceStatisticsVO::getIncomeAmount));
        result.setExpensesChangeRange(getRange(thisMonth, lastMonth, FinanceStatisticsVO::getExpensesAmount));
        result.setBalanceChangeRange(getRange(thisMonth, lastMonth, FinanceStatisticsVO::getBalance));

        return result;
    }

    /**
     * 获取某一属性变化幅度
     * @param thisMonth 这个月统计
     * @param lastMonth 上个月统计
     * @param function  提供某一属性
     * @return 变化幅度
     */
    private double getRange(FinanceStatisticsVO thisMonth, FinanceStatisticsVO lastMonth,
                            Function<FinanceStatisticsVO, Double> function) {
        double range = (function.apply(thisMonth) - function.apply(lastMonth)) / function.apply(lastMonth);

        return Double.isInfinite(range) ? 1 : range;
    }
}
