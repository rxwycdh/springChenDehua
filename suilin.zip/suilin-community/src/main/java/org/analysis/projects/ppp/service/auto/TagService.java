package org.analysis.projects.ppp.service.auto;

import org.analysis.projects.ppp.model.auto.Tag;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 标签信息表 服务类
 * </p>
 *
 * @author Feliz
 * @since 2020-03-30
 */
public interface TagService extends IService<Tag> {

}
