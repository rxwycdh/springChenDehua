package org.analysis.projects.ppp.service.auto;

import org.analysis.projects.ppp.model.auto.ServerDemand;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 服务版需求信息 服务类
 * </p>
 *
 * @author Feliz
 * @since 2020-04-23
 */
public interface ServerDemandService extends IService<ServerDemand> {

}
