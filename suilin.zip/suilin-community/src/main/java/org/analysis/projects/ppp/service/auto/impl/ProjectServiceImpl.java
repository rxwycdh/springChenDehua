package org.analysis.projects.ppp.service.auto.impl;

import org.analysis.projects.ppp.model.auto.Project;
import org.analysis.projects.ppp.mapper.auto.ProjectMapper;
import org.analysis.projects.ppp.service.auto.ProjectService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 项目信息 服务实现类
 * </p>
 *
 * @author Feliz
 * @since 2020-04-03
 */
@Service
public class ProjectServiceImpl extends ServiceImpl<ProjectMapper, Project> implements ProjectService {

}
