package org.analysis.projects.ppp.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.analysis.projects.ppp.model.auto.ArticleTag;
import org.analysis.projects.ppp.model.auto.ProjectTag;
import org.analysis.projects.ppp.model.auto.Tag;
import org.analysis.projects.ppp.service.auto.ArticleTagService;
import org.analysis.projects.ppp.service.auto.ProjectTagService;
import org.analysis.projects.ppp.service.auto.TagService;
import org.analysis.system.common.base.BaseController;
import org.analysis.system.common.domain.AjaxResult;
import org.analysis.system.common.domain.TableSplitResult;
import org.analysis.system.common.domain.Tablepar;
import org.analysis.system.common.log.Log;
import org.analysis.system.common.support.Convert;
import org.analysis.system.model.custom.TitleVo;
import org.analysis.system.util.ExcelUtils;
import org.analysis.system.util.StringUtils;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.io.InputStream;
import java.io.OutputStream;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;


/**
 * <p>
 * 标签信息表 前端控制器
 * </p>
 *
 * @author Feliz
 * @since 2020-03-30 17:46:57
 */
@Controller
@Api(tags = {"标签信息表"})
@RequestMapping("/ppp/TagController")
public class TagController extends BaseController{

    private static Logger logger = LoggerFactory.getLogger(TagController.class);

    //跳转页面参数
    private String prefix = "projects/ppp/tag";

	@Autowired
	private TagService tagService;
	@Autowired
    private ProjectTagService projectTagService;
	@Autowired
    private ArticleTagService articleTagService;

	//跳转标签信息表页面
    @GetMapping("/view")
    @RequiresPermissions("ppp:tag:view")
    public String view(Model model) {
        String str="标签信息";
        setTitle(model, new TitleVo(str+"列表", str+"管理", false, "欢迎进入"+str+"页面", false, false));
        return prefix + "/list";
    }

    @Log(title = "标签信息表列查询", action = "111")
    @ApiOperation(value = "获取标签信息列表", notes = "获取标签信息列表")
    @PostMapping("/list")
    @RequiresPermissions("ppp:tag:list")
    @ResponseBody
    public TableSplitResult<Tag> list(Tablepar tablepar, String searchText) {

        QueryWrapper<Tag> queryWrapper = new QueryWrapper<>();
        if (StringUtils.isNotEmpty(searchText)) {
            queryWrapper.and(wrapper -> wrapper
                    .like("name", searchText).or()
                    .like("description", searchText).or()
            );
        }

        PageHelper.startPage(tablepar.getPageNum(), tablepar.getPageSize());
        List<Tag> list = tagService.list(queryWrapper);
        PageInfo<Tag> pageInfo = new PageInfo<Tag>(list);

        return new TableSplitResult<>(pageInfo.getPageNum(), pageInfo.getTotal(), pageInfo.getList());
    }

    @GetMapping("/getTags")
    @ResponseBody
    public List<Tag> getTags(String searchText) {
        try {
            QueryWrapper<Tag> queryWrapper = new QueryWrapper<>();
            if (StringUtils.isNotEmpty(searchText)) {
                queryWrapper.and(wrapper -> wrapper
                        .like("name", searchText).or()
                );
            }

            List<Tag> list = tagService.list(queryWrapper);
            return list;
        } catch (Exception e) {
            logger.error(e.toString());
            return null;
        }
    }

    //跳转标签信息表新增页面
    @GetMapping("/add")
    public String add() {
        return prefix + "/add";
    }

    @Log(title = "标签信息新增", action = "111")
    @ApiOperation(value = "添加标签信息", notes = "添加标签信息")
    @PostMapping("add")
    @RequiresPermissions("ppp:tag:add")
    @ResponseBody
    public AjaxResult add(Tag tag) {
        tag.setCreateTime(LocalDateTime.now());
        boolean save = tagService.save(tag);
        if (save) {
            return success();
        } else {
            return error();
        }
    }

    @Log(title = "标签信息删除", action = "111")
    @ApiOperation(value = "删除标签信息", notes = "根据id删除标签信息（可批量）")
    @PostMapping("/remove")
    @RequiresPermissions("ppp:tag:remove")
    @Transactional
    @ResponseBody
    public AjaxResult remove(String ids) {
        List<Integer> idList= Convert.toListIntArray(ids);
        QueryWrapper<ProjectTag> projectTagQueryWrapper = new QueryWrapper<>();
        projectTagQueryWrapper.in("tag_id", idList);
        projectTagService.remove(projectTagQueryWrapper);

        QueryWrapper<ArticleTag> articleTagQueryWrapper = new QueryWrapper<>();
        articleTagQueryWrapper.in("tag_id", idList);
        articleTagService.remove(articleTagQueryWrapper);
        boolean delete = tagService.removeByIds(idList);
        if (delete) {
            return success();
        } else {
            return error();
        }
    }

    @ApiOperation(value = "检查标签信息是否存在", notes = "返回: 1-存在; 0-不存在")
    @PostMapping("/checkNameUnique")
    @ResponseBody
    public Integer checkNameUnique(Tag tag) {
        QueryWrapper<Tag> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("name", tag.getName());
        List<Tag> list = tagService.list(queryWrapper);
        if (list.size() > 0) {
            return 1;
        } else {
            return 0;
        }
    }

    //跳转标签信息表修改页面
    @GetMapping("/edit/{id}")
    public String edit(@PathVariable("id") Integer id, ModelMap mmap) {
        mmap.put("tag", tagService.getById(id));
        return prefix + "/edit";
    }

    @Log(title = "标签信息修改", action = "111")
    @ApiOperation(value = "修改标签信息", notes = "修改标签信息")
    @PostMapping("/edit")
    @RequiresPermissions("ppp:tag:edit")
    @ResponseBody
    public AjaxResult editSave(Tag tag) {
        tag.setUpdateTime(LocalDateTime.now());
        boolean b = tagService.updateById(tag);
        return b ? success() : error();
    }


    //跳转标签信息表批量新增页面
    @GetMapping("/batchAdd")
    public String batchAdd() {
        return prefix + "/batchAdd";
    }

    @Log(title = "标签信息批量导入", action = "111")
    @ApiOperation(value = "批量导入标签信息", notes = "批量导入标签信息")
    @RequiresPermissions("ppp:tag:add")
    @Transactional(propagation = Propagation.REQUIRED)
    @PostMapping("/batchAdd")
    @ResponseBody
    public AjaxResult batchAdd(@RequestParam(value = "file", required = false) MultipartFile file) {
        try {
            String suffer = file.getOriginalFilename().substring(file.getOriginalFilename().indexOf(".") + 1);
            if ("xls".equals(suffer) || "xlsx".equals(suffer)) {
                InputStream in = file.getInputStream();
                Map<String, String> fields = new LinkedHashMap<String, String>();

                fields.put("标签名称", "name");
                fields.put("备注", "description");

                List<Tag> list = new ArrayList<Tag>();
                list = ExcelUtils.ExecltoList(in, Tag.class, fields);

                int sum = list.size();//总需导入数
                int successNum = 0;//成功导入数
                int failNum = 0;//失败导入数
                for (Tag o : list) {

                    if (checkNameUnique(o) == 0) {
                        add(o);
                        successNum++;
                    }else {
                        failNum++;
                    }
                }

                return success("总需导入数：" + sum + "</br>成功导入数：" + successNum +" </br>失败导入数：" + failNum);
            }
            return error("上传文件格式应为xls或xlsx");

        } catch (Exception e) {
            return error("上传文件模板有误，请对比导入模板！");
        }
    }

    @Log(title = "标签信息导入模板获取", action = "111")
    @GetMapping("/getExcelModel")
    @ResponseBody
    public void getUserCardExcelModel(HttpServletResponse response) throws Exception {
        OutputStream out = null;
        //通过response对象获取outputStream流
        response.setContentType("application/octect-stream"); // 下载文件能正常显示中文
        response.setHeader("Content-Disposition", "attachment;filename=" + new String(("标签信息表的导入模板.xls").getBytes("gb2312"), "ISO8859-1"));
        out = response.getOutputStream();

        Map<String, String> fields = new LinkedHashMap<String, String>();

        int i = 0;
        fields.put("name", "标签名称");
        fields.put("description", "备注");

        ExcelUtils.ListtoExecl(null, out, fields);
        out.flush();
        out.close();
    }

	
}
