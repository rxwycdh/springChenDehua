package org.analysis.projects.oasystem.service.auto.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.analysis.projects.oasystem.mapper.auto.ClaimDetailMapper;
import org.analysis.projects.oasystem.model.auto.ClaimDetail;
import org.analysis.projects.oasystem.service.auto.ClaimDetailService;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author Feliz
 * @since 2019-06-21
 */
@Service
public class ClaimDetailServiceImpl extends ServiceImpl<ClaimDetailMapper, ClaimDetail> implements ClaimDetailService {

}
