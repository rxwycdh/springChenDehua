package org.analysis.projects.brainwave.model.custom;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 脑波数据查询条件
 */
@ApiModel(value="DataQueryCondition对象", description="脑波数据查询条件")
public class DataQueryCondition implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "穿戴者", required = true, example = "0")
    private Integer eegUser;

    @ApiModelProperty(value = "脑波仪器", required = true, example = "0")
    private Integer eegDevice;

    @ApiModelProperty(value = "场景", required = true, example = "0")
    private Integer eegScene;

    @ApiModelProperty(value = "开始时间", required = true)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm")
    private LocalDateTime startTime;

    @ApiModelProperty(value = "结束时间", required = true)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm")
    private LocalDateTime endTime;

    public Integer getEegUser() {
        return eegUser;
    }

    public void setEegUser(Integer eegUser) {
        this.eegUser = eegUser;
    }

    public Integer getEegDevice() {
        return eegDevice;
    }

    public void setEegDevice(Integer eegDevice) {
        this.eegDevice = eegDevice;
    }

    public LocalDateTime getStartTime() {
        return startTime;
    }

    public void setStartTime(LocalDateTime startTime) {
        this.startTime = startTime;
    }

    public LocalDateTime getEndTime() {
        return endTime;
    }

    public void setEndTime(LocalDateTime endTime) {
        this.endTime = endTime;
    }

    public Integer getEegScene() {
        return eegScene;
    }

    public void setEegScene(Integer eegScene) {
        this.eegScene = eegScene;
    }

    @Override
    public String toString() {
        return "DataQueryCondition{" +
                "eegUser=" + eegUser +
                ", eegDevice=" + eegDevice +
                ", eegScene=" + eegScene +
                ", startTime=" + startTime +
                ", endTime=" + endTime +
                '}';
    }
}
