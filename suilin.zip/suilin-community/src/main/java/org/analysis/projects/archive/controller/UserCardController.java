package org.analysis.projects.archive.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.analysis.projects.archive.model.auto.Card;
import org.analysis.projects.archive.model.auto.Field;
import org.analysis.projects.archive.model.auto.UserCard;
import org.analysis.projects.archive.model.auto.UserField;
import org.analysis.projects.archive.model.custom.FieldValue;
import org.analysis.projects.archive.model.custom.UserFieldVO;
import org.analysis.projects.archive.service.auto.CardService;
import org.analysis.projects.archive.service.auto.FieldService;
import org.analysis.projects.archive.service.auto.UserCardService;
import org.analysis.projects.archive.service.auto.UserFieldService;
import org.analysis.system.common.base.BaseController;
import org.analysis.system.common.domain.AjaxResult;
import org.analysis.system.common.domain.TableSplitResult;
import org.analysis.system.common.domain.Tablepar;
import org.analysis.system.common.log.Log;
import org.analysis.system.common.support.Convert;
import org.analysis.system.model.auto.TsysPremission;
import org.analysis.system.model.auto.TsysRoleExample;
import org.analysis.system.model.auto.TsysUser;
import org.analysis.system.model.auto.TsysUserExample;
import org.analysis.system.model.custom.TitleVo;
import org.analysis.system.shiro.util.ShiroUtils;
import org.analysis.system.util.ExcelUtils;
import org.analysis.system.util.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.*;

/**
 * <p>
 * 信息数据 前端控制器
 * </p>
 *
 * @author Feliz
 * @since 2019-09-10 16:55:35
 */
@Controller
@Api(tags = {"信息数据"})
@RequestMapping("/archive/UserCardController")
public class UserCardController extends BaseController {

    private static Logger logger = LoggerFactory.getLogger(UserCardController.class);

    @Autowired
    private FieldService fieldService;
    @Autowired
    private UserFieldService userFieldService;
    @Autowired
    private CardService cardService;
    @Autowired
    private UserCardService userCardService;

    private final Base64.Decoder decoder = Base64.getDecoder();
    private final Base64.Encoder encoder = Base64.getEncoder();


    //跳转页面参数
    private String prefix = "projects/archive/userCard";
    //档案个人用户角色名称
    private String archiveUserRoleName = "archiveUserRoleName";
    //档案管理员角色名称
    private String archiveAdminRoleName = "archiveAdminRoleName";

    @ApiOperation(value = "跳转信息数据页面", notes = "跳转信息数据页面", hidden = true)
    @GetMapping("/view/{cardId}")
    public String view(@PathVariable("cardId") String cardId, Model model) {

        //获取当前用户所有角色的权限集合
        List<TsysPremission> userRolePremission = sysPremissionService.getUserRolePremission();

        String userRoleName = sysKvSettingService.getValueByDicKey(archiveUserRoleName);
        String adminRoleName = sysKvSettingService.getValueByDicKey(archiveAdminRoleName);
        String str = "用户信息";

        //判断当前用户是否有相应页面权限
        for (TsysPremission premission : userRolePremission) {
            if (("archive:userCard:" + cardId).equals(premission.getPerms())) {
                if (ShiroUtils.hasRole(adminRoleName) || ShiroUtils.hasRole("管理员")) {
                    Card card = cardService.getById(cardId);
                    List<Field> fields = fieldService.listByIds(card.getCardFieldIds());
                    model.addAttribute("cardFields", fields);
                    model.addAttribute("cardId", cardId);
                    setTitle(model, new TitleVo(str + "列表", str + "管理", false, "欢迎进入" + str + "页面", false, false));
                    return prefix + "/list";
                } else if (ShiroUtils.hasRole(userRoleName)) {
                    return "redirect:/archive/UserCardController/userEdit/" + ShiroUtils.getUser().getId() + "/" + cardId;
                } else {
                    return "redirect:/error/404";
                }

            }
        }

        return "redirect:/Out403";
    }

    @Log(title = "信息数据列表查询", action = "111")
    @ApiOperation(value = "获取信息数据列表", notes = "获取信息数据列表")
    @PostMapping("/list")
    @ResponseBody
    public TableSplitResult<UserFieldVO> list(Tablepar tablepar, String searchText, Integer cardId) {

        List<UserFieldVO> list = new ArrayList<>();
        //档案卡片字段
        Card card = cardService.getById(cardId);
        List<Integer> cardFieldIds = Convert.toListIntArray(card.getCardFieldIds());
        PageInfo pageInfo = new PageInfo<>();

        //搜索关键词不为空时
        if (StringUtils.isNotEmpty(searchText)) {
            QueryWrapper<UserField> fieldQueryWrapper = new QueryWrapper<>();
            fieldQueryWrapper.in("field_id", cardFieldIds);
            fieldQueryWrapper.like("value", searchText);
            fieldQueryWrapper.groupBy("user_id");
            PageHelper.startPage(tablepar.getPageNum(), tablepar.getPageSize());
            List<UserField> userFields = userFieldService.list(fieldQueryWrapper);
            pageInfo = new PageInfo<>(userFields);

            for (UserField uf : userFields) {
                Integer userId = uf.getUserId();

                //用户-字段&值
                UserFieldVO userFieldVO = new UserFieldVO();
                userFieldVO.setCardId(cardId);
                userFieldVO.setUser(sysUserService.selectByPrimaryKey(userId));
                //字段-值集合
                Map<String, Object> map = getFieldValueList(cardFieldIds, userId);
                List<FieldValue> fieldValueList = (List<FieldValue>) map.get("fieldValueList");
                List<String> fieldValues = new ArrayList<>();
                for (FieldValue fv : fieldValueList) {
                    fieldValues.add(fv.getFieldValue());
                }

                //如果字段值全为空，则不显示该条信息
                boolean b = (boolean) map.get("ifAllNull");
                if (b) {
                    continue;
                }
                userFieldVO.setFieldValueList(fieldValueList);
                list.add(userFieldVO);
            }
        } else {
            QueryWrapper<UserCard> userCardQueryWrapper = new QueryWrapper<>();
            userCardQueryWrapper.eq("card_id", cardId);
            PageHelper.startPage(tablepar.getPageNum(), tablepar.getPageSize());
            List<UserCard> userCards = userCardService.list(userCardQueryWrapper);
            pageInfo = new PageInfo<>(userCards);
            for (UserCard uc : userCards) {
                Integer userId = uc.getUserId();

                //用户-字段&值
                UserFieldVO userFieldVO = new UserFieldVO();
                userFieldVO.setCardId(cardId);
                userFieldVO.setUser(sysUserService.selectByPrimaryKey(userId));
                //字段-值集合
                Map<String, Object> map = getFieldValueList(cardFieldIds, userId);
                List<FieldValue> fieldValueList = (List<FieldValue>) map.get("fieldValueList");
                List<String> fieldValues = new ArrayList<>();
                for (FieldValue fv : fieldValueList) {
                    fieldValues.add(fv.getFieldValue());
                }

                //如果字段值全为空，则不显示该条信息
                boolean b = (boolean) map.get("ifAllNull");
                if (b) {
                    continue;
                }
                userFieldVO.setFieldValueList(fieldValueList);
                list.add(userFieldVO);
            }
        }

        return new TableSplitResult<>(pageInfo.getPageNum(), pageInfo.getTotal(), list);

//        List<UserFieldVO> list = new ArrayList<>();

//        //获取个人信息用户list
//        String userRoleName = sysKvSettingService.getValueByDicKey(archiveUserRoleName);
//
//        TsysPremissionExample example = new TsysPremissionExample();
//        if (StringUtils.isNotEmpty(searchText)) {
//            example.createCriteria().andNameLike("%" + searchText + "%");
//        }
//
//        PageHelper.startPage(tablepar.getPageNum(), tablepar.getPageSize());
//        List<TsysUser> archiveUsers = sysUserService.listUserByRoleName(userRoleName);
//        PageInfo<TsysUser> pageInfo = new PageInfo<>(archiveUsers);


        //档案卡片字段
//        Card card = cardService.getById(cardId);
//        List<Integer> cardFieldIds = Convert.toListIntArray(card.getCardFieldIds());
//
//        for (TsysUser user : archiveUsers) {
//            //用户-字段&值
//            UserFieldVO userFieldVO = new UserFieldVO();
//            userFieldVO.setUser(user);
//            //字段-值集合
//            Map<String, Object> map = getFieldValueList(cardFieldIds, user.getId());
//            List<FieldValue> fieldValueList = (List<FieldValue>) map.get("fieldValueList");
//            List<String> fieldValues = new ArrayList<>();
//            for (FieldValue fv : fieldValueList) {
//                fieldValues.add(fv.getFieldValue());
//            }
//
//            if (fieldValueList.size() > 0) {
//                //是否进行搜索
//                if (StringUtils.isNotEmpty(searchText)) {
//                    if (searchText.equals(user.getUsername()) || fieldValues.contains(searchText)) {
//                        userFieldVO.setFieldValueList(fieldValueList);
//                        list.add(userFieldVO);
//                    }
//                } else {
//                    //如果字段值全为空，则不显示该条信息
//                    boolean b = (boolean) map.get("ifAllNull");
//                    if (b) {
//                        continue;
//                    }
//                    userFieldVO.setFieldValueList(fieldValueList);
//                    list.add(userFieldVO);
//                }
//            }
//        }

    }

    @ApiOperation(value = "获取信息用户集合", notes = "获取信息用户集合")
    @PostMapping("/listArchiveUsers")
    @ResponseBody
    public AjaxResult<TableSplitResult<TsysUser>> listArchiveUsers() {
        String userRoleName = sysKvSettingService.getValueByDicKey(archiveUserRoleName);
        List<TsysUser> archiveUsers = sysUserService.listUserByRoleName(userRoleName);
        return AjaxResult.successDataList(archiveUsers);
    }

    @ApiOperation(value = "跳转新增信息数据页面", notes = "跳转新增信息数据页面", hidden = true)
    @GetMapping("/add/{cardId}")
    public String add(@PathVariable("cardId") Integer cardId, Model model) {
        Card card = cardService.getById(cardId);
        List<Field> fields = fieldService.listByIds(card.getCardFieldIds());
        model.addAttribute("cardFields", fields);
        model.addAttribute("cardId", cardId);

        return prefix + "/add";
    }


    @Log(title = "信息数据新增", action = "111")
    @ApiOperation(value = "添加信息数据记录", notes = "添加信息数据记录")
    @PostMapping("add")
    @Transactional
    @ResponseBody
    public AjaxResult add(String username, Integer cardId, Integer[] fieldIds, String[] fieldValues) {
        try {
            if (fieldIds.length != fieldValues.length) {
                return success();
            }

            UserCard userCard = new UserCard();

            TsysUser tsysUser = new TsysUser();
            tsysUser.setUsername(username);
            tsysUser.setPassword(username);

            TsysUserExample example = new TsysUserExample();
            example.createCriteria().andUsernameEqualTo(tsysUser.getUsername());
            List<TsysUser> list = sysUserService.selectByExample(example);
            //判断是否存在用户
            if (list.size() > 0) {
                tsysUser.setId(list.get(0).getId());
                userCard.setUserId(list.get(0).getId());
            } else {
                //不存在用户时，自动创建用户
                String userRoleName = sysKvSettingService.getValueByDicKey(archiveUserRoleName);

                List<Integer> userRoles = new ArrayList<>();
                TsysRoleExample roleExample = new TsysRoleExample();
                roleExample.createCriteria().andNameEqualTo(userRoleName);
                userRoles.add(sysRoleService.selectByExample(roleExample).get(0).getId());

                int id = sysUserService.insertUserRoles(tsysUser, userRoles);
                tsysUser.setId(id);
                userCard.setUserId(id);
            }

            for (int i = 0; i < fieldIds.length; i++) {
                String value = new String(decoder.decode(fieldValues[i]), "UTF-8");
                UserField userField = new UserField(tsysUser.getId(), fieldIds[i], value);

                //若存在值，则覆盖
                QueryWrapper<UserField> queryWrapper = new QueryWrapper<>();
                queryWrapper.eq("user_id", tsysUser.getId()).eq("field_id", fieldIds[i]);
                List<UserField> userFields = userFieldService.list(queryWrapper);
                if (userFields.size() > 0) {
                    userField.setId(userFields.get(0).getId());
                }
                userFieldService.saveOrUpdate(userField);
            }

            userCard.setCardId(cardId);
            QueryWrapper<UserCard> userCardQueryWrapper = new QueryWrapper<>();
            userCardQueryWrapper.eq("user_id", userCard.getUserId());
            userCardQueryWrapper.eq("card_id", userCard.getCardId());
            List<UserCard> userCardList = userCardService.list(userCardQueryWrapper);
            if (userCardList.size() == 0) {
                userCardService.save(userCard);
            }
        } catch (Exception e) {
            logger.error(e.toString());
            return error();
        }

        return success();
    }

    @ApiOperation(value = "跳转修改信息数据页面", notes = "跳转修改信息数据页面", hidden = true)
    @GetMapping("/edit/{userId}/{cardId}")
    public String edit(@PathVariable("cardId") Integer cardId, @PathVariable("userId") Integer userId, Model model) {
        Card card = cardService.getById(cardId);
        List<Field> fields = fieldService.listByIds(card.getCardFieldIds());
        List<Integer> cardFieldIds = Convert.toListIntArray(card.getCardFieldIds());

        List<FieldValue> fieldValueList = (List<FieldValue>) getFieldValueList(cardFieldIds, userId).get("fieldValueList");
        UserFieldVO userFieldVO = new UserFieldVO();
        userFieldVO.setUser(sysUserService.selectByPrimaryKey(userId));
        userFieldVO.setFieldValueList(fieldValueList);

        model.addAttribute("userFieldVO", userFieldVO);
        model.addAttribute("cardFields", fields);
        model.addAttribute("cardId", cardId);

        return prefix + "/edit";
    }

    @ApiOperation(value = "跳转修改用户修改信息数据页面", notes = "跳转修改用户修改信息数据页面", hidden = true)
    @GetMapping("/userEdit/{userId}/{cardId}")
    public String userEdit(@PathVariable("cardId") Integer cardId, @PathVariable("userId") Integer userId, Model model) {
        Card card = cardService.getById(cardId);
        List<Field> fields = fieldService.listByIds(card.getCardFieldIds());
        List<Integer> cardFieldIds = Convert.toListIntArray(card.getCardFieldIds());

        List<FieldValue> fieldValueList = (List<FieldValue>) getFieldValueList(cardFieldIds, userId).get("fieldValueList");
        UserFieldVO userFieldVO = new UserFieldVO();
        userFieldVO.setUser(sysUserService.selectByPrimaryKey(userId));
        userFieldVO.setFieldValueList(fieldValueList);

        model.addAttribute("userFieldVO", userFieldVO);
        model.addAttribute("cardFields", fields);
        model.addAttribute("cardId", cardId);
        setTitle(model, new TitleVo(card.getCardName(), "信息数据管理", false, "欢迎进入详情页面", false, false));

        return prefix + "/userEdit";
    }

    @Log(title = "信息数据修改", action = "111")
    @ApiOperation(value = "修改信息数据记录", notes = "修改信息数据记录")
    @PostMapping("/edit")
    @Transactional
    @ResponseBody
    public AjaxResult editSave(Integer userId, Integer cardId, Integer[] fieldIds, String[] fieldValues) {
        try {
            if (fieldIds.length != fieldValues.length) {
                return success();
            }

            UserCard userCard = new UserCard();
            userCard.setCardId(cardId);
            userCard.setUserId(userId);
            QueryWrapper<UserCard> userCardQueryWrapper = new QueryWrapper<>();
            userCardQueryWrapper.eq("user_id", userId);
            userCardQueryWrapper.eq("card_id", cardId);
            List<UserCard> userCardList = userCardService.list(userCardQueryWrapper);
            if (userCardList.size() == 0) {
                userCardService.save(userCard);
            }

            for (int i = 0; i < fieldIds.length; i++) {
                QueryWrapper<UserField> queryWrapper = new QueryWrapper<>();
                queryWrapper.eq("user_id", userId).eq("field_id", fieldIds[i]);
                List<UserField> list = userFieldService.list(queryWrapper);
                String value = new String(decoder.decode(fieldValues[i]), "UTF-8");
                //没有数据创建，有数据更新
                if (list.size() == 0) {
                    UserField userField = new UserField(userId, fieldIds[i], value);
                    userFieldService.save(userField);
                } else {
                    UserField userField = list.get(0);
                    userField.setValue(value);
                    userFieldService.updateById(userField);
                }
            }
        } catch (Exception e) {
            logger.error(e.toString());
            return error();
        }

        return success();
    }

    @Log(title = "信息数据删除", action = "111")
    @ApiOperation(value = "删除信息数据记录", notes = "删除信息数据记录（可批量）")
    @PostMapping("/remove")
    @Transactional
    @ResponseBody
    public AjaxResult remove(String ids) {
        boolean delete = false;
        List<String> idList = Convert.toListStrArray(ids);
        if (idList.isEmpty()) {
            return error("该条信息不存在！");
        } else {
            for (String id : idList) {
                String[] split = id.split("_");
                Integer userId = Integer.parseInt(split[0]);
                Integer cardId = Integer.parseInt(split[1]);

                QueryWrapper<UserCard> userCardQueryWrapper = new QueryWrapper<>();
                userCardQueryWrapper.eq("user_id", userId);
                userCardQueryWrapper.eq("card_id", cardId);
                userCardService.remove(userCardQueryWrapper);

                Card card = cardService.getById(cardId);
                QueryWrapper<UserField> fieldQueryWrapper = new QueryWrapper<>();
                fieldQueryWrapper.eq("user_id", userId);
                fieldQueryWrapper.in("field_id", Convert.toListIntArray(card.getCardFieldIds()));
                userFieldService.remove(fieldQueryWrapper);
            }

            delete = true;

        }
        if (delete) {
            return success();
        } else {
            return error();
        }
    }

    /**
     * 批量新增信息数据表单信息
     */
    @GetMapping("/batchAdd")
    @ApiOperation(value = "跳转批量新增信息数据页面", notes = "跳转到批量新增信息数据页面", hidden = true)
    public String batchAdd(@RequestParam(value = "cardId") Integer cardId, Model model) {
        model.addAttribute("cardId", cardId);

        return prefix + "/batchAdd";
    }

    /**
     * 批量导入信息数据
     */
    @Log(title = "信息数据批量导入", action = "111")
    @Transactional(propagation = Propagation.REQUIRED)
    @PostMapping("/batchAdd")
    @ResponseBody
    public AjaxResult batchAdd(Integer cardId, @RequestParam(value = "file", required = false) MultipartFile file) {
        try {
            Map<String, Object> excelToMap = ExcelUtils.excelToMap(file);//将excel转成map
            Integer code = (Integer) excelToMap.get("code");//自动拆箱与int比大小
            if (code == 200) {
                List<String[]> rowList = (List<String[]>) excelToMap.get("rowList");
                //判断第一个单元格值是否为信息用户
                String firstCell = rowList.get(0)[0];

                if (firstCell.equals("信息用户")) {
                    String[] firstRow = rowList.get(0);
                    //获得fieldIds
                    Integer[] fieldIds = new Integer[(firstRow.length - 1)];
                    for (int i = 1; i < firstRow.length; i++) {
                        String cellValue = firstRow[i];
                        QueryWrapper<Field> queryWrapper = new QueryWrapper<>();
                        queryWrapper.eq("field_name", cellValue);
                        Integer id = fieldService.list(queryWrapper).get(0).getId();
                        fieldIds[(i - 1)] = id;
                    }

                    //获得username以及fieldValues
                    Integer resultCode;//导入后返回code
                    int sum = 0;//总需导入数
                    int successNum = 0;//成功导入数
                    //int quitNum = 0;//跳过导入数
                    int failNum = 0;//失败导入数

                    for (int i = 1; i < rowList.size(); i++) {
                        String[] cellArr = rowList.get(i);
                        //判断username是否为空
                        String username = cellArr[0];
                        if (username.trim().length() != 0) {
                            sum = sum + 1;
                            String[] fieldValues = new String[(firstRow.length - 1)];
                            for (int j = 1; j < cellArr.length; j++) {
                                if (cellArr[j] == null) {
                                    continue;
                                }
                                fieldValues[(j - 1)] = new String(encoder.encode(cellArr[j].getBytes("UTF-8")), StandardCharsets.UTF_8);
                            }
                            //获得成功导入数以及跳过数
                            resultCode = add(username, cardId, fieldIds, fieldValues).getCode();
                            switch (resultCode) {
                                case 200:
                                    successNum = successNum + 1;
                                    break;
                                default:
                                    failNum = failNum + 1;
                            }
                        }
                    }
                    String message = "总需导入用户数：" + sum + "</br>导入成功用户数：" + successNum + " </br>导入失败用户数：" + failNum + "。";
                    return success(message);
                }
            }
            return error("导入文件有误，请检查文件格式！");
        } catch (Exception e) {
            logger.info(e.toString());
            return error();
        }
    }

    /**
     * 信息数据导入模板获取
     */
    @Log(title = "信息数据导入模板获取", action = "111")
    @GetMapping("/getUserCardExcelModel")
    @ResponseBody
    public void getUserCardExcelModel(@RequestParam(value = "cardId") Integer cardId, HttpServletResponse response) throws Exception {
        //档案卡片字段
        Card card = cardService.getById(cardId);
        OutputStream out = null;
        //通过response对象获取outputStream流
        response.setContentType("application/octect-stream"); // 下载文件能正常显示中文
        response.setHeader("Content-Disposition", "attachment;filename=" + new String((card.getCardName() + "的导入模板.xls").getBytes("gb2312"), "ISO8859-1"));
        out = response.getOutputStream();

        Map<String, String> userCard = new LinkedHashMap<String, String>();

        List<Field> fields = fieldService.listByIds(card.getCardFieldIds());
        userCard.put("username", "信息用户");
        for (Field field : fields) {
            userCard.put(String.valueOf(field.getId()), field.getFieldName());
        }
        ExcelUtils.ListtoExecl(null, out, userCard);
        out.flush();
        out.close();
    }

    @ApiOperation(value = "检查信息用户是否存在记录", notes = "返回: 1-存在; 0-不存在")
    @PostMapping("/checkNameUnique")
    @ResponseBody
    public int checkNameUnique(String username, Integer[] fieldIds) {
        TsysUserExample tsysUserExample = new TsysUserExample();
        tsysUserExample.createCriteria().andUsernameEqualTo(username);
        List<TsysUser> tsysUsers = sysUserService.selectByExample(tsysUserExample);
        if (tsysUsers.size() <= 0) {
            return 0;
        }

        QueryWrapper<UserField> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("user_id", tsysUsers.get(0).getId()).in("field_id", fieldIds);
        List<UserField> list = userFieldService.list(queryWrapper);

        if (list.size() > 0) {
            return 1;
        } else {
            return 0;
        }
    }

    /**
     * @param cardFieldIds
     * @param userId
     * @return key:fieldValueList value:字段值集合; key:ifAllNull value:是否全为空（即全返回默认值）
     */
    public Map<String, Object> getFieldValueList(List<Integer> cardFieldIds, Integer userId) {

        HashMap<String, Object> map = new HashMap<>();
        //返回成默认值数(若返回成默认值数与传入id数相同，说明该条信息为空)
        int defalutValueNum = 0;

        QueryWrapper<UserField> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("user_id", userId);

        //字段-值集合
        List<FieldValue> fieldValueList = new ArrayList<>();
        List<UserField> userFields = userFieldService.list(queryWrapper);

        boolean hasField;
        for (Integer fieldId : cardFieldIds) {
            hasField = false;
            //用户字段为空时，显示默认值
            if (userFields.size() > 0) {
                //判断档案卡片字段是否含有该字段
                for (UserField uf : userFields) {
                    //含有则返回对应值
                    if (fieldId.equals(uf.getFieldId())) {
                        hasField = true;
                        Field field = fieldService.getById(fieldId);
                        if (field != null) {
                            FieldValue fieldValue = new FieldValue(uf.getId(), field, uf.getValue());
                            fieldValueList.add(fieldValue);
                        }
                        break;
                    }
                }
            }
            //否则返回默认值
            if (!hasField) {
                defalutValueNum = defalutValueNum + 1;
                Field field = fieldService.getById(fieldId);
                if (field != null) {
                    FieldValue fieldValue = new FieldValue(field, null);
                    fieldValueList.add(fieldValue);
                }
            }
        }
        map.put("fieldValueList", fieldValueList);
        if (defalutValueNum == cardFieldIds.size()) {
            map.put("ifAllNull", true);
        } else {
            map.put("ifAllNull", false);
        }
        return map;
    }


}
