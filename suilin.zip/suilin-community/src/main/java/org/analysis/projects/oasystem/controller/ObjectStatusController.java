package org.analysis.projects.oasystem.controller;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.analysis.projects.oasystem.model.auto.ObjectStatus;
import org.analysis.projects.oasystem.service.auto.ObjectStatusService;
import org.analysis.system.common.base.BaseController;
import org.analysis.system.common.domain.AjaxResult;
import org.analysis.system.common.domain.TableSplitResult;
import org.analysis.system.common.domain.Tablepar;
import org.analysis.system.common.support.Convert;
import org.analysis.system.model.custom.TitleVo;
import org.analysis.system.util.StringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * <p>
 * 状态信息 前端控制器
 * </p>
 *
 * @author Feliz
 * @since 2019-06-14
 */
@Api(tags = {"状态信息"})
@Controller
@RequestMapping("/oasystem/object-status")
public class ObjectStatusController extends BaseController {

    private static Logger logger = LoggerFactory.getLogger(ObjectStatusController.class);

    @Autowired
    private ObjectStatusService statusService;

    //跳转页面参数
    private String prefix = "projects/oasystem/status";


    @ApiOperation(value = "获取全部状态信息", notes = "获取全部状态信息")
    @PostMapping("getallstatus")
    @ResponseBody
    public AjaxResult<TableSplitResult<ObjectStatus>> getAllEegUser() {
        try {
            List<ObjectStatus> list = statusService.list();
            return AjaxResult.successDataList(list);
        } catch (Exception e) {
            logger.error(e.toString());
            return AjaxResult.error(e.getMessage());
        }
    }

    @ApiOperation(value = "跳转状态管理页面", notes = "跳转到状态管理页面", hidden = true)
    @GetMapping("view")
    @RequiresPermissions("oasystem:status:view")
    public String view(Model model) {
        setTitle(model, new TitleVo("状态列表", "状态管理", false, "欢迎进入状态管理页面", false, false));
        return prefix + "/list";
    }

    @ApiOperation(value = "获取状态列表", notes = "获取状态列表")
    @PostMapping("list")
    @RequiresPermissions("oasystem:status:list")
    @ResponseBody
    public TableSplitResult<ObjectStatus> list(Tablepar tablepar, String searchText) {

        try {
            QueryWrapper<ObjectStatus> queryWrapper = new QueryWrapper<>();
            if (StringUtils.isNotEmpty(searchText)) {
                queryWrapper.like("status_name", searchText).or().like("status_color", searchText).or().like("status_model", searchText)
                        .or().like("description", searchText);
            }

            PageHelper.startPage(tablepar.getPageNum(), tablepar.getPageSize());
            List<ObjectStatus> list = statusService.list(queryWrapper);
            PageInfo<ObjectStatus> pageInfo = new PageInfo<>(list);

            return new TableSplitResult<>(pageInfo.getPageNum(), pageInfo.getTotal(), pageInfo.getList());
        } catch (Exception e) {
            logger.error(ExceptionUtils.getFullStackTrace(e));
            return null;
        }
    }


    @ApiOperation(value = "跳转新增状态页面", notes = "跳转新增状态页面", hidden = true)
    @GetMapping("/add")
    public String add() {
        return prefix + "/add";
    }

    @ApiOperation(value = "添加状态", notes = "添加新的状态")
    @PostMapping("add")
    @RequiresPermissions("oasystem:status:add")
    @ResponseBody
    public AjaxResult add(ObjectStatus objectStatus) {
        boolean save = statusService.save(objectStatus);
        if (save) {
            return success();
        } else {
            return error();
        }
    }

    @ApiOperation(value = "删除状态", notes = "根据id删除状态（批量）")
    @PostMapping("remove")
    @RequiresPermissions("oasystem:status:remove")
    @ResponseBody
    public AjaxResult remove(String ids) {
        List<String> idList= Convert.toListStrArray(ids);
        boolean save = statusService.removeByIds(idList);
        if (save) {
            return success();
        } else {
            return error();
        }
    }


    @ApiOperation(value = "检查状态名字是否存在", notes = "传入: name; 返回: 1-存在; 0-不存在")
    @PostMapping("checkNameUnique")
    @ResponseBody
    public Integer checkNameUnique(String statusName) {
        QueryWrapper<ObjectStatus> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("status_name", statusName);
        List<ObjectStatus> list = statusService.list(queryWrapper);
        if (list.size() > 0) {
            return 1;
        } else {
            return 0;
        }
    }

    @ApiOperation(value = "跳转状态修改页面", notes = "跳转到状态修改页面", hidden = true)
    @GetMapping("/edit/{id}")
    public String edit(@PathVariable("id") String id, ModelMap mmap) {
        mmap.put("status", statusService.getById(id));
        return prefix + "/edit";
    }

    @ApiOperation(value = "修改状态", notes = "修改保存状态")
    @PostMapping("/edit")
    @RequiresPermissions("oasystem:status:edit")
    @ResponseBody
    public AjaxResult editSave(ObjectStatus objectStatus) {
        boolean b = statusService.updateById(objectStatus);
        return b ? success() : error();
    }

}

