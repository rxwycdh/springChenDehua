package org.analysis.projects.ppp.minapp.common;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.analysis.projects.ppp.model.auto.Feedback;
import org.analysis.projects.ppp.model.auto.ProjectTag;
import org.analysis.projects.ppp.model.auto.Tag;
import org.analysis.projects.ppp.service.auto.FeedbackService;
import org.analysis.projects.ppp.service.auto.ProjectTagService;
import org.analysis.projects.ppp.service.auto.TagService;
import org.analysis.system.common.base.BaseController;
import org.analysis.system.common.domain.AjaxResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * 微信小程序用户版获取轮播图接口
 */
@RestController
@Api(tags = {"微信小程序-通用接口"})
@RequestMapping("/wx/ppp/minapp")
public class WxMaCommonController extends BaseController {

    private static Logger logger = LoggerFactory.getLogger(WxMaCommonController.class);

    @Autowired
    private FeedbackService feedbackService;
    @Autowired
    private TagService tagService;
    @Autowired
    private ProjectTagService projectTagService;

    @ApiOperation(value = "用户反馈", notes = "用户反馈")
    @GetMapping("/feedback")
    public AjaxResult feedback(@ApiParam(name = "email", value = "邮箱") String email,
                          @ApiParam(name = "content", value = "反馈信息") String content) {
        try {
            Feedback feedback = new Feedback();
            feedback.setEmail(email);
            feedback.setFeedback(content);
            feedback.setCreateTime(LocalDateTime.now());
            boolean save = feedbackService.save(feedback);
            return save ? success() : error();
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            return error();
        }
    }

    @ApiOperation(value = "获取热门标签", notes = "获取热门标签")
    @GetMapping("/getHotTags")
    public AjaxResult<List<Tag>> getHotTags() {

        try {
            QueryWrapper<ProjectTag> queryWrapper = new QueryWrapper<>();
            //取tag_id重复出现次数最多的10条记录
            queryWrapper.groupBy("tag_id");
            queryWrapper.orderByDesc("count(*)");
            queryWrapper.last("limit 10");
            List<ProjectTag> projectTags = projectTagService.list(queryWrapper);

            List<Tag> list = new ArrayList<>();
            for (ProjectTag pt : projectTags) {
                Tag tag = tagService.getById(pt.getTagId());
                list.add(tag);
            }

            return AjaxResult.successData(list);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            return AjaxResult.error();
        }
    }

    /**
     * 上传文件
     */
    @PostMapping("/upload")
    @ApiOperation(value = "上传文件", notes = "上传文件")
    public Integer updateFile(@RequestParam("file") MultipartFile file) {
        try {
            if (!file.isEmpty()) {
                //插入文件存储表
                Integer id = sysDatasService.insertSelective(file);
                if (id != null) {
                    return id;
                }
            }
            return null;
        } catch (Exception e) {
            return null;
        }
    }
}
