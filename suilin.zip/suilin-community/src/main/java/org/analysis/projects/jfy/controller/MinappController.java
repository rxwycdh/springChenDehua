package org.analysis.projects.jfy.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.analysis.projects.jfy.model.auto.PropertyInformation;
import org.analysis.projects.jfy.service.auto.PropertyInformationService;
import org.analysis.system.common.base.BaseController;
import org.analysis.system.common.domain.AjaxResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.time.LocalDateTime;

/**
 * <p>
 * 小程序接口 前端控制器
 * </p>
 *
 * @author Feliz
 * @since 2019-06-29
 */
@Api(tags = {"小程序接口"})
@Controller
@RequestMapping("/jfyminapp")
public class MinappController extends BaseController {

    @Autowired
    private PropertyInformationService propertyInformationService;

    @ApiOperation(value = "添加业主信息", notes = "小程序添加新业主信息接口")
    @PostMapping("/addpropertyinfo")
    @ResponseBody
    public AjaxResult addpropertyinfo(PropertyInformation propertyInformation) {
        propertyInformation.setCreateTime(LocalDateTime.now());
        boolean save = propertyInformationService.save(propertyInformation);
        if (save) {
            return success();
        } else {
            return error();
        }
    }
}
