package org.analysis.projects.ppp.service.auto.impl;

import org.analysis.projects.ppp.model.auto.ServerNotice;
import org.analysis.projects.ppp.mapper.auto.ServerNoticeMapper;
import org.analysis.projects.ppp.service.auto.ServerNoticeService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 服务版通知信息 服务实现类
 * </p>
 *
 * @author Feliz
 * @since 2020-04-01
 */
@Service
public class ServerNoticeServiceImpl extends ServiceImpl<ServerNoticeMapper, ServerNotice> implements ServerNoticeService {

}
