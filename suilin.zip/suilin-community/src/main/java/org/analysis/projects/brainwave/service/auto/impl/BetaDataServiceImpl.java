package org.analysis.projects.brainwave.service.auto.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.analysis.projects.brainwave.mapper.auto.BetaDataMapper;
import org.analysis.projects.brainwave.model.auto.BetaData;
import org.analysis.projects.brainwave.service.auto.BetaDataService;
import org.springframework.stereotype.Service;

/**
 * <p>
 * beta脑波数据表 服务实现类
 * </p>
 *
 * @author Feliz
 * @since 2019-06-06
 */
@Service
public class BetaDataServiceImpl extends ServiceImpl<BetaDataMapper, BetaData> implements BetaDataService {

}
