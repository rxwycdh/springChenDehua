package org.analysis.projects.suilin.model.auto;

import java.math.BigDecimal;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import java.time.LocalDateTime;
import com.baomidou.mybatisplus.annotation.TableLogic;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * <p>
 * 帖子表
 * </p>
 *
 * @author Feliz
 * @since 2020-08-19
 */
@TableName("suilin_post_info")
@ApiModel(value="PostInfo对象", description="帖子表")
public class PostInfo implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "小区编号")
    @TableField("suilin_community_id")
    private Integer suilinCommunityId;

    @ApiModelProperty(value = "用户号")
    @TableField("suilin_user_id")
    private Integer suilinUserId;

    @ApiModelProperty(value = "阅读量")
    @TableField("read_count")
    private Integer readCount;

    @ApiModelProperty(value = "点赞数")
    @TableField("like_count")
    private Integer likeCount;

    @ApiModelProperty(value = "评论数")
    @TableField("comment_count")
    private Integer commentCount;

    @ApiModelProperty(value = "分享用户号，按照逗号隔开")
    @TableField("share_user")
    private String shareUser;

    @ApiModelProperty(value = "点赞用户号，按照逗号隔开")
    @TableField("like_user")
    private String likeUser;

    @ApiModelProperty(value = "标题")
    @TableField("title")
    private String title;

    @ApiModelProperty(value = "内容")
    @TableField("content")
    private String content;

    @ApiModelProperty(value = "关闭评论：1，开启评论：0")
    @TableField("comment_closed")
    private Integer commentClosed;

    @ApiModelProperty(value = "排序，权重,显示从大到小")
    @TableField("sort")
    private BigDecimal sort;

    @ApiModelProperty(value = "逻辑删除；0：未删除；1：已删除")
    @TableField("deleted")
    @TableLogic
    private Integer deleted;

    @ApiModelProperty(value = "发布时间")
    @TableField("create_time")
    private LocalDateTime createTime;

    @ApiModelProperty(value = "更新时间")
    @TableField("update_time")
    private LocalDateTime updateTime;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getSuilinCommunityId() {
        return suilinCommunityId;
    }

    public void setSuilinCommunityId(Integer suilinCommunityId) {
        this.suilinCommunityId = suilinCommunityId;
    }

    public Integer getSuilinUserId() {
        return suilinUserId;
    }

    public void setSuilinUserId(Integer suilinUserId) {
        this.suilinUserId = suilinUserId;
    }

    public Integer getReadCount() {
        return readCount;
    }

    public void setReadCount(Integer readCount) {
        this.readCount = readCount;
    }

    public Integer getLikeCount() {
        return likeCount;
    }

    public void setLikeCount(Integer likeCount) {
        this.likeCount = likeCount;
    }

    public Integer getCommentCount() {
        return commentCount;
    }

    public void setCommentCount(Integer commentCount) {
        this.commentCount = commentCount;
    }

    public String getShareUser() {
        return shareUser;
    }

    public void setShareUser(String shareUser) {
        this.shareUser = shareUser;
    }

    public String getLikeUser() {
        return likeUser;
    }

    public void setLikeUser(String likeUser) {
        this.likeUser = likeUser;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public Integer getCommentClosed() {
        return commentClosed;
    }

    public void setCommentClosed(Integer commentClosed) {
        this.commentClosed = commentClosed;
    }

    public BigDecimal getSort() {
        return sort;
    }

    public void setSort(BigDecimal sort) {
        this.sort = sort;
    }

    public Integer getDeleted() {
        return deleted;
    }

    public void setDeleted(Integer deleted) {
        this.deleted = deleted;
    }

    public LocalDateTime getCreateTime() {
        return createTime;
    }

    public void setCreateTime(LocalDateTime createTime) {
        this.createTime = createTime;
    }

    public LocalDateTime getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(LocalDateTime updateTime) {
        this.updateTime = updateTime;
    }

    @Override
    public String toString() {
        return "PostInfo{" +
        "id=" + id +
        ", suilinCommunityId=" + suilinCommunityId +
        ", suilinUserId=" + suilinUserId +
        ", readCount=" + readCount +
        ", likeCount=" + likeCount +
        ", commentCount=" + commentCount +
        ", shareUser=" + shareUser +
        ", likeUser=" + likeUser +
        ", title=" + title +
        ", content=" + content +
        ", commentClosed=" + commentClosed +
        ", sort=" + sort +
        ", deleted=" + deleted +
        ", createTime=" + createTime +
        ", updateTime=" + updateTime +
        "}";
    }
}
