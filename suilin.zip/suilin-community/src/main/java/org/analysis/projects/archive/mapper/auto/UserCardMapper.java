package org.analysis.projects.archive.mapper.auto;

import org.analysis.projects.archive.model.auto.UserCard;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 用户档案连接表 Mapper 接口
 * </p>
 *
 * @author Feliz
 * @since 2020-05-14
 */
public interface UserCardMapper extends BaseMapper<UserCard> {

}
