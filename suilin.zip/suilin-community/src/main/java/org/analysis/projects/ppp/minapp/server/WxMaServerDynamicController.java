package org.analysis.projects.ppp.minapp.server;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.analysis.projects.ppp.model.auto.*;
import org.analysis.projects.ppp.model.custom.ClientUserIF;
import org.analysis.projects.ppp.model.custom.DynamicIF;
import org.analysis.projects.ppp.model.custom.NoticeIF;
import org.analysis.projects.ppp.service.auto.*;
import org.analysis.system.common.base.BaseController;
import org.analysis.system.common.domain.AjaxResult;
import org.analysis.system.common.domain.TableSplitResult;
import org.analysis.system.common.domain.Tablepar;
import org.apache.commons.beanutils.BeanUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@RestController
@Api(tags = {"微信小程序服务版-动态接口"})
@RequestMapping("/wx/pppserver/minapp/dynamic")
public class WxMaServerDynamicController extends BaseController {

    private static Logger logger = LoggerFactory.getLogger(WxMaServerDynamicController.class);

    @Autowired
    private ProjectDynamicService projectDynamicService;
    @Autowired
    private ProjectService projectService;
    @Autowired
    private ProjectTypeService projectTypeService;
    @Autowired
    private ServerNoticeService serverNoticeService;
    @Autowired
    private ClientUserService clientUserService;
    @Autowired
    private ServerUserService serverUserService;

    @ApiOperation(value = "获取项目动态列表", notes = "获取个人用户项目动态列表")
    @GetMapping("/project")
    public TableSplitResult<DynamicIF> projectList(Tablepar tablepar,
                                                   @ApiParam(name = "id", value = "用户id") Integer id) {

        try {
            QueryWrapper<ProjectDynamic> queryWrapper = new QueryWrapper<>();
            queryWrapper.eq("reply_id", id);
            queryWrapper.orderByDesc("state != 0, state", "applicant_time is null, applicant_time");
            PageHelper.startPage(tablepar.getPageNum(), tablepar.getPageSize());
            List<ProjectDynamic> projectDynamics = projectDynamicService.list(queryWrapper);
            PageInfo<ProjectDynamic> pageInfo = new PageInfo<>(projectDynamics);

            List<DynamicIF> list = new ArrayList<>();
            for (ProjectDynamic pd : projectDynamics) {
                DynamicIF dynamicIF = new DynamicIF();

                BeanUtils.copyProperties(dynamicIF, pd);

                Project project = projectService.getById(pd.getProjectId());
                if (project == null) {
                    continue;
                }
                dynamicIF.setProjectTitle(project.getTitle());
                ProjectType projectType = projectTypeService.getById(project.getTypeId());
                dynamicIF.setProjectType(projectType!=null ? projectType.getName() : "");

                ClientUser applicantUser = clientUserService.getById(pd.getApplicantId());
                if (dynamicIF.getState() == 0) {
                    dynamicIF.setDynamicContent("#"+ applicantUser.getName() +"#提交了报名申请，点击查看详情。");
                    dynamicIF.setDynamicTime(pd.getApplicantTime());
                } else if (dynamicIF.getState() == 1) {
                    dynamicIF.setDynamicContent("#"+ applicantUser.getName() +"#面试邀请已发出，请等待应聘者参与应试。面试说明："+pd.getInterviewNote());
                    dynamicIF.setDynamicTime(pd.getReplyTime());
                } else if (dynamicIF.getState() == 2) {
                    dynamicIF.setDynamicContent("#"+ applicantUser.getName() +"#面试已拒绝。");
                    dynamicIF.setDynamicTime(pd.getReplyTime());
                } else {
                    dynamicIF.setDynamicContent("#"+ applicantUser.getName() +"#项目已终止招募。");
                    dynamicIF.setDynamicTime(pd.getReplyTime());
                }

                list.add(dynamicIF);
            }

            return new TableSplitResult<>(pageInfo.getPageNum(), pageInfo.getTotal(), list);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            return null;
        }
    }

    @ApiOperation(value = "获取通知列表", notes = "获取用户通知列表")
    @GetMapping("/notice")
    public TableSplitResult<NoticeIF> noticeList(Tablepar tablepar,
                                                 @ApiParam(name = "id", value = "用户id") Integer id) {

        try {
            QueryWrapper<ServerNotice> queryWrapper = new QueryWrapper<>();
            //匹配目标用户
            queryWrapper.and(wrapper -> wrapper
                    .eq("target_user", "").or()
                    .isNull("target_user").or()
                    .eq("target_user", id).or()
                    .likeRight("target_user", id+",").or()
                    .likeLeft("target_user", ","+id).or()
                    .like("target_user", ","+id+",")
            );

            queryWrapper.orderByDesc("create_time is null, create_time");
            PageHelper.startPage(tablepar.getPageNum(), tablepar.getPageSize());
            List<ServerNotice> serverNotices = serverNoticeService.list(queryWrapper);
            PageInfo<ServerNotice> pageInfo = new PageInfo<>(serverNotices);

            List<NoticeIF> list = new ArrayList<>();
            for (ServerNotice sn : serverNotices) {
                NoticeIF noticeIF = new NoticeIF();
                BeanUtils.copyProperties(noticeIF, sn);

                list.add(noticeIF);
            }

            return new TableSplitResult<>(pageInfo.getPageNum(), pageInfo.getTotal(), list);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            return null;
        }
    }

    @ApiOperation(value = "获取报名者信息", notes = "获取报名者信息")
    @GetMapping("/getApplicant")
    public AjaxResult<ClientUserIF> getApplicant(@ApiParam(name = "id", value = "动态id") Integer id, HttpServletRequest request) {

        try {
            ProjectDynamic projectDynamic = projectDynamicService.getById(id);
            Integer applicantId = projectDynamic.getApplicantId();
            ClientUser clientUser = clientUserService.getById(applicantId);
            ClientUserIF clientUserIF = new ClientUserIF();
            BeanUtils.copyProperties(clientUserIF, clientUser);
            String avatarUrl = "https://" + request.getServerName() + request.getContextPath() + "/FileController/viewFileByFileId/" + clientUser.getAvatarId();
            clientUserIF.setAvatarUrl(avatarUrl);

            return AjaxResult.successData(clientUserIF);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            return AjaxResult.error();
        }
    }

    @ApiOperation(value = "邀请面试", notes = "邀请面试")
    @PostMapping("/invitation")
    public AjaxResult invitation(ServerUser serverUser,
                                 @ApiParam(name = "dynamicId", value = "动态id") Integer dynamicId,
                                 @ApiParam(name = "interviewNote", value = "面试说明") String interviewNote) {

        try {

            ProjectDynamic projectDynamic = projectDynamicService.getById(dynamicId);
            if (!serverUser.getId().equals(projectDynamic.getReplyId())) {
                logger.error("请求错误：请求用户无权限。");
                return error();
            }

            serverUser.setUpdateTime(LocalDateTime.now());
            boolean editUser = serverUserService.updateById(serverUser);

            projectDynamic.setState(1);
            projectDynamic.setInterviewNote(interviewNote);
            projectDynamic.setReplyTime(LocalDateTime.now());
            boolean edit = projectDynamicService.updateById(projectDynamic);
            return (editUser && edit) ? success() : error();
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            return null;
        }
    }

    @ApiOperation(value = "拒绝面试", notes = "拒绝面试")
    @PostMapping("/refuse")
    public AjaxResult refuse(@ApiParam(name = "id", value = "动态id") Integer id,
                             @ApiParam(name = "userId", value = "用户id") Integer userId) {

        try {
            ProjectDynamic projectDynamic = projectDynamicService.getById(id);
            if (!userId.equals(projectDynamic.getReplyId())) {
                logger.error("请求错误：请求用户无权限。");
                return error();
            }

            projectDynamic.setState(2);
            projectDynamic.setReplyTime(LocalDateTime.now());
            boolean edit = projectDynamicService.updateById(projectDynamic);
            return edit ? success() : error();
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            return error();
        }
    }
}
