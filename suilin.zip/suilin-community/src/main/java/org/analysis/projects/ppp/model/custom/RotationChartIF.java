package org.analysis.projects.ppp.model.custom;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;

/**
 * <p>
 * 轮播信息表
 * </p>
 *
 * @author Feliz
 * @since 2020-03-29
 */
@ApiModel(value="RotationChartIF对象", description="轮播信息表")
public class RotationChartIF implements Serializable {

    private static final long serialVersionUID = 1L;

    private Integer id;

    @ApiModelProperty(value = "轮播标题")
    private String title;

    @ApiModelProperty(value = "轮播图片url")
    private String imageUrl;

    @ApiModelProperty(value = "是否跳转；1：跳转；0：不跳转")
    private Integer jumped;

    @ApiModelProperty(value = "跳转链接")
    private String jumpUrl;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Integer getJumped() {
        return jumped;
    }

    public void setJumped(Integer jumped) {
        this.jumped = jumped;
    }

    public String getJumpUrl() {
        return jumpUrl;
    }

    public void setJumpUrl(String jumpUrl) {
        this.jumpUrl = jumpUrl;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    @Override
    public String toString() {
        return "RotationChartIF{" +
                "id=" + id +
                ", title='" + title + '\'' +
                ", imageUrl='" + imageUrl + '\'' +
                ", jumped=" + jumped +
                ", jumpUrl='" + jumpUrl + '\'' +
                '}';
    }
}
