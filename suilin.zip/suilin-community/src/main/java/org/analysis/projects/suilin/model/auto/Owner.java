package org.analysis.projects.suilin.model.auto;

import java.math.BigDecimal;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import java.time.LocalDateTime;
import com.baomidou.mybatisplus.annotation.TableLogic;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * <p>
 * 业主信息
 * </p>
 *
 * @author Feliz
 * @since 2020-08-18
 */
@TableName("suilin_owner")
@ApiModel(value="Owner对象", description="业主信息")
public class Owner implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "用户id")
    @TableField("suilin_user_id")
    private Integer suilinUserId;

    @ApiModelProperty(value = "姓名")
    @TableField("name")
    private String name;

    @ApiModelProperty(value = "性别；0：未知；1：男性；2：女性")
    @TableField("gender")
    private Integer gender;

    @ApiModelProperty(value = "手机号码")
    @TableField("phone")
    private String phone;

    @ApiModelProperty(value = "证件类型")
    @TableField("id_card_type")
    private String idCardType;

    @ApiModelProperty(value = "证件号码")
    @TableField("id_card")
    private String idCard;

    @ApiModelProperty(value = "身份证照file-id")
    @TableField("id_card_file_id")
    private Integer idCardFileId;

    @ApiModelProperty(value = "房产证照file-id")
    @TableField("property_file_id")
    private Integer propertyFileId;

    @ApiModelProperty(value = "楼栋&房号")
    @TableField("room_number")
    private String roomNumber;

    @ApiModelProperty(value = "房屋面积")
    @TableField("room_area")
    private BigDecimal roomArea;

    @ApiModelProperty(value = "职位")
    @TableField("position")
    private String position;

    @ApiModelProperty(value = "逻辑删除；0：未删除；1：已删除")
    @TableField("deleted")
    @TableLogic
    private Integer deleted;

    @ApiModelProperty(value = "注册时间")
    @TableField("create_time")
    private LocalDateTime createTime;

    @ApiModelProperty(value = "修改时间")
    @TableField("update_time")
    private LocalDateTime updateTime;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getSuilinUserId() {
        return suilinUserId;
    }

    public void setSuilinUserId(Integer suilinUserId) {
        this.suilinUserId = suilinUserId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getGender() {
        return gender;
    }

    public void setGender(Integer gender) {
        this.gender = gender;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getIdCardType() {
        return idCardType;
    }

    public void setIdCardType(String idCardType) {
        this.idCardType = idCardType;
    }

    public String getIdCard() {
        return idCard;
    }

    public void setIdCard(String idCard) {
        this.idCard = idCard;
    }

    public Integer getIdCardFileId() {
        return idCardFileId;
    }

    public void setIdCardFileId(Integer idCardFileId) {
        this.idCardFileId = idCardFileId;
    }

    public Integer getPropertyFileId() {
        return propertyFileId;
    }

    public void setPropertyFileId(Integer propertyFileId) {
        this.propertyFileId = propertyFileId;
    }

    public String getRoomNumber() {
        return roomNumber;
    }

    public void setRoomNumber(String roomNumber) {
        this.roomNumber = roomNumber;
    }

    public BigDecimal getRoomArea() {
        return roomArea;
    }

    public void setRoomArea(BigDecimal roomArea) {
        this.roomArea = roomArea;
    }

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public Integer getDeleted() {
        return deleted;
    }

    public void setDeleted(Integer deleted) {
        this.deleted = deleted;
    }

    public LocalDateTime getCreateTime() {
        return createTime;
    }

    public void setCreateTime(LocalDateTime createTime) {
        this.createTime = createTime;
    }

    public LocalDateTime getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(LocalDateTime updateTime) {
        this.updateTime = updateTime;
    }

    @Override
    public String toString() {
        return "Owner{" +
        "id=" + id +
        ", suilinUserId=" + suilinUserId +
        ", name=" + name +
        ", gender=" + gender +
        ", phone=" + phone +
        ", idCardType=" + idCardType +
        ", idCard=" + idCard +
        ", idCardFileId=" + idCardFileId +
        ", propertyFileId=" + propertyFileId +
        ", roomNumber=" + roomNumber +
        ", roomArea=" + roomArea +
        ", position=" + position +
        ", deleted=" + deleted +
        ", createTime=" + createTime +
        ", updateTime=" + updateTime +
        "}";
    }
}
