package org.analysis.projects.suilin.model.auto;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import java.time.LocalDateTime;
import com.baomidou.mybatisplus.annotation.TableLogic;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * <p>
 * 帖子评论表
 * </p>
 *
 * @author Feliz
 * @since 2020-08-19
 */
@TableName("suilin_post_comment")
@ApiModel(value="PostComment对象", description="帖子评论表")
public class PostComment implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "所属帖子编号")
    @TableField("post_info_id")
    private Integer postInfoId;

    @ApiModelProperty(value = "用户号")
    @TableField("suilin_user_id")
    private Integer suilinUserId;

    @ApiModelProperty(value = "点赞用户好，按照逗号隔开")
    @TableField("like_user")
    private String likeUser;

    @ApiModelProperty(value = "点赞数")
    @TableField("like_count")
    private Integer likeCount;

    @ApiModelProperty(value = "评论回复数")
    @TableField("reply_count")
    private Integer replyCount;

    @ApiModelProperty(value = "评论内容")
    @TableField("comment")
    private String comment;

    @ApiModelProperty(value = "逻辑删除；0：未删除；1：已删除")
    @TableField("deleted")
    @TableLogic
    private Integer deleted;

    @ApiModelProperty(value = "发布时间")
    @TableField("create_time")
    private LocalDateTime createTime;

    @ApiModelProperty(value = "更新时间")
    @TableField("update_time")
    private LocalDateTime updateTime;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getPostInfoId() {
        return postInfoId;
    }

    public void setPostInfoId(Integer postInfoId) {
        this.postInfoId = postInfoId;
    }

    public Integer getSuilinUserId() {
        return suilinUserId;
    }

    public void setSuilinUserId(Integer suilinUserId) {
        this.suilinUserId = suilinUserId;
    }

    public String getLikeUser() {
        return likeUser;
    }

    public void setLikeUser(String likeUser) {
        this.likeUser = likeUser;
    }

    public Integer getLikeCount() {
        return likeCount;
    }

    public void setLikeCount(Integer likeCount) {
        this.likeCount = likeCount;
    }

    public Integer getReplyCount() {
        return replyCount;
    }

    public void setReplyCount(Integer replyCount) {
        this.replyCount = replyCount;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public Integer getDeleted() {
        return deleted;
    }

    public void setDeleted(Integer deleted) {
        this.deleted = deleted;
    }

    public LocalDateTime getCreateTime() {
        return createTime;
    }

    public void setCreateTime(LocalDateTime createTime) {
        this.createTime = createTime;
    }

    public LocalDateTime getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(LocalDateTime updateTime) {
        this.updateTime = updateTime;
    }

    @Override
    public String toString() {
        return "PostComment{" +
        "id=" + id +
        ", postInfoId=" + postInfoId +
        ", suilinUserId=" + suilinUserId +
        ", likeUser=" + likeUser +
        ", likeCount=" + likeCount +
        ", replyCount=" + replyCount +
        ", comment=" + comment +
        ", deleted=" + deleted +
        ", createTime=" + createTime +
        ", updateTime=" + updateTime +
        "}";
    }
}
