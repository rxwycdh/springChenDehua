package org.analysis.projects.ppp.service.auto;

import org.analysis.projects.ppp.model.auto.ArticleTag;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 文章标签中间表 服务类
 * </p>
 *
 * @author Feliz
 * @since 2020-03-29
 */
public interface ArticleTagService extends IService<ArticleTag> {

}
