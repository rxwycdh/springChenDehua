package org.analysis.projects.brainwave.mapper.auto;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.analysis.projects.brainwave.model.auto.EegScene;
import org.apache.ibatis.annotations.CacheNamespace;

/**
 * <p>
 * 脑波采集场景 Mapper 接口
 * </p>
 *
 * @author Feliz
 * @since 2019-06-06
 */
@DS("db_brainwave")
@CacheNamespace(flushInterval = 3600000, size = 4096)
public interface EegSceneMapper extends BaseMapper<EegScene> {

}
