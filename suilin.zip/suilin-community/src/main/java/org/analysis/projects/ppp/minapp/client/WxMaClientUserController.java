package org.analysis.projects.ppp.minapp.client;

import cn.binarywang.wx.miniapp.api.WxMaService;
import cn.binarywang.wx.miniapp.bean.WxMaJscode2SessionResult;
import cn.binarywang.wx.miniapp.bean.WxMaPhoneNumberInfo;
import cn.binarywang.wx.miniapp.bean.WxMaUserInfo;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.analysis.projects.ppp.model.auto.ClientUser;
import org.analysis.projects.ppp.model.custom.ClientUserIF;
import org.analysis.projects.ppp.service.auto.ClientUserService;
import org.analysis.system.common.base.BaseController;
import org.analysis.system.common.domain.AjaxResult;
import org.analysis.system.model.auto.TsysFile;
import org.analysis.wx.common.utils.JsonUtils;
import org.analysis.wx.miniapp.config.WxMaConfiguration;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.time.LocalDateTime;
import java.util.List;

/**
 * 微信小程序用户版用户接口
 */
@RestController
@Api(tags = {"微信小程序用户版-用户接口"})
@RequestMapping("/wx/pppclient/minapp/user")
public class WxMaClientUserController extends BaseController {
    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    private final String appid = "wxce0043b393ea24cb";

    @Autowired
    private ClientUserService clientUserService;

    /**
     * 登陆接口
     */
    @GetMapping("/login")
    @ApiOperation(value = "登陆接口", notes = "微信小程序用户登陆")
    public AjaxResult<ClientUserIF> login(String code, HttpServletRequest request) {

        if (StringUtils.isBlank(code)) {
            return AjaxResult.error("empty code");
        }

        final WxMaService wxService = WxMaConfiguration.getMaService(appid);

        try {
            WxMaJscode2SessionResult session = wxService.getUserService().getSessionInfo(code);

            //检测是否已注册用户
            QueryWrapper<ClientUser> queryWrapper = new QueryWrapper<>();
            queryWrapper.eq("openid", session.getOpenid());
            List<ClientUser> list = clientUserService.list(queryWrapper);

            //若已注册返回用户信息
            if (list.size() == 0) {

                ClientUserIF clientUserIF = new ClientUserIF(null, null, session.getSessionKey());
                return AjaxResult.successData(clientUserIF);

            } else {
                ClientUserIF clientUserIF = new ClientUserIF();
                ClientUser clientUser = list.get(0);
                BeanUtils.copyProperties(clientUserIF, clientUser);
                String avatarUrl = "https://" + request.getServerName() + request.getContextPath() + "/FileController/viewFileByFileId/" + clientUser.getAvatarId();
                clientUserIF.setAvatarUrl(avatarUrl);
                clientUserIF.setSessionKey(session.getSessionKey());

                return AjaxResult.successData(clientUserIF);
            }

        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            return AjaxResult.error("login error");
        }
    }

    /**
     * <pre>
     * 注册接口
     * </pre>
     */
    @GetMapping("/register")
    @Transactional
    @ApiOperation(value = "注册接口", notes = "微信小程序初次获取用户微信信息并注册用户")
    public AjaxResult<ClientUserIF> register(String sessionKey, String signature, String rawData, String encryptedData, String iv, HttpServletRequest request) {

        final WxMaService wxService = WxMaConfiguration.getMaService(appid);

        try {
            // 用户信息校验
            if (!wxService.getUserService().checkUserInfo(sessionKey, rawData, signature)) {
                return AjaxResult.error("user check failed");
            }

            // 解密用户信息
            WxMaUserInfo userInfo = wxService.getUserService().getUserInfo(sessionKey, encryptedData, iv);

            //检测是否已注册用户
            QueryWrapper<ClientUser> queryWrapper = new QueryWrapper<>();
            queryWrapper.eq("openid", userInfo.getOpenId());
            List<ClientUser> list = clientUserService.list(queryWrapper);
            //若已注册直接返回用户信息
            if (list.size() != 0) {
                ClientUserIF clientUserIF = new ClientUserIF();
                ClientUser clientUser = list.get(0);
                BeanUtils.copyProperties(clientUserIF, clientUser);
                String avatarUrl = "https://" + request.getServerName() + request.getContextPath() + "/FileController/viewFileByFileId/" + clientUser.getAvatarId();
                clientUserIF.setAvatarUrl(avatarUrl);
                clientUserIF.setSessionKey(sessionKey);

                logger.info("#####用户已注册,直接返回用户信息-openid:" + userInfo.getOpenId());
                return AjaxResult.successData(clientUserIF);
            }

            ClientUser clientUser = new ClientUser();
            clientUser.setName(userInfo.getNickName());
            clientUser.setGender(Integer.parseInt(userInfo.getGender()));
            //上传头像到服务器
            int avatarId = sysFileService.insertUrl(userInfo.getNickName(), userInfo.getAvatarUrl(), "userSideAvatar_" + userInfo.getOpenId() + ".png");
            clientUser.setAvatarId(avatarId);
            clientUser.setOpenid(userInfo.getOpenId());
            clientUser.setUnionid(userInfo.getUnionId());
//            clientUser.setCountry(userInfo.getCountry());
//            clientUser.setProvince(userInfo.getProvince());
//            clientUser.setCity(userInfo.getCity());
            clientUser.setCreateTime(LocalDateTime.now());
            boolean save = clientUserService.save(clientUser);

            ClientUserIF clientUserIF = new ClientUserIF();
            BeanUtils.copyProperties(clientUserIF, clientUser);
            String avatarUrl = "https://" + request.getServerName() + request.getContextPath() + "/FileController/viewFileByFileId/" + clientUser.getAvatarId();
            clientUserIF.setAvatarUrl(avatarUrl);
            clientUserIF.setSessionKey(sessionKey);
            if (save) {
                logger.info("#####注册用户成功-openid:" + userInfo.getOpenId());
                return AjaxResult.successData(clientUserIF);
            } else {
                return AjaxResult.error("register error");
            }
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            return AjaxResult.error("register error");
        }
    }


    @GetMapping("/getUserInfo/{id}")
    @ApiOperation(value = "获取用户信息", notes = "微信小程序获取用户信息")
    public AjaxResult<ClientUserIF> getUserInfo(@ApiParam(name = "id", value = "用户id") @PathVariable("id") Integer id, HttpServletRequest request) {

        try {
            ClientUser clientUser = clientUserService.getById(id);
            ClientUserIF clientUserIF = new ClientUserIF();
            BeanUtils.copyProperties(clientUserIF, clientUser);

            String avatarUrl = "https://" + request.getServerName() + request.getContextPath() + "/FileController/viewFileByFileId/" + clientUser.getAvatarId();
            clientUserIF.setAvatarUrl(avatarUrl);

            return AjaxResult.successData(clientUserIF);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            return AjaxResult.error("getUserInfo error");
        }

    }

    @GetMapping("/editUserInfo")
    @Transactional
    @ApiOperation(value = "修改用户信息", notes = "微信小程序修改用户信息")
    public AjaxResult editUserInfo(ClientUser clientUser, @ApiParam(name = "dataId", value = "文件数据id") Integer dataId) {

        try {
            if (dataId != null) {
                //修改文件
                TsysFile record = sysFileService.selectByPrimaryKey(clientUser.getAvatarId());
                sysFileService.updateByPrimaryKey(record, dataId);
            }

            clientUser.setUpdateTime(LocalDateTime.now());
            boolean edit = clientUserService.updateById(clientUser);
            return edit ? success() : error();
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            return AjaxResult.error("editUserInfo error");
        }

    }

    /**
     * <pre>
     * 获取用户绑定手机号信息
     * </pre>
     */
    @GetMapping("/phone")
    @ApiOperation(value = "获取用户绑定手机号信息", notes = "微信小程序获取用户绑定手机号信息")
    public String phone(String sessionKey, String signature, String rawData, String encryptedData, String iv) {
        final WxMaService wxService = WxMaConfiguration.getMaService(appid);

        // 用户信息校验
        if (!wxService.getUserService().checkUserInfo(sessionKey, rawData, signature)) {
            return "user check failed";
        }

        // 解密
        WxMaPhoneNumberInfo phoneNoInfo = wxService.getUserService().getPhoneNoInfo(sessionKey, encryptedData, iv);

        return JsonUtils.toJson(phoneNoInfo);
    }


}
