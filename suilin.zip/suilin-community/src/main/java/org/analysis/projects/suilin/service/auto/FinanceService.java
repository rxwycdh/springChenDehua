package org.analysis.projects.suilin.service.auto;

import org.analysis.projects.suilin.model.auto.Finance;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 财务信息 服务类
 * </p>
 *
 * @author Feliz
 * @since 2020-07-28
 */
public interface FinanceService extends IService<Finance> {

}
