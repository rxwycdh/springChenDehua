package org.analysis.projects.ppp.service.auto;

import org.analysis.projects.ppp.model.auto.ProjectDynamic;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 项目动态信息 服务类
 * </p>
 *
 * @author Feliz
 * @since 2020-04-05
 */
public interface ProjectDynamicService extends IService<ProjectDynamic> {

}
