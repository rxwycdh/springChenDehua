package org.analysis.projects.archive.service.auto.impl;

import org.analysis.projects.archive.model.auto.UserCard;
import org.analysis.projects.archive.mapper.auto.UserCardMapper;
import org.analysis.projects.archive.service.auto.UserCardService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 用户档案连接表 服务实现类
 * </p>
 *
 * @author Feliz
 * @since 2020-05-14
 */
@Service
public class UserCardServiceImpl extends ServiceImpl<UserCardMapper, UserCard> implements UserCardService {

}
