package org.analysis.projects.oasystem.service.auto;

import com.baomidou.mybatisplus.extension.service.IService;
import org.analysis.projects.oasystem.model.auto.ObjectStatus;

/**
 * <p>
 * 状态信息 服务类
 * </p>
 *
 * @author Feliz
 * @since 2019-06-14
 */
public interface ObjectStatusService extends IService<ObjectStatus> {

}
