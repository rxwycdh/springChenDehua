package org.analysis.projects.oasystem.service.auto;

import com.baomidou.mybatisplus.extension.service.IService;
import org.analysis.projects.oasystem.model.auto.StaffUser;

/**
 * <p>
 * 职员-系统用户连接表 服务类
 * </p>
 *
 * @author Feliz
 * @since 2019-06-18
 */
public interface StaffUserService extends IService<StaffUser> {

}
