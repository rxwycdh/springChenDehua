package org.analysis.projects.oasystem.service.auto.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.analysis.projects.oasystem.mapper.auto.StaffUserMapper;
import org.analysis.projects.oasystem.model.auto.StaffUser;
import org.analysis.projects.oasystem.service.auto.StaffUserService;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 职员-系统用户连接表 服务实现类
 * </p>
 *
 * @author Feliz
 * @since 2019-06-18
 */
@Service
public class StaffUserServiceImpl extends ServiceImpl<StaffUserMapper, StaffUser> implements StaffUserService {

}
