package org.analysis.system.common.conf;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * 读取项目相关配置
 *
 * @ConfigurationProperties(prefix = "person")告诉SpringBoot将本类中的相关配置与yml文件中的配置绑定
 * 获取配置前缀person下的配置的一一配置。
 * 并且获取的是全局配置的变量的值
 *
 * @Component组件 也就是这个组件只有是spring容器中的组件才能使用@ConfigurationProperties功能
 *
 * @PropertySource(value = {"classpath:person.properties"})获取的是person.properties这个配置文件下的配置信息
 */
@Component
@ConfigurationProperties(prefix = "system")
public class OMGConfig
{
    /** 项目名称 */
    private String name;
    /** 版本 */
    private String version;
    /** 版权年份 */
    private String copyrightYear;
    /** 滚动验证码 **/
    private static Boolean rollVerification;

    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public String getVersion()
    {
        return version;
    }

    public void setVersion(String version)
    {
        this.version = version;
    }

    public String getCopyrightYear()
    {
        return copyrightYear;
    }

    public void setCopyrightYear(String copyrightYear)
    {
        this.copyrightYear = copyrightYear;
    }

    public static Boolean getRollVerification() {
        return rollVerification;
    }

    public  void setRollVerification(Boolean rollVerification) {
        OMGConfig.rollVerification = rollVerification;
    }
}
