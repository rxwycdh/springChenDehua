package org.analysis.system.common.file;

import org.analysis.system.util.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.net.URLEncoder;

/**
 * 文件处理工具类
 *
 * @author fuce
 * @date: 2018年9月22日 下午10:33:31
 */
public class FileUtils {
    private static Logger logger = LoggerFactory.getLogger(FileUtils.class);

    /**
     * 输出指定文件的byte数组
     *
     * @param filePath 文件
     * @return
     */
    public static void writeBytes(String filePath, OutputStream os){
        FileInputStream fis = null;
        try {
            File file = new File(filePath);
            if (!file.exists()) {
                throw new FileNotFoundException(filePath);
            }
            fis = new FileInputStream(file);
            byte[] b = new byte[1024];
            int length;
            while ((length = fis.read(b)) > 0) {
                os.write(b, 0, length);
            }
        } catch (IOException e) {
            logger.error(e.getMessage());
        } finally {
            if (os != null) {
                try {
                    os.close();
                } catch (IOException e1) {
                    logger.error(e1.getMessage());
                }
            }
            if (fis != null) {
                try {
                    fis.close();
                } catch (IOException e1) {
                    logger.error(e1.getMessage());
                }
            }
        }
    }

    /**
     * 删除文件
     *
     * @param filePath 文件
     * @return
     */
    public static boolean deleteFile(String filePath) {
        boolean flag = false;
        File file = new File(filePath);
        // 路径为文件且不为空则进行删除
        if (file.isFile() && file.exists()) {
            file.delete();
            flag = true;
        }
        return flag;
    }

    /**
     * 读取图片地址 输出到页面
     *
     * @param request
     * @param response
     * @param fileurl
     * @throws IOException
     */
    public static void readIMGTohtml(HttpServletRequest request, HttpServletResponse response, String fileurl) {
        OutputStream out = null;
        FileInputStream inputStream = null;
        try {
            //读取本地图片输入流
            File file = new File(fileurl);
            inputStream = new FileInputStream(fileurl);
            int i = inputStream.available();
            //byte数组用于存放图片字节数据
            byte[] buff = new byte[i];
            inputStream.read(buff);

            //设置发送到客户端的响应内容类型
            response.setContentType("image/jpeg");
            //inline:浏览器支持该文件类型的预览，就会打开;attachment:浏览器则直接进行下载;
            response.setHeader("content-disposition", "inline;filename=" + URLEncoder.encode(file.getName(), "UTF-8"));
            out = response.getOutputStream();
            out.write(buff);

        } catch (IOException e) {
            logger.error(e.getMessage());
        } finally {
            //记得关闭输入流
            try {
                if (inputStream != null) {
                    inputStream.close();
                }
                //关闭响应输出流
                if (out != null) {
                    out.close();
                }
            } catch (IOException e1) {
                logger.error(e1.getMessage());
            }
        }
    }

    /**
     * 读取视频地址 输出到页面
     *
     * @param request
     * @param response
     * @param fileurl
     * @throws IOException
     */
    public static void readVideoTohtml(HttpServletRequest request, HttpServletResponse response, String fileurl) {
        OutputStream out = null;
        FileInputStream inputStream = null;
        try {
            //读取本地图片输入流
            File file = new File(fileurl);
            inputStream = new FileInputStream(fileurl);
            int i = inputStream.available();
            //byte数组用于存放图片字节数据
            byte[] buff = new byte[i];
            inputStream.read(buff);

            //设置发送到客户端的响应内容类型
            String rangeString = request.getHeader("Range");//如果是video标签发起的请求就不会为null
            if (StringUtils.isNotEmpty(rangeString)) {
                long range = Long.valueOf(rangeString.substring(rangeString.indexOf("=") + 1, rangeString.indexOf("-")));
                response.setHeader("Content-Range", String.valueOf(range + (file.length()-1)));//拖动进度条时的断点，其中10000是上面的视频文件大小，改成你的就好
            }
            response.setContentType("video/mp4;charset=UTF-8");
            response.setHeader("content-disposition", "inline;filename=" + URLEncoder.encode(file.getName(), "UTF-8"));
            response.setContentLength((int) file.length());//10000是视频文件的大小，上传文件时都会有这些参数的
            response.setHeader("Accept-Ranges", "bytes");
            out = response.getOutputStream();
            out.write(buff);

        } catch (IOException e) {
            logger.error(e.getMessage());
        } finally {
            //记得关闭输入流
            try {
                if (inputStream != null) {
                    inputStream.close();
                }
                //关闭响应输出流
                if (out != null) {
                    out.close();
                }
            } catch (IOException e1) {
                logger.error(e1.getMessage());
            }
        }
    }

    /**
     * 读取音频地址 输出到页面
     *
     * @param request
     * @param response
     * @param fileurl
     * @throws IOException
     */
    public static void readAudioTohtml(HttpServletRequest request, HttpServletResponse response, String fileurl) {
        OutputStream out = null;
        FileInputStream inputStream = null;
        try {
            //读取本地图片输入流
            File file = new File(fileurl);
            inputStream = new FileInputStream(fileurl);
            int i = inputStream.available();
            //byte数组用于存放图片字节数据
            byte[] buff = new byte[i];
            inputStream.read(buff);

            //设置发送到客户端的响应内容类型
            String rangeString = request.getHeader("Range");//如果是video标签发起的请求就不会为null
            if (StringUtils.isNotEmpty(rangeString)) {
                long range = Long.valueOf(rangeString.substring(rangeString.indexOf("=") + 1, rangeString.indexOf("-")));
                response.setHeader("Content-Range", String.valueOf(range + (file.length()-1)));//拖动进度条时的断点，其中10000是上面的视频文件大小，改成你的就好
            }
            response.setContentType("audio/mpeg;charset=UTF-8");
            response.setHeader("content-disposition", "inline;filename=" + URLEncoder.encode(file.getName(), "UTF-8"));
            response.setContentLength((int) file.length());//10000是视频文件的大小，上传文件时都会有这些参数的
            response.setHeader("Accept-Ranges", "bytes");
            out = response.getOutputStream();
            out.write(buff);

        } catch (IOException e) {
            logger.error(e.getMessage());
        } finally {
            //记得关闭输入流
            try {
                if (inputStream != null) {
                    inputStream.close();
                }
                //关闭响应输出流
                if (out != null) {
                    out.close();
                }
            } catch (IOException e1) {
                logger.error(e1.getMessage());
            }
        }
    }
}
