package org.analysis.system.common.base;

public class JavaInfo {

    /**
     * Java的运行环境版本
     */
    private String version;
    /**
     * Java的运行环境供应商
     */
    private String vendor;
    /**
     * Java供应商的URL
     */
    private String vendorURL;

    public JavaInfo() {
    }

    public JavaInfo(String version, String vendor, String vendorURL) {
        this.version = version;
        this.vendor = vendor;
        this.vendorURL = vendorURL;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getVendor() {
        return vendor;
    }

    public void setVendor(String vendor) {
        this.vendor = vendor;
    }

    public String getVendorURL() {
        return vendorURL;
    }

    public void setVendorURL(String vendorURL) {
        this.vendorURL = vendorURL;
    }
}
