package org.analysis.system.common.base;

import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 抽象类BaseService
* @ClassName: BaseService
* @Description: TODO(Service实现这个)
* @author fuce
* @date 2018年6月3日
*
 */
public interface BaseService<T,T2> {
	
    int deleteByPrimaryKey(String ids);

    int insertSelective(T record);

    T selectByPrimaryKey(Integer id);
   
    int updateByPrimaryKeySelective(T record);
    
    int updateByExampleSelective(@Param("record") T record, @Param("example") T2 example);

    int updateByExample(@Param("record") T record, @Param("example") T2 example);
    
    List<T> selectByExample(T2 example);

    long countByExample(T2 example);

    int deleteByExample(T2 example);

}
