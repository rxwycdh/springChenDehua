package org.analysis;


import cn.hutool.core.util.StrUtil;

import org.analysis.core.launch.SuilinApplication;
import org.analysis.core.launch.enums.CommunityEnum;
import org.analysis.core.launch.constant.*;

import org.analysis.projects.suilin.SuilinSystemApplication;
import org.analysis.system.SystemApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;


/**
 * 项目启动方法
 * @author Administrator
 *
 */
@EnableScheduling
//@MapperScan(value = "org.analysis.**.mapper")
@SpringBootApplication
public class SpringbootOMGStart {

    public static void main(String[] args) {

        if(args == null || args.length == 0) {
            throw new RuntimeException("没有指定小区名称，请输入小区英文名称作为参数启动，详见suilin-common CommunityEnum");
        }
        String name = args[0];

        CommunityEnum[] communities = CommunityEnum.values();
        CommunityEnum community = null;

        for (CommunityEnum anEnum : communities) {
            if(anEnum.value.equals(name)) {
                community = anEnum;
            }
        }
        if(community == null) {
            throw new RuntimeException("找不到对应小区！");
        }

        //多模块单独启动
        SuilinApplication.runCommunity(
                AppConstant.APPLICATION_COMMUNITY_NAME_PREFIX.concat(community.value),
                new Class[]{SystemApplication.class, SuilinSystemApplication.class},
                community, args);

        System.out.println("=================================");
        System.out.println(StrUtil.format("==========={}小区系统启动成功，端口{}，数据库连接{}===========",
                community.cnValue, community.port, community.url) );
        System.out.println("=================================");
    }
}
