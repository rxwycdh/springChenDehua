package org.analysis.core.launch.constant;

/**
 * @author ChenDehua  597701764@qq.com
 * @date 2020/8/26 21:20
 */
public interface SentinelConstant {

    /**
     * sentinel 地址
     */
    String SENTINEL_ADDR = "127.0.0.1:8858";
}
